AGROVIAX — website package
==========================

This zip has TWO folders. Use whichever one you need.

1) website-html/   <-- the plain website (HTML + CSS + JS + images)
   - Open index.html in any browser (double-click it) and the site works offline.
   - Pages: index.html, marketplace.html, market-prices.html, crop-health.html,
     crop-guides.html, disease-library.html, services.html, how-it-works.html,
     about.html, pricing.html, contact.html, plus marketplace/ and crop-guides/
     detail pages.
   - assets/  = the stylesheet (.css), scripts (.js), logo and photos.
   - To host it: upload the whole website-html folder to any web host
     (cPanel, Hostinger, Netlify, GitHub Pages). No server setup needed.
   - Note: this is a snapshot. Login, dashboards, orders and the AI crop scan
     need the live database, so they only work in the full app (folder 2).

2) source-code/    <-- the full-stack project that generates the site
   - React + TypeScript + Vite (front end) and server functions + PostgreSQL
     database (back end). The .tsx files are the pages; they compile into the
     HTML/CSS/JS you see in folder 1.
   - Run it locally:
       npm install
       npm run dev      (opens http://localhost:8080)
       npm run build    (production build into dist/)
   - supabase/ holds the database configuration and migrations.
