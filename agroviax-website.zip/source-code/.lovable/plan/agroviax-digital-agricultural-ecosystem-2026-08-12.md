# AGROVIAX — Digital Agricultural Ecosystem

A full platform based on the AGRICORE master document, rebranded as AGROVIAX: public site, real accounts with six roles, live database, and AI crop-disease analysis. Visual direction: Deep Field Green (#0F2F1E deep forest, #1B7A4B growth green, #F4F1E6 cream, #E0A93B harvest gold).

## Brand
- Generated AGROVIAX logo (leaf/growth mark + wordmark), used in header, footer, favicon and social preview.
- Custom typography and tokens; photographic agricultural imagery (farms, produce, markets, greenhouses, logistics) generated for hero and section visuals.

## Public site
- Home — hero, the connected farm-to-market workflow, module highlights, market snapshot, testimonials, CTA
- Marketplace — search, category and location filters, product cards, product detail with seller profile and order/bulk-request actions
- Market Prices — crop price table, trend charts, regional comparison
- Crop Health — explains the detection pipeline, links to the AI tool and disease library
- Disease Library — browsable diseases with symptoms, causes, treatment
- Crop Guides — per-crop soil, planting, spacing, fertilization, pests, harvesting, storage
- Experts, Transport & Services directories
- About, How It Works, Pricing, Contact, Auth

Each page gets its own route and unique SEO metadata.

## Accounts and roles
Email/password sign-up and login on Lovable Cloud, with a separate role table (farmer, buyer, business, expert, transporter, admin) and role-based routing to the right dashboard.

## Role dashboards
- **Farmer** — KPI overview (farms, active crops, expected harvest, expenses, revenue, profit, alerts); farms CRUD; crops with lifecycle status; activities log; expenses and income with profit by crop/farm/season; inventory with low-stock alerts; harvests; product listings; orders; crop-health cases; weather; messages
- **Buyer** — marketplace, cart/checkout, orders and delivery tracking, bulk purchase requests, saved sellers, messages
- **Business** — input catalogue (seeds, fertilizer, crop protection, equipment, irrigation, feed), stock, orders
- **Expert** — case queue, review and diagnosis submission, published guidance
- **Transporter** — vehicles, available delivery jobs, active deliveries with status updates
- **Admin** — users and verification, listings moderation, orders, disease records, market price management, reports, platform analytics

## AI crop disease detection
Upload a crop photo (video accepted and stored), stored securely, analysed server-side through Lovable AI. Returns likely disease, confidence, symptoms and treatment guidance, saved as a case the farmer can escalate to an expert for review.

## Data model
users/profiles, user_roles, farms, crops, crop_activities, harvests, expenses, income, inventory, categories, products, product_images, orders, order_items, bulk_requests, market_prices, diseases, disease_cases, case_media, expert_reviews, vehicles, deliveries, messages, notifications, reviews, reports, verifications, crop_guides, articles. Row-level security scoped per owner and role; seeded with realistic demo content (products, prices, guides, diseases) so every screen is populated from first load.

## Build order
1. Cloud + design system + logo/imagery + public shell and home
2. Auth, roles, protected dashboard shell
3. Farm management (farms, crops, activities, harvests, finance, inventory)
4. Marketplace, orders, bulk requests, buyer and business dashboards
5. Market intelligence, weather, knowledge (guides, disease library)
6. AI crop health + expert review workflow
7. Logistics, messaging, notifications, reviews
8. Admin console and analytics, SEO and polish

## Technical notes
- TanStack Start routes with `head()` metadata per page; Tailwind v4 tokens in `src/styles.css`
- Lovable Cloud for auth, Postgres, storage; RLS on every table with explicit grants; roles in a dedicated `user_roles` table via a `has_role` security-definer function
- AI calls via `createServerFn` against Lovable AI (`google/gemini-3.6-flash` vision), key server-side only
- Media uploads validated for type and size, stored in a private bucket with signed access
