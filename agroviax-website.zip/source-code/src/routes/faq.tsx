import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { MessageCircleQuestion, Send } from "lucide-react";
import { toast } from "sonner";
import { PublicLayout, PageHero } from "@/components/site/PublicLayout";
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/faq")({
  head: () => ({
    meta: [
      { title: "FAQ | AGROVIAX" },
      {
        name: "description",
        content: "Answers about roles, the crop-health AI, marketplace orders, payment and delivery on AGROVIAX.",
      },
    ],
  }),
  component: FAQ,
});

const FAQ_GROUPS: { group: string; items: { q: string; a: string }[] }[] = [
  {
    group: "Getting started",
    items: [
      {
        q: "What's the difference between the account roles?",
        a: "Farmer and Agricultural Business list produce or inputs and track farms and finances. Buyer browses and orders from the marketplace. Transporter registers vehicles and picks up delivery jobs. Agricultural Expert reviews crop-health cases farmers escalate. You choose your role when you sign up, and your dashboard changes to match it.",
      },
      {
        q: "Can I have more than one role?",
        a: "Each account has one primary role chosen at sign-up, since it determines which dashboard sections you see. If you need a second role — for example a farmer who also transports produce — the simplest approach today is a second account for that role. Role combination on a single account isn't built yet.",
      },
      {
        q: "I signed up with an email I've already used — what happens?",
        a: "You'll get a clear error telling you the email is already registered, and you should sign in instead. If you signed up before but never confirmed your email, sign-up intentionally doesn't reveal whether that email exists yet, as a security precaution against email-guessing — try signing in, or use \"forgot password\" to regain access.",
      },
    ],
  },
  {
    group: "Crop health AI",
    items: [
      {
        q: "How accurate is the AI diagnosis?",
        a: "It's an AI-assisted first read, not a lab diagnosis. Every result includes a confidence score, and cases with lower confidence or higher severity are flagged for expert review. Treat it as a fast first opinion that tells you whether — and how urgently — to get a human expert involved.",
      },
      {
        q: "What happens when I request an expert review?",
        a: "Your case (photo, crop type, your notes and the AI's read) is added to the queue every verified expert can see. Once an expert submits a diagnosis and recommendation, you're notified and it appears on your case in Crop Health Cases.",
      },
      {
        q: "Is my crop photo private?",
        a: "Yes. Photos are stored in a private bucket only you and reviewing experts can access — they aren't part of the public marketplace or visible to other farmers.",
      },
    ],
  },
  {
    group: "Marketplace, orders & payment",
    items: [
      {
        q: "How do I pay for an order?",
        a: "At checkout you choose Pay on Delivery or Bank Transfer, and settle payment directly with the seller by that method. AGROVIAX doesn't process card payments on the platform yet — the order record is what both sides use to track what was agreed.",
      },
      {
        q: "Does the seller know when I order?",
        a: "Yes — placing an order notifies the seller immediately (visible in their notification bell and Orders dashboard), and you're notified in turn whenever they update its status.",
      },
      {
        q: "How does delivery get arranged?",
        a: "Once an order is placed, a delivery job can be posted with pickup and drop-off details. Available transporters are notified and can accept it, then update its status as it moves — you'll see the same status on your order.",
      },
    ],
  },
  {
    group: "Account & data",
    items: [
      {
        q: "Can I turn off notifications?",
        a: "Yes — go to Settings → Notifications to toggle order, message and delivery notifications independently.",
      },
      {
        q: "How do I delete my account?",
        a: "Settings → Danger zone → Request account deletion. Because it removes your farms, listings, cases and messages permanently, it's confirmed by a person rather than instant.",
      },
    ],
  },
];

function FAQ() {
  const [sending, setSending] = useState(false);

  return (
    <PublicLayout>
      <PageHero
        eyebrow="Support"
        title="Frequently asked questions"
        description="Answers about roles, the crop-health AI, ordering, payment and delivery. Can't find yours? Ask below."
      />

      <section className="mx-auto max-w-3xl px-4 py-14 sm:px-6">
        {FAQ_GROUPS.map((g) => (
          <div key={g.group} className="mb-10">
            <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-muted-foreground">{g.group}</h2>
            <Accordion type="single" collapsible className="rounded-xl border border-border bg-card">
              {g.items.map((item, i) => (
                <AccordionItem key={item.q} value={`${g.group}-${i}`} className="px-4">
                  <AccordionTrigger className="text-left text-sm font-medium">{item.q}</AccordionTrigger>
                  <AccordionContent className="text-sm text-muted-foreground">{item.a}</AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        ))}

        <div className="rounded-xl border border-border bg-card p-6">
          <h2 className="flex items-center gap-2 text-base font-semibold">
            <MessageCircleQuestion className="h-4 w-4 text-primary" /> Still have a question?
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Send it to us directly — it goes straight to the AGROVIAX team's inbox.
          </p>
          <form
            className="mt-4 space-y-3"
            onSubmit={async (e) => {
              e.preventDefault();
              const form = e.currentTarget;
              const data = new FormData(form);
              const name = String(data.get("name") ?? "").trim();
              const email = String(data.get("email") ?? "").trim();
              const question = String(data.get("question") ?? "").trim();
              if (!name || !email || !question) return;

              setSending(true);
              const { error } = await supabase.from("contact_messages").insert({
                name,
                email,
                subject: "FAQ question",
                body: question,
              });
              setSending(false);

              if (error) {
                toast.error("Couldn't send your question — please try again.");
                return;
              }
              form.reset();
              toast.success("Question sent — we'll reply by email.");
            }}
          >
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="faq-name">Name</Label>
                <Input id="faq-name" name="name" required />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="faq-email">Email</Label>
                <Input id="faq-email" name="email" type="email" required />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="faq-question">Your question</Label>
              <Textarea id="faq-question" name="question" rows={3} required />
            </div>
            <Button type="submit" disabled={sending}>
              <Send className="mr-2 h-4 w-4" /> {sending ? "Sending…" : "Ask"}
            </Button>
          </form>
        </div>
      </section>
    </PublicLayout>
  );
}
