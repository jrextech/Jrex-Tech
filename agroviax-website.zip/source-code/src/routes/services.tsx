import { createFileRoute, Link } from "@tanstack/react-router";
import { Truck, Warehouse, Wrench, Sprout, PackageCheck, Route as RouteIcon } from "lucide-react";
import { PublicLayout, PageHero } from "@/components/site/PublicLayout";
import { Button } from "@/components/ui/button";
import logisticsImage from "@/assets/logistics.jpg";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Transport, Storage & Farm Services | AGROVIAX" },
      {
        name: "description",
        content:
          "Book produce transport, find storage, hire equipment and access agronomy services through the AGROVIAX network of verified providers.",
      },
      { property: "og:title", content: "Farm Services & Logistics | AGROVIAX" },
      { property: "og:description", content: "Transport, storage, equipment hire and agronomy support in one network." },
    ],
  }),
  component: Services,
});

const SERVICES = [
  { icon: Truck, title: "Produce transport", body: "Registered transporters with vehicle type, capacity and base location, matched to your load and route." },
  { icon: Warehouse, title: "Storage & aggregation", body: "Short-term storage near collection points so harvest is not forced onto the market on a bad price day." },
  { icon: Wrench, title: "Equipment hire", body: "Tractors, tillers, sprayers, threshers and irrigation kit listed by agricultural businesses." },
  { icon: Sprout, title: "Agronomy support", body: "Verified experts reviewing crop cases, soil questions and input programmes." },
  { icon: PackageCheck, title: "Post-harvest handling", body: "Grading, packing and quality-grade recording attached to each harvest and listing." },
  { icon: RouteIcon, title: "Delivery tracking", body: "Pickup, in-transit and delivered status shared between buyer, seller and transporter." },
];

const DELIVERY_FLOW = [
  ["Order confirmed", "Buyer and seller agree quantity, price and delivery address."],
  ["Job posted", "A delivery is created with pickup, dropoff and fee."],
  ["Transporter accepts", "A verified transporter with matching capacity takes the job."],
  ["In transit", "Status updates keep all three parties on the same record."],
  ["Delivered", "Delivery is closed, the order completes and reviews open."],
];

function Services() {
  return (
    <PublicLayout>
      <PageHero
        eyebrow="Services"
        title="Getting the crop to the buyer is half the business."
        description="AGROVIAX connects farms to transporters, storage, equipment and agronomy support, so a good harvest is not lost between the field and the market."
      />

      <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map((s) => (
            <div key={s.title} className="rounded-xl border border-border bg-card p-6">
              <s.icon className="h-6 w-6 text-primary" />
              <h2 className="mt-4 text-lg font-semibold">{s.title}</h2>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{s.body}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="border-y border-border bg-secondary/40">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 py-16 sm:px-6 md:grid-cols-2">
          <figure className="overflow-hidden rounded-xl border border-border">
            <img
              src={logisticsImage}
              alt="Truck loaded with sacks of produce on a rural road"
              width={1200}
              height={900}
              className="h-full w-full object-cover"
            />
          </figure>
          <div>
            <h2 className="text-2xl md:text-3xl">How a delivery moves</h2>
            <ol className="mt-6 space-y-3">
              {DELIVERY_FLOW.map(([title, body], i) => (
                <li key={title} className="flex gap-4 rounded-lg border border-border bg-card p-4">
                  <span className="font-display text-sm text-gold">{String(i + 1).padStart(2, "0")}</span>
                  <div>
                    <p className="text-sm font-medium">{title}</p>
                    <p className="mt-0.5 text-xs text-muted-foreground">{body}</p>
                  </div>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-3xl px-4 py-20 text-center sm:px-6">
        <h2 className="text-2xl md:text-3xl">Own a vehicle? Put it to work.</h2>
        <p className="mt-4 text-sm text-muted-foreground">
          Register as a transporter, list your vehicles and start receiving delivery jobs matched to your capacity and
          base location.
        </p>
        <div className="mt-7 flex flex-wrap justify-center gap-3">
          <Button asChild size="lg">
            <Link to="/auth" search={{ mode: "signup" }}>Register as a transporter</Link>
          </Button>
          <Button asChild size="lg" variant="outline">
            <Link to="/marketplace">Browse the marketplace</Link>
          </Button>
        </div>
      </section>
    </PublicLayout>
  );
}
