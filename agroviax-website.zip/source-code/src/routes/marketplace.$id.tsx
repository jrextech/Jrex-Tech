import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery, useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { MapPin, Leaf, BadgeCheck, ShoppingCart, MessageCircle, ArrowLeft, Check, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { PublicLayout } from "@/components/site/PublicLayout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { getProduct } from "@/lib/public.functions";
import { useAuth } from "@/hooks/useAuth";
import { useCart } from "@/lib/cart";
import { supabase } from "@/integrations/supabase/client";

const productQuery = (id: string) =>
  queryOptions({ queryKey: ["product", id], queryFn: () => getProduct({ data: { id } }) });

export const Route = createFileRoute("/marketplace/$id")({
  loader: async ({ context, params }) => {
    const result = await context.queryClient.ensureQueryData(productQuery(params.id));
    if (!result.product) throw notFound();
    return result;
  },
  head: ({ loaderData }) => {
    if (!loaderData?.product) {
      return { meta: [{ title: "Listing unavailable | AGROVIAX" }, { name: "robots", content: "noindex" }] };
    }
    const p = loaderData.product;
    const description = `${p.title} — ₦${Number(p.price).toLocaleString()}/${p.unit} from ${p.seller_name} in ${p.location}.`;
    return {
      meta: [
        { title: `${p.title} | AGROVIAX Marketplace` },
        { name: "description", content: description },
        { property: "og:title", content: `${p.title} | AGROVIAX` },
        { property: "og:description", content: description },
        ...(p.image_url?.startsWith("https://")
          ? [
              { property: "og:image", content: p.image_url },
              { name: "twitter:image", content: p.image_url },
            ]
          : []),
      ],
    };
  },
  component: ProductDetail,
});

function ProductDetail() {
  const { id } = Route.useParams();
  const { data } = useSuspenseQuery(productQuery(id));
  const p = data.product!;
  const { user } = useAuth();
  const cart = useCart();
  const [added, setAdded] = useState(false);
  const [messageOpen, setMessageOpen] = useState(false);
  const [messageBody, setMessageBody] = useState(`Hi, is "${p.title}" still available?`);
  const isOwnListing = !!user && user.id === p.seller_id;

  const sendMessage = useMutation({
    mutationFn: async () => {
      if (!user) throw new Error("Sign in to message a seller.");
      if (!messageBody.trim()) throw new Error("Write a message first.");
      const { error } = await supabase.from("messages").insert({
        sender_id: user.id,
        recipient_id: p.seller_id,
        body: messageBody.trim(),
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Message sent — find the reply in your dashboard inbox.");
      setMessageOpen(false);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const handleAddToCart = () => {
    cart.add({
      id: p.id,
      title: p.title,
      price: Number(p.price),
      unit: p.unit,
      image_url: p.image_url,
      seller_id: p.seller_id,
      seller_name: p.seller_name,
      transport_option: p.transport_option,
      weight_kg: p.weight_kg,
      pickup_location: p.location,
    });
    setAdded(true);
    toast.success("Added to your basket.");
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <PublicLayout>
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
        <Link to="/marketplace" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Back to marketplace
        </Link>

        <div className="mt-6 grid gap-10 lg:grid-cols-[1.15fr_1fr]">
          <div className="overflow-hidden rounded-xl border border-border">
            {p.image_url && (
              <img src={p.image_url} alt={p.title} width={1200} height={800} className="h-full w-full object-cover" />
            )}
          </div>

          <div>
            <div className="flex flex-wrap gap-1.5">
              {p.organic && (
                <Badge variant="secondary" className="gap-1">
                  <Leaf className="h-3 w-3" /> Organic
                </Badge>
              )}
              {p.verified && (
                <Badge className="gap-1 bg-forest text-forest-foreground hover:bg-forest">
                  <BadgeCheck className="h-3 w-3" /> Verified seller
                </Badge>
              )}
            </div>
            <h1 className="mt-4 text-3xl md:text-4xl">{p.title}</h1>
            <p className="mt-2 flex items-center gap-1.5 text-sm text-muted-foreground">
              <MapPin className="h-4 w-4" /> {p.location} · Sold by {p.seller_name}
            </p>

            <p className="mt-6 font-display text-4xl text-forest">
              ₦{Number(p.price).toLocaleString()}
              <span className="text-base text-muted-foreground">/{p.unit}</span>
            </p>
            <p className="mt-1 text-sm text-muted-foreground">
              {Number(p.quantity_available).toLocaleString()} {p.unit} available
            </p>

            <p className="mt-6 text-sm leading-relaxed text-muted-foreground">{p.description}</p>

            <div className="mt-8 flex flex-wrap gap-3">
              {!user ? (
                <>
                  <Button asChild size="lg">
                    <Link to="/auth" search={{ mode: "signin" }}>
                      <ShoppingCart className="mr-2 h-4 w-4" /> Sign in to order
                    </Link>
                  </Button>
                  <Button asChild size="lg" variant="outline">
                    <Link to="/auth" search={{ mode: "signin" }}>
                      <MessageCircle className="mr-2 h-4 w-4" /> Message seller
                    </Link>
                  </Button>
                </>
              ) : isOwnListing ? (
                <Button asChild size="lg" variant="outline">
                  <Link to="/dashboard/listings">Manage this listing</Link>
                </Button>
              ) : (
                <>
                  <Button size="lg" onClick={handleAddToCart} disabled={added}>
                    {added ? (
                      <>
                        <Check className="mr-2 h-4 w-4" /> Added
                      </>
                    ) : (
                      <>
                        <ShoppingCart className="mr-2 h-4 w-4" /> Add to basket
                      </>
                    )}
                  </Button>
                  <Button size="lg" variant="outline" onClick={() => setMessageOpen((v) => !v)}>
                    <MessageCircle className="mr-2 h-4 w-4" /> Message seller
                  </Button>
                </>
              )}
            </div>

            {messageOpen && user && !isOwnListing && (
              <Card className="mt-4">
                <CardContent className="space-y-3 p-4">
                  <Textarea
                    value={messageBody}
                    onChange={(e) => setMessageBody(e.target.value)}
                    rows={3}
                    placeholder={`Message ${p.seller_name}…`}
                  />
                  <Button
                    size="sm"
                    disabled={sendMessage.isPending}
                    onClick={() => sendMessage.mutate()}
                  >
                    {sendMessage.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Sending…
                      </>
                    ) : (
                      "Send message"
                    )}
                  </Button>
                </CardContent>
              </Card>
            )}

            <Card className="mt-8">
              <CardContent className="grid gap-4 p-5 sm:grid-cols-2">
                <Detail label="Category" value={p.category_slug.replace(/-/g, " ")} />
                <Detail label="Unit" value={p.unit} />
                <Detail label="Currency" value={p.currency} />
                <Detail label="Listed" value={new Date(p.created_at).toLocaleDateString()} />
              </CardContent>
            </Card>
          </div>
        </div>

        {data.related.length > 0 && (
          <section className="mt-16">
            <h2 className="text-2xl">Similar listings</h2>
            <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {data.related.map((r) => (
                <Link
                  key={r.id}
                  to="/marketplace/$id"
                  params={{ id: r.id }}
                  className="overflow-hidden rounded-lg border border-border bg-card transition-shadow hover:shadow-md"
                >
                  {r.image_url && (
                    <img src={r.image_url} alt={r.title} loading="lazy" width={400} height={280} className="h-36 w-full object-cover" />
                  )}
                  <div className="p-4">
                    <h3 className="text-sm font-semibold">{r.title}</h3>
                    <p className="mt-1 text-xs text-muted-foreground">{r.location}</p>
                    <p className="mt-2 font-display text-base text-forest">
                      ₦{Number(r.price).toLocaleString()}/{r.unit}
                    </p>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}
      </div>
    </PublicLayout>
  );
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-xs uppercase tracking-widest text-muted-foreground">{label}</p>
      <p className="mt-1 text-sm font-medium capitalize">{value}</p>
    </div>
  );
}
