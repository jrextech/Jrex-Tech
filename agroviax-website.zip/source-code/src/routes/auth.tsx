import { useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { Logo } from "@/components/brand/Logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ROLE_LABELS, type AppRole } from "@/hooks/useAuth";

export const Route = createFileRoute("/auth")({
  validateSearch: (search: Record<string, unknown>) => ({
    mode: search["mode"] === "signup" ? ("signup" as const) : ("signin" as const),
  }),
  head: () => ({
    meta: [
      { title: "Sign in or create your AGROVIAX account" },
      {
        name: "description",
        content: "Access your AGROVIAX dashboard as a farmer, buyer, agricultural business, expert or transporter.",
      },
      { property: "og:title", content: "Sign in to AGROVIAX" },
      { property: "og:description", content: "One account for farm management, marketplace and logistics." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Auth,
});

// Transporter and logistics_partner are deliberately absent — AGROVIAX
// creates those accounts itself (see dashboard.admin.tsx "Create driver
// account" / "Register partner company"), never public self-signup.
const ROLES: AppRole[] = ["farmer", "buyer", "business", "expert"];

function Auth() {
  const { mode } = Route.useSearch();
  const navigate = useNavigate();
  const [isSignup, setIsSignup] = useState(mode === "signup");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [role, setRole] = useState<AppRole>("farmer");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (isSignup) {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: `${window.location.origin}/dashboard`,
            data: { full_name: fullName, role },
          },
        });
        if (error) throw error;
        toast.success("Account created. Welcome to AGROVIAX.");
        navigate({ to: "/dashboard" });
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        navigate({ to: "/dashboard" });
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Something went wrong.");
    } finally {
      setLoading(false);
    }
  };

  const google = async () => {
    const result = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
    if (result.error) {
      toast.error("Google sign-in failed. Please try again.");
      return;
    }
    if (result.redirected) return;
    navigate({ to: "/dashboard" });
  };

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="hidden flex-col justify-between bg-forest p-12 text-forest-foreground lg:flex">
        <Logo tone="light" />
        <div>
          <h1 className="max-w-md text-4xl leading-tight">One account for the whole agricultural cycle.</h1>
          <p className="mt-5 max-w-sm text-sm text-forest-foreground/70">
            Manage farms, diagnose crop problems, sell produce, arrange transport and track profit — all from a
            dashboard built around your role.
          </p>
        </div>
        <p className="text-xs text-forest-foreground/50">&copy; {new Date().getFullYear()} AGROVIAX</p>
      </div>

      <div className="flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-sm">
          <div className="lg:hidden">
            <Logo />
          </div>
          <h2 className="mt-8 text-2xl lg:mt-0">{isSignup ? "Create your account" : "Welcome back"}</h2>
          <p className="mt-1.5 text-sm text-muted-foreground">
            {isSignup ? "Choose your role to get the right dashboard." : "Sign in to continue to your dashboard."}
          </p>

          <Button variant="outline" className="mt-6 w-full" onClick={google} type="button">
            Continue with Google
          </Button>

          <div className="my-6 flex items-center gap-3 text-xs text-muted-foreground">
            <span className="h-px flex-1 bg-border" /> or use email <span className="h-px flex-1 bg-border" />
          </div>

          <form onSubmit={submit} className="space-y-4">
            {isSignup && (
              <>
                <div>
                  <Label htmlFor="fullName">Full name</Label>
                  <Input id="fullName" value={fullName} onChange={(e) => setFullName(e.target.value)} required className="mt-2" />
                </div>
                <div>
                  <Label htmlFor="role">I am a…</Label>
                  <select
                    id="role"
                    value={role}
                    onChange={(e) => setRole(e.target.value as AppRole)}
                    className="mt-2 h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                  >
                    {ROLES.map((r) => (
                      <option key={r} value={r}>
                        {ROLE_LABELS[r]}
                      </option>
                    ))}
                  </select>
                </div>
              </>
            )}
            <div>
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="mt-2" />
            </div>
            <div>
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={6}
                className="mt-2"
              />
            </div>
            <Button type="submit" className="w-full" disabled={loading}>
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isSignup ? "Create account" : "Sign in"}
            </Button>
          </form>

          <p className="mt-6 text-center text-sm text-muted-foreground">
            {isSignup ? "Already have an account?" : "New to AGROVIAX?"}{" "}
            <button type="button" onClick={() => setIsSignup((v) => !v)} className="font-medium text-primary hover:underline">
              {isSignup ? "Sign in" : "Create one"}
            </button>
          </p>
          <p className="mt-4 text-center text-xs text-muted-foreground">
            <Link to="/" className="hover:underline">
              Back to AGROVIAX
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
