import { createFileRoute } from "@tanstack/react-router";
import { supabaseAdmin } from "@/integrations/supabase/admin";
import { verifyWebhookSignature, verifyTransaction } from "@/lib/paystack";

/**
 * Paystack calls this URL directly (not the browser) whenever a payment
 * event happens. Configure it in the Paystack dashboard → Settings → API
 * Keys & Webhooks as: https://YOUR_DOMAIN/api/webhooks/paystack
 *
 * Two independent checks before anything is trusted, per the safe-payment
 * document's requirements:
 *   1. HMAC signature check — proves the request body really came from
 *      Paystack and wasn't forged.
 *   2. Server-side verifyTransaction call back to Paystack's API — proves
 *      the payment is real even if the webhook body itself were somehow
 *      spoofed. Never trust only the webhook payload for something this
 *      consequential.
 * Idempotent: if this fires twice for the same reference (Paystack does
 * retry), the second call is a no-op because we check the payment's
 * current status before doing anything.
 */
export const Route = createFileRoute("/api/webhooks/paystack")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const rawBody = await request.text();
        const signature = request.headers.get("x-paystack-signature");

        const validSignature = await verifyWebhookSignature(rawBody, signature);
        if (!validSignature) {
          return new Response("Invalid signature", { status: 401 });
        }

        const event = JSON.parse(rawBody);
        if (event.event !== "charge.success") {
          return new Response("ignored", { status: 200 });
        }

        const reference = event.data?.reference as string | undefined;
        if (!reference) return new Response("missing reference", { status: 400 });

        // Re-verify with Paystack's API directly — do not trust the webhook
        // body alone, even after the signature check.
        const verified = await verifyTransaction(reference);
        if (verified.status !== "success") {
          return new Response("not successful", { status: 200 });
        }

        const db = supabaseAdmin();
        const { data: payment } = await db.from("payments").select("*").eq("reference", reference).maybeSingle();
        if (!payment) return new Response("unknown reference", { status: 404 });

        if (payment.status === "paid" || payment.status === "released") {
          // Already processed — a Paystack retry, not a new event.
          return new Response("already processed", { status: 200 });
        }

        await db.from("payments").update({ status: "paid" }).eq("id", payment.id);
        await db.from("orders").update({ status: "paid" }).eq("id", payment.order_id);

        return new Response("ok", { status: 200 });
      },
    },
  },
});
