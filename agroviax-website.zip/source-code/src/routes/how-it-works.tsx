import { createFileRoute, Link } from "@tanstack/react-router";
import { Sprout, ShoppingBasket, Building2, Stethoscope, Truck, ShieldCheck } from "lucide-react";
import { PublicLayout, PageHero } from "@/components/site/PublicLayout";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export const Route = createFileRoute("/how-it-works")({
  head: () => ({
    meta: [
      { title: "How AGROVIAX Works — For Every Role in Agriculture" },
      {
        name: "description",
        content:
          "See exactly what farmers, buyers, agricultural businesses, experts, transporters and administrators can do inside AGROVIAX.",
      },
      { property: "og:title", content: "How AGROVIAX Works" },
      { property: "og:description", content: "A walkthrough of the platform for each of the six user roles." },
    ],
  }),
  component: HowItWorks,
});

const ROLES = [
  {
    key: "farmer",
    icon: Sprout,
    label: "Farmer",
    headline: "Run the farm and sell the harvest in one place.",
    steps: [
      "Register your farms with size, location, soil type and irrigation method",
      "Add crop cycles with variety, planting date and expected yield",
      "Log activities — planting, weeding, spraying, fertilizing — with their cost",
      "Scan sick plants with the crop-health AI and escalate to an expert if needed",
      "Record the harvest with quantity and quality grade",
      "List produce on the marketplace and accept orders",
      "Track expenses and income to see real profit per crop and per season",
    ],
  },
  {
    key: "buyer",
    icon: ShoppingBasket,
    label: "Buyer",
    headline: "Source produce directly, at a price you can verify.",
    steps: [
      "Browse and filter listings by crop, category, price and location",
      "Check seller verification status, ratings and reviews before ordering",
      "Place an order and track it from pending through to delivered",
      "Post a bulk purchase request with your target price and deadline",
      "Message sellers directly to negotiate quantity and logistics",
      "Compare listing prices against live market price data",
    ],
  },
  {
    key: "business",
    icon: Building2,
    label: "Agricultural business",
    headline: "Reach farmers who are ready to buy inputs.",
    steps: [
      "List seeds, fertilizer, crop protection, equipment, feed and veterinary products",
      "Manage stock levels, pricing and product visibility",
      "Receive and fulfil orders from farmers across regions",
      "Build reputation through verified status and buyer reviews",
    ],
  },
  {
    key: "expert",
    icon: Stethoscope,
    label: "Agricultural expert",
    headline: "Review real cases and advise farmers at scale.",
    steps: [
      "Receive crop-health cases escalated by farmers with photos and AI findings",
      "Confirm, correct or refine the diagnosis",
      "Write treatment and prevention recommendations the farmer can act on",
      "Contribute to the disease library and crop guides",
    ],
  },
  {
    key: "transporter",
    icon: Truck,
    label: "Transporter",
    headline: "Turn empty return trips into paid deliveries.",
    steps: [
      "Register vehicles with type, plate number, capacity and base location",
      "Set availability and see delivery jobs matched to your capacity",
      "Accept a job and record pickup and dropoff locations and fee",
      "Update status through in-transit to delivered so everyone stays informed",
    ],
  },
  {
    key: "admin",
    icon: ShieldCheck,
    label: "Administrator",
    headline: "Keep the ecosystem trustworthy.",
    steps: [
      "Verify farmers, businesses, experts and transporters",
      "Moderate listings and resolve disputes between parties",
      "Maintain market price records, disease entries and crop guides",
      "Monitor platform activity across every module",
    ],
  },
] as const;

function HowItWorks() {
  return (
    <PublicLayout>
      <PageHero
        eyebrow="How it works"
        title="Six roles. One connected platform."
        description="AGROVIAX is not one product wearing six hats — each role gets its own dashboard, permissions and workflow, while sharing the same underlying data."
      />

      <div className="mx-auto max-w-5xl px-4 py-12 sm:px-6">
        <Tabs defaultValue="farmer">
          <TabsList className="flex h-auto w-full flex-wrap justify-start gap-1">
            {ROLES.map((r) => (
              <TabsTrigger key={r.key} value={r.key} className="gap-1.5">
                <r.icon className="h-4 w-4" />
                {r.label}
              </TabsTrigger>
            ))}
          </TabsList>

          {ROLES.map((r) => (
            <TabsContent key={r.key} value={r.key} className="mt-8">
              <h2 className="text-2xl md:text-3xl">{r.headline}</h2>
              <ol className="mt-6 space-y-3">
                {r.steps.map((s, i) => (
                  <li key={s} className="flex gap-4 rounded-lg border border-border bg-card p-4">
                    <span className="font-display text-sm text-gold">{String(i + 1).padStart(2, "0")}</span>
                    <p className="text-sm">{s}</p>
                  </li>
                ))}
              </ol>
            </TabsContent>
          ))}
        </Tabs>

        <div className="mt-14 rounded-xl border border-border bg-secondary/40 p-8 text-center">
          <h2 className="text-xl">Pick your role and start</h2>
          <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
            You choose your role when you create your account, and your dashboard is built around it.
          </p>
          <Button asChild className="mt-5">
            <Link to="/auth" search={{ mode: "signup" }}>Create account</Link>
          </Button>
        </div>
      </div>
    </PublicLayout>
  );
}
