import { createFileRoute, Link } from "@tanstack/react-router";
import { Check } from "lucide-react";
import { PublicLayout, PageHero } from "@/components/site/PublicLayout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export const Route = createFileRoute("/pricing")({
  head: () => ({
    meta: [
      { title: "Pricing — Free for Farmers | AGROVIAX" },
      {
        name: "description",
        content:
          "AGROVIAX is free for farmers to manage farms, scan crop health and sell produce. Growth and business plans add expert reviews, analytics and priority placement.",
      },
      { property: "og:title", content: "AGROVIAX Pricing" },
      { property: "og:description", content: "Free for farmers. Paid tiers for businesses and high-volume traders." },
    ],
  }),
  component: Pricing,
});

const PLANS = [
  {
    name: "Starter",
    price: "Free",
    note: "For every farmer and buyer",
    features: [
      "Unlimited farms and crop records",
      "Activity, expense and income tracking",
      "Crop-health AI scans",
      "Marketplace listings and orders",
      "Live market prices",
      "Crop guides and disease library",
    ],
  },
  {
    name: "Growth",
    price: "₦4,500",
    period: "/month",
    note: "For serious commercial farms",
    featured: true,
    features: [
      "Everything in Starter",
      "Priority expert review on crop cases",
      "Season profitability analytics per crop",
      "Featured marketplace placement",
      "Inventory and low-stock alerts",
      "Bulk request matching",
    ],
  },
  {
    name: "Business",
    price: "₦18,000",
    period: "/month",
    note: "For agri-businesses and processors",
    features: [
      "Everything in Growth",
      "Multi-user team accounts",
      "Input catalogue with stock management",
      "Verified business badge",
      "Logistics coordination tools",
      "Regional demand reporting",
    ],
  },
];

const FAQS: Array<{ q: string; a: string }> = [
  { q: "Is AGROVIAX really free for farmers?", a: "Yes. Farm management, crop records, crop-health AI scans, marketplace listings and market prices are all included at no cost on the Starter plan." },
  { q: "Do you take a commission on sales?", a: "Starter accounts trade without a subscription. Transaction handling and any applicable service fee are shown clearly before an order is confirmed." },
  { q: "What does an expert review cost?", a: "Escalating a crop case to a verified agricultural expert is included on Growth and Business, and available as a one-off on Starter." },
  { q: "Can transporters use the platform for free?", a: "Yes. Transporters register vehicles and accept delivery jobs at no subscription cost." },
  { q: "Can I change plans later?", a: "Plans can be upgraded or downgraded at any time and take effect from the next billing cycle." },
];

function Pricing() {
  return (
    <PublicLayout>
      <PageHero
        eyebrow="Pricing"
        title="Free where it matters most."
        description="Farmers should never pay to record their own harvest or find out what their crop is worth. Paid tiers exist for teams and businesses that need depth."
      />

      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <div className="grid gap-6 lg:grid-cols-3">
          {PLANS.map((plan) => (
            <div
              key={plan.name}
              className={`flex flex-col rounded-2xl border p-8 ${
                plan.featured ? "border-forest bg-forest text-forest-foreground shadow-lg" : "border-border bg-card"
              }`}
            >
              {plan.featured && <Badge className="mb-4 w-fit bg-gold text-gold-foreground hover:bg-gold">Most popular</Badge>}
              <h2 className="text-xl">{plan.name}</h2>
              <p className={`mt-1 text-xs ${plan.featured ? "text-forest-foreground/70" : "text-muted-foreground"}`}>
                {plan.note}
              </p>
              <p className="mt-6 font-display text-4xl">
                {plan.price}
                {plan.period && <span className="text-base font-normal opacity-70">{plan.period}</span>}
              </p>
              <ul className="mt-7 flex-1 space-y-3 text-sm">
                {plan.features.map((f) => (
                  <li key={f} className="flex gap-2.5">
                    <Check className={`mt-0.5 h-4 w-4 shrink-0 ${plan.featured ? "text-gold" : "text-primary"}`} />
                    <span className={plan.featured ? "text-forest-foreground/85" : "text-muted-foreground"}>{f}</span>
                  </li>
                ))}
              </ul>
              <Button
                asChild
                className={`mt-8 ${plan.featured ? "bg-gold text-gold-foreground hover:bg-gold/90" : ""}`}
                variant={plan.featured ? "default" : "outline"}
              >
                <Link to="/auth" search={{ mode: "signup" }}>Get started</Link>
              </Button>
            </div>
          ))}
        </div>

        <div className="mx-auto mt-20 max-w-3xl">
          <h2 className="text-2xl">Frequently asked questions</h2>
          <Accordion type="single" collapsible className="mt-6">
            {FAQS.map((item) => (
              <AccordionItem key={item.q} value={item.q}>
                <AccordionTrigger className="text-left">{item.q}</AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground">{item.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </PublicLayout>
  );
}
