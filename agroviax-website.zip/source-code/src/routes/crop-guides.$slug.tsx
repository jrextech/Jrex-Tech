import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { ArrowLeft } from "lucide-react";
import { PublicLayout } from "@/components/site/PublicLayout";
import { getCropGuide } from "@/lib/public.functions";

const guideQuery = (slug: string) =>
  queryOptions({ queryKey: ["crop-guide", slug], queryFn: () => getCropGuide({ data: { slug } }) });

export const Route = createFileRoute("/crop-guides/$slug")({
  loader: async ({ context, params }) => {
    const result = await context.queryClient.ensureQueryData(guideQuery(params.slug));
    if (!result.guide) throw notFound();
    return result;
  },
  head: ({ loaderData }) => {
    if (!loaderData?.guide) {
      return { meta: [{ title: "Guide unavailable | AGROVIAX" }, { name: "robots", content: "noindex" }] };
    }
    const g = loaderData.guide;
    return {
      meta: [
        { title: `How to Grow ${g.crop_name} — Complete Guide | AGROVIAX` },
        { name: "description", content: (g.overview ?? "").slice(0, 155) },
        { property: "og:title", content: `How to Grow ${g.crop_name} | AGROVIAX` },
        { property: "og:description", content: (g.overview ?? "").slice(0, 155) },
      ],
    };
  },
  component: GuideDetail,
});

function GuideDetail() {
  const { slug } = Route.useParams();
  const { data } = useSuspenseQuery(guideQuery(slug));
  const g = data.guide!;

  const sections: Array<[string, string | null]> = [
    ["Soil & land preparation", g.soil],
    ["Planting", g.planting],
    ["Spacing", g.spacing],
    ["Fertilization", g.fertilization],
    ["Common pests", g.pests],
    ["Common diseases", g.diseases],
    ["Harvesting", g.harvesting],
    ["Storage & post-harvest", g.storage],
    ["Market outlook", g.market_info],
  ];

  return (
    <PublicLayout>
      <article className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
        <Link
          to="/crop-guides"
          className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" /> All crop guides
        </Link>

        <h1 className="mt-6 text-3xl md:text-5xl">How to grow {g.crop_name}</h1>
        {g.season && <p className="mt-3 text-sm text-primary">{g.season}</p>}
        <p className="mt-5 text-base leading-relaxed text-muted-foreground">{g.overview}</p>

        <div className="mt-10 space-y-9">
          {sections.map(([title, body]) =>
            body ? (
              <section key={title}>
                <h2 className="text-xl">{title}</h2>
                {Array.isArray(body) ? (
                  <ul className="mt-3 list-inside list-disc space-y-1.5 text-sm leading-relaxed text-muted-foreground">
                    {body.map((b) => (
                      <li key={b}>{b}</li>
                    ))}
                  </ul>
                ) : (
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{body}</p>
                )}
              </section>
            ) : null,
          )}
        </div>
      </article>
    </PublicLayout>
  );
}
