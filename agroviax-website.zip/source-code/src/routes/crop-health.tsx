import { useRef, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation } from "@tanstack/react-query";
import { Upload, Loader2, ScanLine, Stethoscope, ShieldAlert, RotateCcw, CheckCircle2, FolderOpen } from "lucide-react";
import { toast } from "sonner";
import { PublicLayout, PageHero } from "@/components/site/PublicLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent } from "@/components/ui/card";
import { analyzeCropPhoto, type CropAnalysis } from "@/lib/crop-health.functions";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import cropHealthImage from "@/assets/crop-health.jpg";

/**
 * Persists an analysed case for a signed-in farmer: uploads the photo to the
 * private crop-media storage bucket (RLS-scoped to the user's own folder),
 * gets a long-lived signed URL, then writes the disease_cases row so it shows
 * up in /dashboard/cases and — once escalated — in the expert desk queue.
 */
async function saveCaseToDatabase({
  userId,
  file,
  cropType,
  notes,
  analysis,
}: {
  userId: string;
  file: File;
  cropType: string;
  notes: string;
  analysis: CropAnalysis;
}) {
  const path = `${userId}/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9.\-_]/g, "_")}`;
  const upload = await supabase.storage.from("crop-media").upload(path, file, {
    contentType: file.type,
    upsert: false,
  });
  if (upload.error) throw upload.error;

  const signed = await supabase.storage.from("crop-media").createSignedUrl(path, 60 * 60 * 24 * 365);
  const mediaUrl = signed.data?.signedUrl ?? null;

  const { data, error } = await supabase
    .from("disease_cases")
    .insert({
      farmer_id: userId,
      crop_type: cropType,
      media_url: mediaUrl,
      media_type: "image",
      symptoms_note: notes || null,
      ai_disease: analysis.disease,
      ai_confidence: analysis.confidence,
      ai_summary: analysis.summary || null,
      ai_treatment: analysis.treatment.join("; ") || null,
      ai_prevention: analysis.prevention.join("; ") || null,
      status: "analyzed",
    })
    .select("id")
    .single();
  if (error) throw error;
  return data.id as string;
}

export const Route = createFileRoute("/crop-health")({
  head: () => ({
    meta: [
      { title: "AI Crop Disease Detection from a Photo | AGROVIAX" },
      {
        name: "description",
        content:
          "Upload a photo of an affected plant and get a likely diagnosis, severity, treatment steps and prevention advice in seconds — then escalate to a verified expert.",
      },
      { property: "og:title", content: "AI Crop Health Analysis | AGROVIAX" },
      { property: "og:description", content: "Diagnose crop disease from a photo, with treatment and prevention steps." },
    ],
  }),
  component: CropHealth,
});

const MAX_BYTES = 6 * 1024 * 1024;

function CropHealth() {
  const { user } = useAuth();
  const [preview, setPreview] = useState<string | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [cropType, setCropType] = useState("");
  const [notes, setNotes] = useState("");
  const [result, setResult] = useState<CropAnalysis | null>(null);
  const [caseId, setCaseId] = useState<string | null>(null);
  const [expertRequested, setExpertRequested] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const analyze = useServerFn(analyzeCropPhoto);
  const mutation = useMutation({
    mutationFn: (input: { imageDataUrl: string; cropType: string; notes: string }) => analyze({ data: input }),
    onSuccess: (data) => {
      setResult(data);
      setCaseId(null);
      setExpertRequested(false);
      if (user && file) {
        saveCase.mutate({ userId: user.id, file, cropType: cropType.trim(), notes: notes.trim(), analysis: data });
      }
    },
    onError: (error: Error) => toast.error(error.message || "Analysis failed. Please try again."),
  });

  const saveCase = useMutation({
    mutationFn: saveCaseToDatabase,
    onSuccess: (id) => setCaseId(id),
    onError: (error: Error) =>
      toast.error(error.message || "Analysed, but saving this case to your account failed. You can still read the result below."),
  });

  const requestExpert = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("disease_cases").update({ status: "expert_requested" }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      setExpertRequested(true);
      toast.success("Sent to a verified agricultural expert for review.");
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const onFile = (picked: File | undefined) => {
    if (!picked) return;
    if (!picked.type.startsWith("image/")) {
      toast.error("Please upload an image file.");
      return;
    }
    if (picked.size > MAX_BYTES) {
      toast.error("Image must be under 6MB.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setPreview(reader.result as string);
      setResult(null);
      setCaseId(null);
      setExpertRequested(false);
    };
    reader.readAsDataURL(picked);
    setFile(picked);
  };

  const submit = () => {
    if (!preview) {
      toast.error("Upload a photo of the affected plant first.");
      return;
    }
    if (!cropType.trim()) {
      toast.error("Tell us which crop this is.");
      return;
    }
    mutation.mutate({ imageDataUrl: preview, cropType: cropType.trim(), notes: notes.trim() });
  };

  const reset = () => {
    setPreview(null);
    setFile(null);
    setResult(null);
    setCaseId(null);
    setExpertRequested(false);
    setNotes("");
    if (fileRef.current) fileRef.current.value = "";
  };

  return (
    <PublicLayout>
      <PageHero
        eyebrow="Crop health"
        title="Photograph the problem. Get an answer in seconds."
        description="Our vision model looks at the leaf, stem or fruit you photograph and returns a likely diagnosis with confidence, severity, treatment options and prevention practices."
      />

      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-12 sm:px-6 lg:grid-cols-[1fr_1.1fr]">
        {/* Upload panel */}
        <Card>
          <CardContent className="space-y-5 p-6">
            <div>
              <Label htmlFor="crop-photo">Photo of the affected plant</Label>
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => {
                  e.preventDefault();
                  onFile(e.dataTransfer.files[0]);
                }}
                className="mt-2 flex w-full flex-col items-center justify-center overflow-hidden rounded-lg border-2 border-dashed border-border bg-secondary/30 transition-colors hover:border-primary/50"
              >
                {preview ? (
                  <img src={preview} alt="Uploaded crop" className="max-h-80 w-full object-contain" />
                ) : (
                  <span className="flex flex-col items-center gap-2 px-6 py-14 text-center">
                    <Upload className="h-7 w-7 text-muted-foreground" />
                    <span className="text-sm font-medium">Click to upload or drag a photo here</span>
                    <span className="text-xs text-muted-foreground">JPG or PNG, up to 6MB. Get close to the affected area.</span>
                  </span>
                )}
              </button>
              <input
                id="crop-photo"
                ref={fileRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => onFile(e.target.files?.[0])}
              />
            </div>

            <div>
              <Label htmlFor="crop-type">Crop type</Label>
              <Input
                id="crop-type"
                value={cropType}
                onChange={(e) => setCropType(e.target.value)}
                placeholder="e.g. Maize, Tomato, Cassava"
                className="mt-2"
              />
            </div>

            <div>
              <Label htmlFor="notes">What are you seeing? (optional)</Label>
              <Textarea
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Spreading over the last week, worse after rain, lower leaves first…"
                className="mt-2"
                rows={3}
              />
            </div>

            <div className="flex gap-2">
              <Button onClick={submit} disabled={mutation.isPending} className="flex-1">
                {mutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Analysing…
                  </>
                ) : (
                  <>
                    <ScanLine className="mr-2 h-4 w-4" /> Analyse photo
                  </>
                )}
              </Button>
              {(preview || result) && (
                <Button variant="outline" onClick={reset} disabled={mutation.isPending}>
                  <RotateCcw className="h-4 w-4" />
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Result panel */}
        <div>
          {!result && !mutation.isPending && (
            <div className="overflow-hidden rounded-xl border border-border">
              <img
                src={cropHealthImage}
                alt="Close-up of a crop leaf showing disease symptoms being photographed"
                width={1200}
                height={900}
                className="h-56 w-full object-cover"
              />
              <div className="space-y-4 p-6">
                <h2 className="text-xl">How to get the best result</h2>
                <ul className="list-inside list-disc space-y-2 text-sm text-muted-foreground">
                  <li>Fill the frame with the affected leaf, stem or fruit</li>
                  <li>Shoot in daylight, avoiding harsh shadow and blur</li>
                  <li>Include both healthy and affected tissue if you can</li>
                  <li>Add a note about spread, weather and how long it has been happening</li>
                </ul>
                <p className="rounded-md bg-secondary/60 p-3 text-xs text-muted-foreground">
                  AI analysis is guidance, not a substitute for a field visit. For high-severity or spreading outbreaks,
                  escalate the case to a verified agricultural expert.
                </p>
              </div>
            </div>
          )}

          {mutation.isPending && (
            <div className="flex h-72 flex-col items-center justify-center rounded-xl border border-border bg-card">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <p className="mt-4 text-sm text-muted-foreground">Examining leaf structure, colour and lesion pattern…</p>
            </div>
          )}

          {result && (
            <div className="space-y-6 rounded-xl border border-border bg-card p-6">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="text-xs uppercase tracking-widest text-muted-foreground">Likely diagnosis</p>
                  <h2 className="mt-1 text-2xl">{result.disease}</h2>
                </div>
                <Badge
                  variant={result.severity === "high" ? "destructive" : "secondary"}
                  className="capitalize"
                >
                  {result.severity} severity
                </Badge>
              </div>

              <div>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>Confidence</span>
                  <span>{result.confidence}%</span>
                </div>
                <Progress value={result.confidence} className="mt-2" />
              </div>

              {result.summary && <p className="text-sm leading-relaxed text-muted-foreground">{result.summary}</p>}

              <ResultList title="Symptoms identified" items={result.symptoms} />
              <ResultList title="Recommended treatment" items={result.treatment} />
              <ResultList title="Prevention going forward" items={result.prevention} />

              {!user && (
                <div className="rounded-lg border border-gold/40 bg-gold/10 p-4">
                  <p className="flex items-center gap-2 text-sm font-medium">
                    <ShieldAlert className="h-4 w-4 text-gold" /> Want this saved to a farm record?
                  </p>
                  <p className="mt-1.5 text-xs text-muted-foreground">
                    Sign in to save this case to your account and send it to a verified agricultural expert for
                    human confirmation.
                  </p>
                  <Button asChild size="sm" className="mt-3">
                    <Link to="/auth" search={{ mode: "signup" }}>
                      <Stethoscope className="mr-1.5 h-4 w-4" /> Sign up to save cases
                    </Link>
                  </Button>
                </div>
              )}

              {user && saveCase.isPending && (
                <p className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Loader2 className="h-3.5 w-3.5 animate-spin" /> Saving this case to your account…
                </p>
              )}

              {user && caseId && (
                <div className="rounded-lg border border-border bg-secondary/40 p-4">
                  <p className="flex items-center gap-2 text-sm font-medium text-forest">
                    <CheckCircle2 className="h-4 w-4" /> Saved to your crop-health cases
                  </p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {expertRequested ? (
                      <Badge variant="secondary">
                        <Stethoscope className="mr-1.5 h-3.5 w-3.5" /> Expert review requested
                      </Badge>
                    ) : (
                      (result.expertRecommended || result.severity !== "low") && (
                        <Button
                          size="sm"
                          variant="outline"
                          disabled={requestExpert.isPending}
                          onClick={() => requestExpert.mutate(caseId)}
                        >
                          <Stethoscope className="mr-1.5 h-4 w-4" />
                          {requestExpert.isPending ? "Sending…" : "Request expert review"}
                        </Button>
                      )
                    )}
                    <Button asChild size="sm" variant="ghost">
                      <Link to="/dashboard/cases">
                        <FolderOpen className="mr-1.5 h-4 w-4" /> View all my cases
                      </Link>
                    </Button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </PublicLayout>
  );
}

function ResultList({ title, items }: { title: string; items: string[] }) {
  if (!items.length) return null;
  return (
    <div>
      <h3 className="text-xs font-semibold uppercase tracking-widest text-primary">{title}</h3>
      <ul className="mt-2 list-inside list-disc space-y-1.5 text-sm text-muted-foreground">
        {items.map((i) => (
          <li key={i}>{i}</li>
        ))}
      </ul>
    </div>
  );
}
