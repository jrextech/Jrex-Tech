import { createFileRoute, Link } from "@tanstack/react-router";
import { Target, Users, Layers, Globe2 } from "lucide-react";
import { PublicLayout, PageHero } from "@/components/site/PublicLayout";
import { Button } from "@/components/ui/button";
import heroImage from "@/assets/hero-farmland.jpg";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About AGROVIAX — Connecting the Agricultural Value Chain" },
      {
        name: "description",
        content:
          "AGROVIAX is a digital agricultural ecosystem built to connect farmers, buyers, agri-businesses, experts, transporters and administrators on one integrated platform.",
      },
      { property: "og:title", content: "About AGROVIAX" },
      { property: "og:description", content: "Why we built one connected platform for the agricultural value chain." },
    ],
  }),
  component: About,
});

const VALUES = [
  { icon: Target, title: "Solve the whole problem", body: "Fragmented tools create fragmented data. One ecosystem keeps the farm's story intact from planting to payment." },
  { icon: Users, title: "Every role matters", body: "Farmers, buyers, businesses, experts, transporters and administrators each get purpose-built tools, not a watered-down view." },
  { icon: Layers, title: "Data that compounds", body: "A harvest record becomes a listing. A listing becomes an order. An order becomes a delivery and an income entry." },
  { icon: Globe2, title: "Built for real conditions", body: "Mobile-first, low-bandwidth aware, and designed around how produce actually moves from farm to market." },
];

function About() {
  return (
    <PublicLayout>
      <PageHero
        eyebrow="About us"
        title="Agriculture loses value in the gaps between people."
        description="Between the farm and the buyer sit missing price information, undiagnosed crop disease, unreliable transport and paper records. AGROVIAX closes those gaps by putting the whole value chain on one platform."
      />

      <section className="mx-auto grid max-w-7xl items-center gap-12 px-4 py-16 sm:px-6 md:grid-cols-2">
        <figure className="overflow-hidden rounded-xl border border-border">
          <img src={heroImage} alt="Farmland with crop rows stretching to the horizon" width={1200} height={900} className="h-full w-full object-cover" />
        </figure>
        <div>
          <h2 className="text-2xl md:text-3xl">Our mission</h2>
          <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
            To give every participant in agriculture — from a smallholder with one hectare to a processor sourcing
            hundreds of tonnes — the same quality of information, market access and operational tooling.
          </p>
          <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
            A farmer who can diagnose disease early, knows today's price at three nearby markets, sells directly to a
            buyer and books transport in the same session keeps far more of the value they created. That is the entire
            point of AGROVIAX.
          </p>
        </div>
      </section>

      <section className="border-y border-border bg-secondary/40">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
          <h2 className="text-2xl md:text-3xl">What we believe</h2>
          <div className="mt-8 grid gap-5 sm:grid-cols-2">
            {VALUES.map((v) => (
              <div key={v.title} className="rounded-xl border border-border bg-card p-6">
                <v.icon className="h-6 w-6 text-primary" />
                <h3 className="mt-4 text-lg font-semibold">{v.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{v.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-3xl px-4 py-20 text-center sm:px-6">
        <h2 className="text-2xl md:text-3xl">Join the ecosystem</h2>
        <p className="mt-4 text-sm text-muted-foreground">
          Creating an account takes a minute and gives you the dashboard for your role immediately.
        </p>
        <Button asChild size="lg" className="mt-7">
          <Link to="/auth" search={{ mode: "signup" }}>Create your account</Link>
        </Button>
      </section>
    </PublicLayout>
  );
}
