import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { ArrowRight, CalendarDays } from "lucide-react";
import { PublicLayout, PageHero } from "@/components/site/PublicLayout";
import { listCropGuides } from "@/lib/public.functions";

const guidesQuery = queryOptions({ queryKey: ["crop-guides"], queryFn: () => listCropGuides() });

export const Route = createFileRoute("/crop-guides/")({
  head: () => ({
    meta: [
      { title: "Crop Growing Guides — Planting to Harvest | AGROVIAX" },
      {
        name: "description",
        content:
          "Practical crop-by-crop growing guides covering soil, planting, spacing, fertilizer, irrigation, pests and harvest timing.",
      },
      { property: "og:title", content: "Crop Growing Guides | AGROVIAX" },
      { property: "og:description", content: "Step-by-step growing guides from land preparation to harvest." },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(guidesQuery),
  component: CropGuides,
});

function CropGuides() {
  const { data } = useSuspenseQuery(guidesQuery);

  return (
    <PublicLayout>
      <PageHero
        eyebrow="Knowledge centre"
        title="Crop guides from land preparation to harvest"
        description="Each guide covers the soil and climate the crop wants, planting and spacing, fertilizer and irrigation schedules, common problems and when to harvest."
      />

      <div className="mx-auto grid max-w-7xl gap-5 px-4 py-12 sm:px-6 md:grid-cols-2 lg:grid-cols-3">
        {data.guides.map((g) => (
          <Link
            key={g.slug}
            to="/crop-guides/$slug"
            params={{ slug: g.slug }}
            className="group flex flex-col rounded-xl border border-border bg-card p-6 transition-shadow hover:shadow-md"
          >
            <h2 className="text-xl">{g.crop_name}</h2>
            {g.season && (
              <p className="mt-2 flex items-center gap-1.5 text-xs text-muted-foreground">
                <CalendarDays className="h-3.5 w-3.5" /> {g.season}
              </p>
            )}
            <p className="mt-3 line-clamp-3 text-sm text-muted-foreground">{g.overview}</p>
            <span className="mt-5 inline-flex items-center gap-1 text-sm font-medium text-primary">
              Read the guide
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
            </span>
          </Link>
        ))}
      </div>
    </PublicLayout>
  );
}
