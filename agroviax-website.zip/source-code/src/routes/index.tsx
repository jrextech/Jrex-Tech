import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import {
  ArrowRight,
  Sprout,
  ShoppingBasket,
  LineChart,
  ScanLine,
  Truck,
  BookOpen,
  Wallet,
  ShieldCheck,
  TrendingUp,
  TrendingDown,
} from "lucide-react";
import { PublicLayout } from "@/components/site/PublicLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getHomeSnapshot } from "@/lib/public.functions";
import heroImage from "@/assets/hero-farmland.jpg";
import cropHealthImage from "@/assets/crop-health.jpg";
import marketplaceImage from "@/assets/marketplace.jpg";
import logisticsImage from "@/assets/logistics.jpg";

const snapshotQuery = queryOptions({
  queryKey: ["home-snapshot"],
  queryFn: () => getHomeSnapshot(),
});

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "AGROVIAX — The Digital Agricultural Ecosystem" },
      {
        name: "description",
        content:
          "Manage farms, monitor crop health with AI, track market prices, sell produce and arrange delivery — AGROVIAX connects the whole farm-to-market journey.",
      },
      { property: "og:title", content: "AGROVIAX — The Digital Agricultural Ecosystem" },
      {
        property: "og:description",
        content:
          "Farm management, marketplace, crop-health AI, market intelligence and logistics in one connected platform.",
      },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(snapshotQuery),
  component: Home,
});

const MODULES = [
  { icon: Sprout, title: "Farm & Crop Management", body: "Farms, crop cycles, activities and harvest records in one place." },
  { icon: Wallet, title: "Farm Finance", body: "Expenses, income and profit by crop, farm and season." },
  { icon: ShoppingBasket, title: "Marketplace", body: "Sell produce direct to buyers and source verified inputs." },
  { icon: LineChart, title: "Market Intelligence", body: "Live crop prices, regional comparison and trend direction." },
  { icon: ScanLine, title: "Crop Health AI", body: "Photo-based disease analysis with expert review on request." },
  { icon: BookOpen, title: "Knowledge Centre", body: "Crop guides and a searchable disease library." },
  { icon: Truck, title: "Logistics", body: "Transporters, vehicles and tracked deliveries per order." },
  { icon: ShieldCheck, title: "Trust & Verification", body: "Verified sellers, ratings, reviews and admin oversight." },
];

const WORKFLOW = [
  "Create a farm and add crops",
  "Record activities and expenses",
  "Scan crop problems with AI",
  "Request expert review",
  "Log the harvest",
  "List produce on the marketplace",
  "Confirm the order and arrange transport",
  "Record revenue and see profit",
];

function Home() {
  const { data } = useSuspenseQuery(snapshotQuery);

  return (
    <PublicLayout>
      {/* Hero */}
      <section className="relative isolate overflow-hidden bg-forest text-forest-foreground">
        <img
          src={heroImage}
          alt="Aerial view of farmland at sunrise with rows of maize and vegetables"
          width={1920}
          height={1280}
          className="absolute inset-0 h-full w-full object-cover opacity-35"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-forest via-forest/85 to-forest/40" />
        <div className="relative mx-auto max-w-7xl px-4 py-24 sm:px-6 md:py-32">
          <Badge className="bg-gold text-gold-foreground hover:bg-gold">One platform. The whole farm cycle.</Badge>
          <h1 className="mt-6 max-w-3xl text-4xl leading-[1.05] md:text-6xl">
            From the first seed to the final sale, connected.
          </h1>
          <p className="mt-5 max-w-xl text-base text-forest-foreground/80 md:text-lg">
            AGROVIAX brings farm management, crop-health intelligence, market access, logistics and farm finance into a
            single agricultural ecosystem — so information entered in one place creates value everywhere else.
          </p>
          <div className="mt-9 flex flex-wrap gap-3">
            <Button asChild size="lg" className="bg-gold text-gold-foreground hover:bg-gold/90">
              <Link to="/auth" search={{ mode: "signup" }}>
                Create your free account
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-forest-foreground/30 bg-transparent text-forest-foreground hover:bg-forest-foreground/10"
            >
              <Link to="/marketplace">Browse the marketplace</Link>
            </Button>
          </div>
          <dl className="mt-14 grid max-w-2xl grid-cols-2 gap-6 sm:grid-cols-4">
            {[
              ["6", "user roles"],
              ["12", "market categories"],
              ["18", "tracked markets"],
              ["24/7", "crop-health AI"],
            ].map(([value, label]) => (
              <div key={label}>
                <dt className="font-display text-3xl text-gold">{value}</dt>
                <dd className="mt-1 text-xs uppercase tracking-widest text-forest-foreground/60">{label}</dd>
              </div>
            ))}
          </dl>
        </div>
      </section>

      {/* Workflow */}
      <section className="border-b border-border bg-card">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
          <h2 className="text-2xl md:text-3xl">One continuous agricultural workflow</h2>
          <p className="mt-3 max-w-2xl text-sm text-muted-foreground">
            Not a collection of unrelated pages. Every step feeds the next, and the numbers add up at the end of the
            season.
          </p>
          <ol className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {WORKFLOW.map((step, i) => (
              <li key={step} className="rounded-lg border border-border bg-background p-4">
                <span className="font-display text-sm text-gold">{String(i + 1).padStart(2, "0")}</span>
                <p className="mt-1.5 text-sm font-medium">{step}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* Modules */}
      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
        <h2 className="text-2xl md:text-3xl">Everything the farm needs, in modules that talk to each other</h2>
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {MODULES.map((m) => (
            <Card key={m.title} className="border-border/80 transition-shadow hover:shadow-md">
              <CardContent className="p-5">
                <m.icon className="h-6 w-6 text-primary" />
                <h3 className="mt-4 text-base font-semibold">{m.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{m.body}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Market snapshot */}
      <section className="border-y border-border bg-secondary/50">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <h2 className="text-2xl md:text-3xl">Today's market snapshot</h2>
              <p className="mt-2 text-sm text-muted-foreground">Prices recorded across tracked agricultural markets.</p>
            </div>
            <Button asChild variant="outline">
              <Link to="/market-prices">See all prices</Link>
            </Button>
          </div>
          <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {data.prices.map((p) => {
              const change = p.previous_price ? Number(p.price) - Number(p.previous_price) : 0;
              const up = change >= 0;
              return (
                <div
                  key={`${p.crop_type}-${p.market_name}`}
                  className="flex items-center justify-between rounded-lg border border-border bg-card p-4"
                >
                  <div>
                    <p className="font-medium">{p.crop_type}</p>
                    <p className="text-xs text-muted-foreground">{p.market_name}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-display text-lg">
                      ₦{Number(p.price).toLocaleString()}
                      <span className="text-xs text-muted-foreground">/{p.unit}</span>
                    </p>
                    <p className={`flex items-center justify-end gap-1 text-xs ${up ? "text-success" : "text-destructive"}`}>
                      {up ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                      {change === 0 ? "steady" : `${up ? "+" : ""}${change.toFixed(0)}`}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Feature spotlights */}
      <section className="mx-auto max-w-7xl space-y-20 px-4 py-20 sm:px-6">
        <Spotlight
          image={cropHealthImage}
          alt="Farmer holding a phone that is scanning a diseased crop leaf"
          eyebrow="Crop health"
          title="Photograph the problem. Get an answer in seconds."
          body="Upload a photo of an affected leaf, stem or fruit and AGROVIAX returns a likely diagnosis, confidence level, treatment steps and prevention advice. Not sure? Escalate the same case to a verified agricultural expert for human review."
          to="/crop-health"
          cta="Try crop-health AI"
        />
        <Spotlight
          reverse
          image={marketplaceImage}
          alt="Market stall filled with tomatoes, peppers, yams and grains"
          eyebrow="Marketplace"
          title="Sell direct. Buy in bulk. Skip the guesswork."
          body="Farmers list harvested produce with quantity, grade and location. Buyers search, filter and order — or post a bulk purchase request and let verified sellers come to them. Agricultural businesses list seeds, fertilizer, crop protection, equipment and feed alongside."
          to="/marketplace"
          cta="Open the marketplace"
        />
        <Spotlight
          image={logisticsImage}
          alt="Truck loaded with sacks of produce driving on a rural road at sunrise"
          eyebrow="Logistics"
          title="Every order can become a tracked delivery."
          body="Registered transporters list vehicles and capacity, pick up delivery jobs and update status from pickup through in-transit to delivered — with buyer, seller and admin all seeing the same record."
          to="/services"
          cta="Find transport & services"
        />
      </section>

      {/* Latest listings */}
      <section className="border-t border-border bg-card">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <h2 className="text-2xl md:text-3xl">Fresh on the marketplace</h2>
            <Button asChild variant="outline">
              <Link to="/marketplace">View all listings</Link>
            </Button>
          </div>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {data.products.map((p) => (
              <Link
                key={p.id}
                to="/marketplace/$id"
                params={{ id: p.id }}
                className="group overflow-hidden rounded-lg border border-border bg-background transition-shadow hover:shadow-md"
              >
                {p.image_url && (
                  <img
                    src={p.image_url}
                    alt={p.title}
                    loading="lazy"
                    width={600}
                    height={400}
                    className="h-44 w-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
                  />
                )}
                <div className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <h3 className="text-base font-semibold">{p.title}</h3>
                    {p.verified && <Badge variant="secondary">Verified</Badge>}
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {p.seller_name} · {p.location}
                  </p>
                  <p className="mt-3 font-display text-lg text-forest">
                    ₦{Number(p.price).toLocaleString()}
                    <span className="text-xs text-muted-foreground">/{p.unit}</span>
                  </p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
        <div className="field-grid rounded-2xl border border-border bg-secondary/40 p-10 text-center md:p-16">
          <h2 className="text-2xl md:text-4xl">Join the ecosystem in your role</h2>
          <p className="mx-auto mt-4 max-w-xl text-sm text-muted-foreground">
            Farmer, buyer, agricultural business, expert, transporter or administrator — each role gets its own
            dashboard, permissions and tools.
          </p>
          <Button asChild size="lg" className="mt-8">
            <Link to="/auth" search={{ mode: "signup" }}>
              Get started free
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>
    </PublicLayout>
  );
}

function Spotlight({
  image,
  alt,
  eyebrow,
  title,
  body,
  to,
  cta,
  reverse,
}: {
  image: string;
  alt: string;
  eyebrow: string;
  title: string;
  body: string;
  to: "/crop-health" | "/marketplace" | "/services";
  cta: string;
  reverse?: boolean;
}) {
  return (
    <div className={`grid items-center gap-10 md:grid-cols-2 ${reverse ? "md:[&>figure]:order-2" : ""}`}>
      <figure className="overflow-hidden rounded-xl border border-border">
        <img src={image} alt={alt} loading="lazy" width={1200} height={900} className="h-full w-full object-cover" />
      </figure>
      <div>
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-primary">{eyebrow}</p>
        <h2 className="mt-3 text-2xl md:text-3xl">{title}</h2>
        <p className="mt-4 text-sm leading-relaxed text-muted-foreground">{body}</p>
        <Button asChild className="mt-6">
          <Link to={to}>{cta}</Link>
        </Button>
      </div>
    </div>
  );
}
