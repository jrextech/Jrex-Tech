import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { Search, ShieldAlert } from "lucide-react";
import { PublicLayout, PageHero } from "@/components/site/PublicLayout";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { listDiseases } from "@/lib/public.functions";

const diseasesQuery = queryOptions({ queryKey: ["diseases"], queryFn: () => listDiseases() });

export const Route = createFileRoute("/disease-library")({
  head: () => ({
    meta: [
      { title: "Crop Disease Library — Symptoms & Treatment | AGROVIAX" },
      {
        name: "description",
        content:
          "Identify crop diseases and pests by symptom, and read causes, treatment options and prevention practices for each one.",
      },
      { property: "og:title", content: "Crop Disease Library | AGROVIAX" },
      { property: "og:description", content: "Symptoms, causes, treatment and prevention for common crop diseases." },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(diseasesQuery),
  component: DiseaseLibrary,
});

function DiseaseLibrary() {
  const { data } = useSuspenseQuery(diseasesQuery);
  const [search, setSearch] = useState("");

  const items = data.diseases.filter((d) => {
    const q = search.toLowerCase();
    return (
      !search ||
      d.name.toLowerCase().includes(q) ||
      (d.affected_crops ?? "").toLowerCase().includes(q) ||
      (d.symptoms ?? "").toLowerCase().includes(q)
    );
  });

  return (
    <PublicLayout>
      <PageHero
        eyebrow="Knowledge centre"
        title="Crop disease & pest library"
        description="Search by crop, disease name or the symptom you can see in the field. Every entry lists causes, treatment options and prevention practices."
      />

      <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="e.g. yellow leaves, cassava, blight…"
            className="pl-9"
          />
        </div>

        <Accordion type="single" collapsible className="mt-8">
          {items.map((d) => (
            <AccordionItem key={d.id} value={d.id}>
              <AccordionTrigger className="text-left">
                <span className="flex flex-1 flex-wrap items-center gap-2 pr-3">
                  <span className="font-medium">{d.name}</span>
                  {d.severity && (
                    <Badge variant={d.severity === "high" ? "destructive" : "secondary"} className="capitalize">
                      {d.severity} severity
                    </Badge>
                  )}
                </span>
              </AccordionTrigger>
              <AccordionContent className="space-y-5 text-sm">
                <Section title="Affected crops" body={d.affected_crops} />
                <Section title="Symptoms" body={d.symptoms} />
                <Section title="Causes" body={d.causes} />
                <Section title="Treatment" body={d.treatment} />
                <Section title="Prevention" body={d.prevention} />
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>

        {items.length === 0 && (
          <p className="mt-10 text-center text-sm text-muted-foreground">No entries match that search.</p>
        )}

        <div className="mt-14 rounded-xl border border-border bg-secondary/40 p-8 text-center">
          <ShieldAlert className="mx-auto h-7 w-7 text-primary" />
          <h2 className="mt-3 text-xl">Can't identify it from a description?</h2>
          <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
            Photograph the affected plant and let the crop-health AI analyse it, then escalate to a verified expert if
            you want a second opinion.
          </p>
          <Button asChild className="mt-5">
            <Link to="/crop-health">Analyse a photo</Link>
          </Button>
        </div>
      </div>
    </PublicLayout>
  );
}

function Section({ title, body }: { title: string; body: string | null }) {
  if (!body) return null;
  const parts = body
    .split(/\r?\n|(?<=\.)\s{1,}(?=[A-Z])/)
    .map((p) => p.trim())
    .filter(Boolean);
  return (
    <div>
      <h3 className="text-xs font-semibold uppercase tracking-widest text-primary">{title}</h3>
      {parts.length > 1 ? (
        <ul className="mt-2 list-inside list-disc space-y-1 text-muted-foreground">
          {parts.map((p) => (
            <li key={p}>{p}</li>
          ))}
        </ul>
      ) : (
        <p className="mt-2 text-muted-foreground">{body}</p>
      )}
    </div>
  );
}
