import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { Search, MapPin, Leaf, BadgeCheck } from "lucide-react";
import { PublicLayout, PageHero } from "@/components/site/PublicLayout";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { listProducts } from "@/lib/public.functions";

const productsQuery = queryOptions({ queryKey: ["products"], queryFn: () => listProducts() });

export const Route = createFileRoute("/marketplace/")({
  head: () => ({
    meta: [
      { title: "Marketplace — Buy & Sell Produce and Farm Inputs | AGROVIAX" },
      {
        name: "description",
        content:
          "Browse fresh produce, grains, seeds, fertilizer, equipment and livestock from verified farmers and agricultural businesses on AGROVIAX.",
      },
      { property: "og:title", content: "AGROVIAX Marketplace" },
      {
        property: "og:description",
        content: "Fresh produce, grains, inputs and equipment from verified sellers.",
      },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(productsQuery),
  component: Marketplace,
});

function Marketplace() {
  const { data } = useSuspenseQuery(productsQuery);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState<string>("all");
  const [sort, setSort] = useState<"newest" | "price-asc" | "price-desc">("newest");

  const filtered = useMemo(() => {
    let items = data.products.filter((p) => {
      const matchesSearch =
        !search ||
        p.title.toLowerCase().includes(search.toLowerCase()) ||
        (p.location ?? "").toLowerCase().includes(search.toLowerCase());
      const matchesCat = category === "all" || p.category_slug === category;
      return matchesSearch && matchesCat;
    });
    if (sort === "price-asc") items = [...items].sort((a, b) => Number(a.price) - Number(b.price));
    if (sort === "price-desc") items = [...items].sort((a, b) => Number(b.price) - Number(a.price));
    return items;
  }, [data.products, search, category, sort]);

  return (
    <PublicLayout>
      <PageHero
        eyebrow="Marketplace"
        title="Buy direct from farms. Sell without middlemen."
        description="Produce, grains, seeds, fertilizer, crop protection, equipment, livestock and feed — listed by verified farmers and agricultural businesses."
      />

      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search produce, inputs or location…"
              className="pl-9"
            />
          </div>
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value as typeof sort)}
            className="h-10 rounded-md border border-input bg-background px-3 text-sm"
          >
            <option value="newest">Newest first</option>
            <option value="price-asc">Price: low to high</option>
            <option value="price-desc">Price: high to low</option>
          </select>
        </div>

        <div className="mt-5 flex flex-wrap gap-2">
          <CategoryChip active={category === "all"} onClick={() => setCategory("all")} label="All listings" />
          {data.categories.map((c) => (
            <CategoryChip
              key={c.slug}
              active={category === c.slug}
              onClick={() => setCategory(c.slug)}
              label={c.name}
            />
          ))}
        </div>

        <p className="mt-6 text-sm text-muted-foreground">
          {filtered.length} listing{filtered.length === 1 ? "" : "s"}
        </p>

        <div className="mt-4 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((p) => (
            <Link
              key={p.id}
              to="/marketplace/$id"
              params={{ id: p.id }}
              className="group flex flex-col overflow-hidden rounded-xl border border-border bg-card transition-shadow hover:shadow-lg"
            >
              {p.image_url && (
                <img
                  src={p.image_url}
                  alt={p.title}
                  loading="lazy"
                  width={600}
                  height={400}
                  className="h-48 w-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
                />
              )}
              <div className="flex flex-1 flex-col p-5">
                <div className="flex flex-wrap gap-1.5">
                  {p.organic && (
                    <Badge variant="secondary" className="gap-1">
                      <Leaf className="h-3 w-3" /> Organic
                    </Badge>
                  )}
                  {p.verified && (
                    <Badge className="gap-1 bg-forest text-forest-foreground hover:bg-forest">
                      <BadgeCheck className="h-3 w-3" /> Verified seller
                    </Badge>
                  )}
                </div>
                <h2 className="mt-3 text-base font-semibold">{p.title}</h2>
                <p className="mt-1.5 line-clamp-2 text-sm text-muted-foreground">{p.description}</p>
                <p className="mt-3 flex items-center gap-1 text-xs text-muted-foreground">
                  <MapPin className="h-3 w-3" /> {p.location} · {p.seller_name}
                </p>
                <div className="mt-auto flex items-end justify-between pt-4">
                  <p className="font-display text-xl text-forest">
                    ₦{Number(p.price).toLocaleString()}
                    <span className="text-xs text-muted-foreground">/{p.unit}</span>
                  </p>
                  <span className="text-xs text-muted-foreground">
                    {Number(p.quantity_available).toLocaleString()} {p.unit} available
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="rounded-xl border border-dashed border-border p-16 text-center">
            <p className="text-sm text-muted-foreground">No listings match your filters yet.</p>
            <Button variant="outline" className="mt-4" onClick={() => { setSearch(""); setCategory("all"); }}>
              Clear filters
            </Button>
          </div>
        )}
      </div>
    </PublicLayout>
  );
}

function CategoryChip({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-full border px-3.5 py-1.5 text-xs font-medium transition-colors ${
        active
          ? "border-forest bg-forest text-forest-foreground"
          : "border-border bg-background text-muted-foreground hover:border-forest/40 hover:text-foreground"
      }`}
    >
      {label}
    </button>
  );
}
