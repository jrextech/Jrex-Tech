import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Sun, Moon, Monitor, KeyRound, Bell, AlertTriangle, Loader2, Landmark } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { getStoredTheme, setTheme, type ThemeChoice } from "@/lib/theme";
import { PageHeading } from "@/components/dashboard/DashboardShell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { useServerFn } from "@tanstack/react-start";
import { getBankList } from "@/lib/payments.functions";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";

export const Route = createFileRoute("/_authenticated/dashboard/settings")({ component: Settings });

const THEME_OPTIONS: { value: ThemeChoice; label: string; icon: typeof Sun }[] = [
  { value: "light", label: "Light", icon: Sun },
  { value: "dark", label: "Dark", icon: Moon },
  { value: "system", label: "System", icon: Monitor },
];

const NOTIFICATION_KINDS: { key: "order" | "message" | "delivery"; label: string; hint: string }[] = [
  { key: "order", label: "Orders", hint: "New orders, and status changes on orders you placed or received." },
  { key: "message", label: "Messages & expert reviews", hint: "New messages, and expert reviews on your crop-health cases." },
  { key: "delivery", label: "Delivery jobs", hint: "New delivery jobs and status changes on jobs tied to your orders." },
];

function Settings() {
  const { user, roles } = useAuth();
  const uid = user?.id;
  const qc = useQueryClient();
  const [theme, setThemeState] = useState<ThemeChoice>(getStoredTheme());
  const needsPayout = roles.some((r) => ["farmer", "business", "transporter", "expert"].includes(r));

  const payoutAccount = useQuery({
    queryKey: ["payout-account", uid],
    enabled: !!uid && needsPayout,
    queryFn: async () =>
      (await supabase.from("payout_accounts").select("*").eq("user_id", uid!).maybeSingle()).data,
  });

  const doGetBankList = useServerFn(getBankList);
  const banks = useQuery({
    queryKey: ["bank-list"],
    enabled: needsPayout,
    staleTime: 1000 * 60 * 60, // bank list barely changes; cache for an hour
    queryFn: () => doGetBankList(),
  });
  const [bankCode, setBankCode] = useState("");

  useEffect(() => {
    if (payoutAccount.data?.bank_code) setBankCode(payoutAccount.data.bank_code);
  }, [payoutAccount.data?.bank_code]);

  const savePayout = useMutation({
    mutationFn: async (f: FormData) => {
      const selectedBank = (banks.data ?? []).find((b) => b.code === bankCode);
      if (!selectedBank) throw new Error("Choose your bank from the list.");
      const payload = {
        user_id: uid!,
        bank_name: selectedBank.name,
        bank_code: selectedBank.code,
        account_number: String(f.get("account_number") ?? "").trim(),
        account_name: String(f.get("account_name") ?? "").trim(),
        // Changing bank details invalidates any previously-created Paystack
        // transfer recipient — it must be recreated against the new account.
        paystack_recipient_code: null,
      };
      const { error } = await supabase.from("payout_accounts").upsert(payload);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Payout details saved");
      void qc.invalidateQueries({ queryKey: ["payout-account", uid] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const profile = useQuery({
    queryKey: ["profile-settings", uid],
    enabled: !!uid,
    queryFn: async () =>
      (await supabase.from("profiles").select("notification_prefs").eq("id", uid!).maybeSingle()).data,
  });

  const prefs = (profile.data?.notification_prefs as Record<string, boolean> | undefined) ?? {
    order: true,
    message: true,
    delivery: true,
  };

  const updatePrefs = useMutation({
    mutationFn: async (next: Record<string, boolean>) => {
      const { error } = await supabase.from("profiles").update({ notification_prefs: next }).eq("id", uid!);
      if (error) throw error;
    },
    onMutate: async (next) => {
      await qc.cancelQueries({ queryKey: ["profile-settings", uid] });
      qc.setQueryData(["profile-settings", uid], { notification_prefs: next });
    },
    onError: (e: Error) => toast.error(e.message),
    onSuccess: () => toast.success("Notification preferences saved"),
  });

  const changePassword = useMutation({
    mutationFn: async (password: string) => {
      const { error } = await supabase.auth.updateUser({ password });
      if (error) throw error;
    },
    onSuccess: () => toast.success("Password updated"),
    onError: (e: Error) => toast.error(e.message),
  });

  const requestDeletion = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("contact_messages").insert({
        name: (user?.user_metadata?.["full_name"] as string) || user?.email || "AGROVIAX user",
        email: user?.email ?? "",
        subject: "Account deletion request",
        body: `User ${uid} (${user?.email}) has requested their AGROVIAX account and all associated data be deleted.`,
      });
      if (error) throw error;
    },
    onSuccess: () =>
      toast.success("Deletion request sent. Our team will process it and confirm by email within a few days."),
    onError: (e: Error) => toast.error(e.message),
  });

  if (profile.isLoading) return <Skeleton className="h-72" />;

  return (
    <div className="max-w-2xl space-y-6">
      <PageHeading title="Settings" description="Appearance, notifications and account security." />

      <Card>
        <CardContent className="p-6">
          <h2 className="text-base font-semibold">Appearance</h2>
          <p className="mt-1 text-xs text-muted-foreground">Choose how AGROVIAX looks on this device.</p>
          <div className="mt-4 grid grid-cols-3 gap-2">
            {THEME_OPTIONS.map(({ value, label, icon: Icon }) => (
              <button
                key={value}
                type="button"
                onClick={() => {
                  setThemeState(value);
                  setTheme(value);
                }}
                className={`flex flex-col items-center gap-1.5 rounded-lg border p-3 text-xs font-medium transition-colors ${
                  theme === value ? "border-primary bg-primary/5 text-primary" : "border-border text-muted-foreground"
                }`}
              >
                <Icon className="h-4 w-4" />
                {label}
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <h2 className="flex items-center gap-2 text-base font-semibold">
            <Bell className="h-4 w-4" /> Notifications
          </h2>
          <p className="mt-1 text-xs text-muted-foreground">
            Control what shows up in your notification bell and, in future, email.
          </p>
          <div className="mt-4 divide-y divide-border">
            {NOTIFICATION_KINDS.map((n) => (
              <div key={n.key} className="flex items-center justify-between gap-4 py-3">
                <div>
                  <p className="text-sm font-medium">{n.label}</p>
                  <p className="text-xs text-muted-foreground">{n.hint}</p>
                </div>
                <Switch
                  checked={prefs[n.key] !== false}
                  onCheckedChange={(checked) => updatePrefs.mutate({ ...prefs, [n.key]: checked })}
                />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {needsPayout && (
        <Card>
          <CardContent className="p-6">
            <h2 className="flex items-center gap-2 text-base font-semibold">
              <Landmark className="h-4 w-4" /> Payout details
            </h2>
            <p className="mt-1 text-xs text-muted-foreground">
              Where AGROVIAX sends what you earn — required before you can publish a listing or accept a delivery job.
            </p>
            {payoutAccount.isLoading ? (
              <Skeleton className="mt-4 h-28" />
            ) : (
              <form
                className="mt-4 grid gap-3 sm:grid-cols-2"
                onSubmit={(e) => {
                  e.preventDefault();
                  savePayout.mutate(new FormData(e.currentTarget));
                }}
              >
                <div className="space-y-1.5">
                  <Label htmlFor="bank_name">Bank</Label>
                  <Select value={bankCode} onValueChange={setBankCode}>
                    <SelectTrigger id="bank_name">
                      <SelectValue placeholder={banks.isLoading ? "Loading banks…" : "Select your bank"} />
                    </SelectTrigger>
                    <SelectContent>
                      {(banks.data ?? []).map((b) => (
                        <SelectItem key={b.code} value={b.code}>
                          {b.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {banks.isError && (
                    <p className="text-xs text-destructive">
                      Couldn't load the bank list — check PAYSTACK_SECRET_KEY is set (see .env.example).
                    </p>
                  )}
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="account_number">Account number</Label>
                  <Input
                    id="account_number"
                    name="account_number"
                    inputMode="numeric"
                    defaultValue={payoutAccount.data?.account_number ?? ""}
                    required
                  />
                </div>
                <div className="space-y-1.5 sm:col-span-2">
                  <Label htmlFor="account_name">Account name</Label>
                  <Input id="account_name" name="account_name" defaultValue={payoutAccount.data?.account_name ?? ""} required />
                </div>
                <Button type="submit" disabled={savePayout.isPending} className="sm:col-span-2 sm:w-fit">
                  {savePayout.isPending ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : null}
                  {payoutAccount.data ? "Update payout details" : "Save payout details"}
                </Button>
              </form>
            )}
          </CardContent>
        </Card>
      )}

      <Card>
        <CardContent className="p-6">
          <h2 className="flex items-center gap-2 text-base font-semibold">
            <KeyRound className="h-4 w-4" /> Security
          </h2>
          <p className="mt-1 text-xs text-muted-foreground">Signed in as {user?.email}.</p>
          <form
            className="mt-4 flex flex-wrap items-end gap-3"
            onSubmit={(e) => {
              e.preventDefault();
              const f = new FormData(e.currentTarget);
              const next = String(f.get("password"));
              if (next.length < 6) {
                toast.error("Password must be at least 6 characters.");
                return;
              }
              changePassword.mutate(next);
              e.currentTarget.reset();
            }}
          >
            <div className="space-y-1.5">
              <Label htmlFor="password">New password</Label>
              <Input id="password" name="password" type="password" placeholder="••••••••" className="w-56" />
            </div>
            <Button type="submit" variant="outline" disabled={changePassword.isPending}>
              {changePassword.isPending ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : null}
              Update password
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card className="border-destructive/30">
        <CardContent className="p-6">
          <h2 className="flex items-center gap-2 text-base font-semibold text-destructive">
            <AlertTriangle className="h-4 w-4" /> Danger zone
          </h2>
          <p className="mt-1 text-xs text-muted-foreground">
            Deleting your account removes your farms, listings, cases and messages. This can't be undone, so it's
            handled by a person rather than instantly — we'll confirm by email before anything is removed.
          </p>
          <Button
            variant="outline"
            className="mt-4 border-destructive/40 text-destructive hover:bg-destructive/10"
            disabled={requestDeletion.isPending}
            onClick={() => {
              if (confirm("Request deletion of your AGROVIAX account and all its data?")) {
                requestDeletion.mutate();
              }
            }}
          >
            Request account deletion
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
