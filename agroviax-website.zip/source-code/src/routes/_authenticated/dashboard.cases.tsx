import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { ScanLine, Stethoscope, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { PageHeading, EmptyState } from "@/components/dashboard/DashboardShell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";

export const Route = createFileRoute("/_authenticated/dashboard/cases")({ component: Cases });

function Cases() {
  const { user } = useAuth();
  const uid = user?.id;
  const qc = useQueryClient();

  const cases = useQuery({
    queryKey: ["my-cases", uid],
    enabled: !!uid,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("disease_cases")
        .select("*, expert_reviews(id, diagnosis, recommendation, created_at)")
        .eq("farmer_id", uid!)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  const requestExpert = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("disease_cases").update({ status: "expert_requested" }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Expert review requested");
      void qc.invalidateQueries({ queryKey: ["my-cases", uid] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("disease_cases").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Case deleted");
      void qc.invalidateQueries({ queryKey: ["my-cases", uid] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (cases.isLoading) return <Skeleton className="h-72" />;

  return (
    <div>
      <PageHeading
        title="Crop health cases"
        description="Every photo you analysed, the AI diagnosis and any expert follow-up."
        action={
          <Button asChild>
            <Link to="/crop-health">
              <ScanLine className="mr-2 h-4 w-4" /> New scan
            </Link>
          </Button>
        }
      />

      {(cases.data ?? []).length === 0 ? (
        <EmptyState
          title="No cases yet"
          body="Scan a photo of an affected leaf, stem or fruit and the case will be saved here with its diagnosis."
          action={
            <Button asChild>
              <Link to="/crop-health">Scan a crop photo</Link>
            </Button>
          }
        />
      ) : (
        <div className="space-y-4">
          {(cases.data ?? []).map((c) => {
            const reviews = (c as unknown as { expert_reviews: { id: string; diagnosis: string; recommendation: string }[] })
              .expert_reviews;
            return (
              <Card key={c.id}>
                <CardContent className="p-5">
                  <div className="flex flex-wrap items-start gap-4">
                    {c.media_url && (
                      <img
                        src={c.media_url}
                        alt={`${c.crop_type} case photo`}
                        className="h-24 w-24 shrink-0 rounded-lg border border-border object-cover"
                      />
                    )}
                    <div className="flex-1">
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div>
                          <h2 className="text-base font-semibold">
                            {c.ai_disease ?? "Analysis pending"} · {c.crop_type}
                          </h2>
                          <p className="mt-1 text-xs text-muted-foreground">
                            {new Date(c.created_at).toLocaleString()}
                            {c.ai_confidence ? ` · ${Math.round(Number(c.ai_confidence))}% confidence` : ""}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="secondary" className="capitalize">
                            {c.status.replace(/_/g, " ")}
                          </Badge>
                          <Button variant="ghost" size="sm" onClick={() => remove.mutate(c.id)}>
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>

                  {c.ai_summary && <p className="mt-3 text-sm text-muted-foreground">{c.ai_summary}</p>}
                  {c.ai_treatment && (
                    <p className="mt-2 text-sm">
                      <span className="font-medium">Treatment: </span>
                      <span className="text-muted-foreground">{c.ai_treatment}</span>
                    </p>
                  )}
                  {c.ai_prevention && (
                    <p className="mt-2 text-sm">
                      <span className="font-medium">Prevention: </span>
                      <span className="text-muted-foreground">{c.ai_prevention}</span>
                    </p>
                  )}

                  {reviews?.length > 0 && (
                    <div className="mt-4 rounded-lg border border-border bg-secondary/40 p-4">
                      <p className="flex items-center gap-2 text-sm font-medium">
                        <Stethoscope className="h-4 w-4 text-primary" /> Expert review
                      </p>
                      {reviews.map((r) => (
                        <div key={r.id} className="mt-2 text-sm text-muted-foreground">
                          <p>
                            <span className="font-medium text-foreground">Diagnosis: </span>
                            {r.diagnosis}
                          </p>
                          <p className="mt-1">
                            <span className="font-medium text-foreground">Recommendation: </span>
                            {r.recommendation}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}

                  {c.status === "analyzed" && (
                    <Button variant="outline" size="sm" className="mt-4" onClick={() => requestExpert.mutate(c.id)}>
                      <Stethoscope className="mr-1.5 h-4 w-4" /> Request expert review
                    </Button>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
