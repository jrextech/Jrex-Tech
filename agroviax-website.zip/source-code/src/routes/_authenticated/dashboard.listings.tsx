import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus, Trash2, Pencil, Eye, EyeOff, Upload, Loader2, ImageOff } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { PageHeading, EmptyState } from "@/components/dashboard/DashboardShell";
import { SmartImage } from "@/components/site/SmartImage";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { naira } from "@/lib/cart";
import { NIGERIAN_STATES } from "@/lib/suggestions";

const MAX_IMAGE_BYTES = 5 * 1024 * 1024;

export const Route = createFileRoute("/_authenticated/dashboard/listings")({ component: Listings });

type Product = {
  id: string;
  title: string;
  description: string | null;
  price: number;
  unit: string;
  quantity_available: number;
  location: string;
  image_url: string | null;
  organic: boolean;
  status: string;
  category_slug: string;
  seller_name: string;
  transport_option: "seller_provides" | "need_transport";
  weight_kg: number | null;
};

function Listings() {
  const { user } = useAuth();
  const uid = user?.id;
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Product | null>(null);
  const [organic, setOrganic] = useState(false);
  const [category, setCategory] = useState("grains");
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [transportOption, setTransportOption] = useState<"seller_provides" | "need_transport">("seller_provides");

  const payoutAccount = useQuery({
    queryKey: ["payout-account", uid],
    enabled: !!uid,
    queryFn: async () => (await supabase.from("payout_accounts").select("user_id").eq("user_id", uid!).maybeSingle()).data,
  });
  const hasPayoutAccount = !!payoutAccount.data;

  const categories = useQuery({
    queryKey: ["categories"],
    queryFn: async () => {
      const { data } = await supabase.from("categories").select("slug, name, kind").order("name");
      return data ?? [];
    },
  });

  const listings = useQuery({
    queryKey: ["my-listings", uid],
    enabled: !!uid,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("products")
        .select("*")
        .eq("seller_id", uid!)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as Product[];
    },
  });

  const save = useMutation({
    mutationFn: async (form: Record<string, FormDataEntryValue | null>) => {
      if (!hasPayoutAccount) throw new Error("Set up your payout details in Settings before publishing a listing.");
      const { data: profile } = await supabase.from("profiles").select("full_name").eq("id", uid!).maybeSingle();
      const payload = {
        title: String(form["title"]),
        description: String(form["description"] ?? ""),
        price: Number(form["price"]),
        unit: String(form["unit"]),
        quantity_available: Number(form["quantity_available"]),
        location: String(form["location"]),
        image_url: imageUrl,
        organic,
        category_slug: category,
        transport_option: transportOption,
        weight_kg: form["weight_kg"] ? Number(form["weight_kg"]) : null,
      };
      if (editing) {
        const { error } = await supabase.from("products").update(payload).eq("id", editing.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("products").insert({
          ...payload,
          seller_id: uid!,
          seller_name:
            profile?.full_name ?? (user?.user_metadata?.["full_name"] as string) ?? user?.email ?? "AGROVIAX seller",
          currency: "NGN",
          status: "active",
        });
        if (error) throw error;
      }
    },
    onSuccess: () => {
      toast.success(editing ? "Listing updated" : "Listing published");
      setOpen(false);
      setEditing(null);
      void qc.invalidateQueries({ queryKey: ["my-listings", uid] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const toggleStatus = useMutation({
    mutationFn: async (p: Product) => {
      const { error } = await supabase
        .from("products")
        .update({ status: p.status === "active" ? "paused" : "active" })
        .eq("id", p.id);
      if (error) throw error;
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["my-listings", uid] }),
    onError: (e: Error) => toast.error(e.message),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("products").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Listing deleted");
      void qc.invalidateQueries({ queryKey: ["my-listings", uid] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const uploadImage = useMutation({
    mutationFn: async (file: File) => {
      if (!file.type.startsWith("image/")) throw new Error("Please choose an image file.");
      if (file.size > MAX_IMAGE_BYTES) throw new Error("Image must be under 5MB.");
      const path = `${uid}/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9.\-_]/g, "_")}`;
      const { error } = await supabase.storage.from("product-media").upload(path, file, {
        contentType: file.type,
        upsert: false,
      });
      if (error) throw error;
      const { data } = supabase.storage.from("product-media").getPublicUrl(path);
      return data.publicUrl;
    },
    onSuccess: (url) => setImageUrl(url),
    onError: (e: Error) => toast.error(e.message || "Upload failed. Please try again."),
  });

  const openNew = () => {
    setEditing(null);
    setOrganic(false);
    setCategory("grains");
    setImageUrl(null);
    setTransportOption("seller_provides");
    setOpen(true);
  };

  const openEdit = (p: Product) => {
    setEditing(p);
    setOrganic(p.organic);
    setCategory(p.category_slug);
    setImageUrl(p.image_url);
    setTransportOption(p.transport_option);
    setOpen(true);
  };

  return (
    <div>
      <PageHeading
        title="My listings"
        description="Everything you have for sale on the AGROVIAX marketplace."
        action={
          <Button onClick={openNew} disabled={payoutAccount.isLoading}>
            <Plus className="mr-2 h-4 w-4" /> New listing
          </Button>
        }
      />

      {!payoutAccount.isLoading && !hasPayoutAccount && (
        <div className="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-amber-300 bg-amber-50 px-4 py-3 text-sm text-amber-900 dark:border-amber-900 dark:bg-amber-950 dark:text-amber-200">
          <span>Add your payout bank details before publishing a listing, so buyers' payments can reach you.</span>
          <Button asChild size="sm" variant="outline">
            <Link to="/dashboard/settings">Set up payout details</Link>
          </Button>
        </div>
      )}

      {listings.isLoading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-64" />
          ))}
        </div>
      ) : (listings.data ?? []).length === 0 ? (
        <EmptyState
          title="You have no listings yet"
          body="Publish your harvested produce or agricultural inputs so buyers can find and order from you."
          action={
            <Button onClick={openNew}>
              <Plus className="mr-2 h-4 w-4" /> Create your first listing
            </Button>
          }
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {(listings.data ?? []).map((p) => (
            <Card key={p.id} className="overflow-hidden">
              <SmartImage src={p.image_url} alt={p.title} className="h-40 w-full object-cover" width={600} height={400} />
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <h2 className="text-base font-semibold">{p.title}</h2>
                  <Badge variant={p.status === "active" ? "default" : "secondary"} className="capitalize">
                    {p.status}
                  </Badge>
                </div>
                <p className="mt-1 text-xs text-muted-foreground">
                  {p.location} · {p.quantity_available} {p.unit} available
                </p>
                <p className="mt-2 font-display text-lg text-forest">
                  {naira(p.price)}
                  <span className="text-xs text-muted-foreground">/{p.unit}</span>
                </p>
                <div className="mt-4 flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => openEdit(p)}>
                    <Pencil className="mr-1.5 h-3.5 w-3.5" /> Edit
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => toggleStatus.mutate(p)}>
                    {p.status === "active" ? (
                      <>
                        <EyeOff className="mr-1.5 h-3.5 w-3.5" /> Pause
                      </>
                    ) : (
                      <>
                        <Eye className="mr-1.5 h-3.5 w-3.5" /> Publish
                      </>
                    )}
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => remove.mutate(p.id)}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit listing" : "New listing"}</DialogTitle>
          </DialogHeader>
          <form
            className="space-y-4"
            onSubmit={(e) => {
              e.preventDefault();
              const f = new FormData(e.currentTarget);
              save.mutate(Object.fromEntries(f.entries()));
            }}
          >
            <div className="space-y-1.5">
              <Label htmlFor="title">Title</Label>
              <Input id="title" name="title" defaultValue={editing?.title ?? ""} required />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="description">Description</Label>
              <Textarea id="description" name="description" rows={3} defaultValue={editing?.description ?? ""} />
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="price">Price (₦)</Label>
                <Input id="price" name="price" type="number" step="0.01" defaultValue={String(editing?.price ?? "")} required />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="unit">Unit</Label>
                <Input id="unit" name="unit" defaultValue={editing?.unit ?? "kg"} required />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="quantity_available">Quantity</Label>
                <Input
                  id="quantity_available"
                  name="quantity_available"
                  type="number"
                  defaultValue={String(editing?.quantity_available ?? "")}
                  required
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="location">Location</Label>
              <Input id="location" name="location" list="ng-state-suggestions" defaultValue={editing?.location ?? ""} required />
              <datalist id="ng-state-suggestions">
                {NIGERIAN_STATES.map((s) => (
                  <option key={s} value={s} />
                ))}
              </datalist>
            </div>
            <div className="space-y-1.5">
              <Label>Category</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {(categories.data ?? []).map((c) => (
                    <SelectItem key={c.slug} value={c.slug}>
                      {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="listing-photo">Photo</Label>
              <div className="flex items-center gap-3">
                <div className="flex h-20 w-20 shrink-0 items-center justify-center overflow-hidden rounded-lg border border-dashed border-border bg-muted">
                  {uploadImage.isPending ? (
                    <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                  ) : imageUrl ? (
                    <img src={imageUrl} alt="Listing preview" className="h-full w-full object-cover" />
                  ) : (
                    <ImageOff className="h-5 w-5 text-muted-foreground" />
                  )}
                </div>
                <div className="flex flex-col gap-1.5">
                  <Button type="button" variant="outline" size="sm" disabled={uploadImage.isPending} asChild>
                    <label htmlFor="listing-photo" className="cursor-pointer">
                      <Upload className="mr-1.5 h-3.5 w-3.5" />
                      {imageUrl ? "Replace photo" : "Upload photo"}
                    </label>
                  </Button>
                  {imageUrl && (
                    <button
                      type="button"
                      onClick={() => setImageUrl(null)}
                      className="text-left text-xs text-muted-foreground hover:text-destructive"
                    >
                      Remove photo
                    </button>
                  )}
                  <input
                    id="listing-photo"
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) uploadImage.mutate(file);
                      e.target.value = "";
                    }}
                  />
                </div>
              </div>
              <p className="text-xs text-muted-foreground">JPG or PNG, up to 5MB. Shows on the public marketplace.</p>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="weight_kg">Weight per unit (kg)</Label>
              <Input
                id="weight_kg"
                name="weight_kg"
                type="number"
                min={0}
                step="0.1"
                placeholder="e.g. 25"
                defaultValue={editing?.weight_kg ?? ""}
              />
              <p className="text-xs text-muted-foreground">
                Used to work out a fair transport fee — a sack of yams needs a bigger vehicle than a crate of tomatoes.
              </p>
            </div>

            <div className="space-y-1.5">
              <Label>Transport</Label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setTransportOption("seller_provides")}
                  className={`rounded-lg border p-3 text-left text-xs font-medium transition-colors ${
                    transportOption === "seller_provides" ? "border-primary bg-primary/5 text-primary" : "border-border text-muted-foreground"
                  }`}
                >
                  I already have a transporter
                  <span className="mt-0.5 block font-normal text-muted-foreground">No AGROVIAX delivery fee — you arrange delivery yourself.</span>
                </button>
                <button
                  type="button"
                  onClick={() => setTransportOption("need_transport")}
                  className={`rounded-lg border p-3 text-left text-xs font-medium transition-colors ${
                    transportOption === "need_transport" ? "border-primary bg-primary/5 text-primary" : "border-border text-muted-foreground"
                  }`}
                >
                  I need a transporter
                  <span className="mt-0.5 block font-normal text-muted-foreground">Buyers can request AGROVIAX delivery; the job appears to transporters.</span>
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between rounded-lg border border-border p-3">
              <Label htmlFor="organic">Organically grown</Label>
              <Switch id="organic" checked={organic} onCheckedChange={setOrganic} />
            </div>
            <DialogFooter>
              <Button type="submit" disabled={save.isPending || uploadImage.isPending}>
                {save.isPending ? "Saving…" : editing ? "Save changes" : "Publish listing"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
