import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus, Trash2, Sprout, Pencil } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { PageHeading, EmptyState } from "@/components/dashboard/DashboardShell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { NIGERIAN_STATES, COMMON_CROPS } from "@/lib/suggestions";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export const Route = createFileRoute("/_authenticated/dashboard/farms")({ component: Farms });

type Farm = {
  id: string;
  name: string;
  location: string;
  size: number;
  size_unit: string;
  soil_type: string | null;
  irrigation_method: string | null;
  description: string | null;
};

const CROP_STATUS = ["planned", "planted", "growing", "ready_for_harvest", "harvested", "completed"] as const;

function Farms() {
  const { user } = useAuth();
  const uid = user?.id;
  const qc = useQueryClient();
  const [editing, setEditing] = useState<Farm | null>(null);
  const [farmOpen, setFarmOpen] = useState(false);

  const farmsQuery = useQuery({
    queryKey: ["farms", uid],
    enabled: !!uid,
    queryFn: async () => {
      const { data, error } = await supabase.from("farms").select("*").eq("owner_id", uid!).order("created_at");
      if (error) throw error;
      return data as Farm[];
    },
  });

  const cropsQuery = useQuery({
    queryKey: ["crops", uid],
    enabled: !!uid,
    queryFn: async () => {
      const { data, error } = await supabase.from("crops").select("*").eq("owner_id", uid!).order("created_at");
      if (error) throw error;
      return data;
    },
  });

  const saveFarm = useMutation({
    mutationFn: async (form: Partial<Farm>) => {
      if (editing) {
        const { error } = await supabase.from("farms").update(form).eq("id", editing.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("farms").insert({
          owner_id: uid!,
          name: form.name!,
          location: form.location!,
          size: form.size ?? 1,
          size_unit: form.size_unit ?? "hectares",
          soil_type: form.soil_type ?? null,
          irrigation_method: form.irrigation_method ?? null,
          description: form.description ?? null,
        });
        if (error) throw error;
      }
    },
    onSuccess: () => {
      toast.success(editing ? "Farm updated" : "Farm added");
      setFarmOpen(false);
      setEditing(null);
      void qc.invalidateQueries({ queryKey: ["farms", uid] });
      void qc.invalidateQueries({ queryKey: ["dashboard-overview", uid] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const deleteFarm = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("farms").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Farm removed");
      void qc.invalidateQueries({ queryKey: ["farms", uid] });
      void qc.invalidateQueries({ queryKey: ["crops", uid] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const addCrop = useMutation({
    mutationFn: async (form: { farm_id: string; crop_type: string; variety: string; planting_date: string; expected_yield: string }) => {
      const { error } = await supabase.from("crops").insert({
        owner_id: uid!,
        farm_id: form.farm_id,
        crop_type: form.crop_type,
        variety: form.variety || null,
        planting_date: form.planting_date || null,
        expected_yield: form.expected_yield ? Number(form.expected_yield) : null,
        status: "planted",
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Crop cycle added");
      void qc.invalidateQueries({ queryKey: ["crops", uid] });
      void qc.invalidateQueries({ queryKey: ["dashboard-overview", uid] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const updateCropStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { error } = await supabase
        .from("crops")
        .update({ status: status as (typeof CROP_STATUS)[number] })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Crop status updated");
      void qc.invalidateQueries({ queryKey: ["crops", uid] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const deleteCrop = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("crops").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Crop removed");
      void qc.invalidateQueries({ queryKey: ["crops", uid] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const openNew = () => {
    setEditing(null);
    setFarmOpen(true);
  };

  return (
    <div>
      <datalist id="ng-state-suggestions">
        {NIGERIAN_STATES.map((s) => (
          <option key={s} value={s} />
        ))}
      </datalist>
      <datalist id="crop-name-suggestions">
        {COMMON_CROPS.map((c) => (
          <option key={c} value={c} />
        ))}
      </datalist>
      <PageHeading
        title="Farms & crops"
        description="Register each farm, then track the crop cycles growing on it."
        action={
          <Dialog open={farmOpen} onOpenChange={setFarmOpen}>
            <DialogTrigger asChild>
              <Button onClick={openNew}>
                <Plus className="mr-2 h-4 w-4" /> Add farm
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{editing ? "Edit farm" : "Add a farm"}</DialogTitle>
              </DialogHeader>
              <form
                className="space-y-4"
                onSubmit={(e) => {
                  e.preventDefault();
                  const f = new FormData(e.currentTarget);
                  saveFarm.mutate({
                    name: String(f.get("name")),
                    location: String(f.get("location")),
                    size: Number(f.get("size")),
                    size_unit: String(f.get("size_unit")),
                    soil_type: String(f.get("soil_type")) || null,
                    irrigation_method: String(f.get("irrigation_method")) || null,
                    description: String(f.get("description")) || null,
                  });
                }}
              >
                <Field label="Farm name" name="name" defaultValue={editing?.name} required />
                <Field label="Location" name="location" defaultValue={editing?.location} list="ng-state-suggestions" required />
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Size" name="size" type="number" step="0.1" defaultValue={String(editing?.size ?? 1)} required />
                  <Field label="Unit" name="size_unit" defaultValue={editing?.size_unit ?? "hectares"} required />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Soil type" name="soil_type" defaultValue={editing?.soil_type ?? ""} />
                  <Field label="Irrigation" name="irrigation_method" defaultValue={editing?.irrigation_method ?? ""} />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="description">Notes</Label>
                  <Textarea id="description" name="description" defaultValue={editing?.description ?? ""} rows={3} />
                </div>
                <DialogFooter>
                  <Button type="submit" disabled={saveFarm.isPending}>
                    {saveFarm.isPending ? "Saving…" : "Save farm"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        }
      />

      {farmsQuery.isLoading ? (
        <div className="grid gap-4">
          <Skeleton className="h-40" />
          <Skeleton className="h-40" />
        </div>
      ) : (farmsQuery.data ?? []).length === 0 ? (
        <EmptyState
          title="No farms registered yet"
          body="Add your first farm to start recording crop cycles, activities, harvests and costs."
          action={
            <Button onClick={openNew}>
              <Plus className="mr-2 h-4 w-4" /> Add your first farm
            </Button>
          }
        />
      ) : (
        <div className="space-y-5">
          {(farmsQuery.data ?? []).map((farm) => {
            const crops = (cropsQuery.data ?? []).filter((c) => c.farm_id === farm.id);
            return (
              <Card key={farm.id}>
                <CardContent className="p-5">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <h2 className="text-lg font-semibold">{farm.name}</h2>
                      <p className="text-sm text-muted-foreground">
                        {farm.location} · {farm.size} {farm.size_unit}
                        {farm.soil_type ? ` · ${farm.soil_type} soil` : ""}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setEditing(farm);
                          setFarmOpen(true);
                        }}
                      >
                        <Pencil className="mr-1.5 h-3.5 w-3.5" /> Edit
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => deleteFarm.mutate(farm.id)}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>

                  {farm.description && <p className="mt-3 text-sm text-muted-foreground">{farm.description}</p>}

                  <div className="mt-5 rounded-lg border border-border">
                    <div className="flex items-center justify-between border-b border-border px-4 py-2.5">
                      <p className="flex items-center gap-2 text-sm font-medium">
                        <Sprout className="h-4 w-4 text-primary" /> Crop cycles ({crops.length})
                      </p>
                    </div>

                    {crops.length > 0 && (
                      <ul className="divide-y divide-border">
                        {crops.map((c) => (
                          <li key={c.id} className="flex flex-wrap items-center justify-between gap-3 px-4 py-3">
                            <div>
                              <p className="text-sm font-medium">
                                {c.crop_type}
                                {c.variety ? ` · ${c.variety}` : ""}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {c.planting_date ? `Planted ${new Date(c.planting_date).toLocaleDateString()}` : "Not planted yet"}
                                {c.expected_yield ? ` · target ${c.expected_yield}kg` : ""}
                              </p>
                            </div>
                            <div className="flex items-center gap-2">
                              <Select
                                value={c.status}
                                onValueChange={(status) => updateCropStatus.mutate({ id: c.id, status })}
                              >
                                <SelectTrigger className="h-8 w-44 text-xs capitalize">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  {CROP_STATUS.map((s) => (
                                    <SelectItem key={s} value={s} className="capitalize">
                                      {s.replace(/_/g, " ")}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <Button variant="ghost" size="sm" onClick={() => deleteCrop.mutate(c.id)}>
                                <Trash2 className="h-3.5 w-3.5" />
                              </Button>
                            </div>
                          </li>
                        ))}
                      </ul>
                    )}

                    <form
                      className="grid gap-2 border-t border-border p-3 sm:grid-cols-5"
                      onSubmit={(e) => {
                        e.preventDefault();
                        const form = e.currentTarget;
                        const f = new FormData(form);
                        addCrop.mutate({
                          farm_id: farm.id,
                          crop_type: String(f.get("crop_type")),
                          variety: String(f.get("variety")),
                          planting_date: String(f.get("planting_date")),
                          expected_yield: String(f.get("expected_yield")),
                        });
                        form.reset();
                      }}
                    >
                      <Input name="crop_type" placeholder="Crop (e.g. Maize)" list="crop-name-suggestions" required className="h-9" />
                      <Input name="variety" placeholder="Variety" className="h-9" />
                      <Input name="planting_date" type="date" className="h-9" />
                      <Input name="expected_yield" type="number" placeholder="Target yield (kg)" className="h-9" />
                      <Button type="submit" variant="secondary" className="h-9">
                        <Plus className="mr-1.5 h-4 w-4" /> Add crop
                      </Button>
                    </form>
                  </div>

                  <div className="mt-3 flex flex-wrap gap-2">
                    <Badge variant="secondary">
                      {crops.filter((c) => c.status === "harvested" || c.status === "completed").length} harvested
                    </Badge>
                    <Badge variant="secondary">
                      {crops.filter((c) => c.status === "growing").length} growing
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}

function Field({
  label,
  name,
  defaultValue,
  type = "text",
  required,
  step,
  list,
}: {
  label: string;
  name: string;
  defaultValue?: string | undefined;
  type?: string;
  required?: boolean;
  step?: string;
  list?: string;
}) {
  return (
    <div className="space-y-1.5">
      <Label htmlFor={name}>{label}</Label>
      <Input id={name} name={name} type={type} step={step} list={list} defaultValue={defaultValue ?? ""} required={required} />
    </div>
  );
}
