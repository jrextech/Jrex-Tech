import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Send } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { PageHeading, EmptyState } from "@/components/dashboard/DashboardShell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";

export const Route = createFileRoute("/_authenticated/dashboard/messages")({ component: Messages });

function Messages() {
  const { user } = useAuth();
  const uid = user?.id;
  const qc = useQueryClient();
  const [active, setActive] = useState<string | null>(null);

  const messages = useQuery({
    queryKey: ["messages", uid],
    enabled: !!uid,
    queryFn: async () => {
      const { data, error } = await supabase.from("messages").select("*").order("created_at");
      if (error) throw error;
      const rows = data ?? [];
      const otherIds = Array.from(new Set(rows.map((m) => (m.sender_id === uid ? m.recipient_id : m.sender_id))));
      let names = new Map<string, string>();
      if (otherIds.length > 0) {
        const { data: profiles } = await supabase.from("profiles").select("id, full_name, organization").in("id", otherIds);
        names = new Map((profiles ?? []).map((p) => [p.id, p.organization || p.full_name || "AGROVIAX user"]));
      }
      return { rows, names };
    },
  });

  const send = useMutation({
    mutationFn: async ({ recipient, body }: { recipient: string; body: string }) => {
      const { error } = await supabase.from("messages").insert({ sender_id: uid!, recipient_id: recipient, body });
      if (error) throw error;
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["messages", uid] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (messages.isLoading) return <Skeleton className="h-72" />;

  const rows = messages.data?.rows ?? [];
  const names = messages.data?.names ?? new Map<string, string>();
  const partners = Array.from(new Set(rows.map((m) => (m.sender_id === uid ? m.recipient_id : m.sender_id))));
  // Most recently active conversation first
  partners.sort((a, b) => {
    const lastA = rows.filter((m) => m.sender_id === a || m.recipient_id === a).at(-1)?.created_at ?? "";
    const lastB = rows.filter((m) => m.sender_id === b || m.recipient_id === b).at(-1)?.created_at ?? "";
    return lastB.localeCompare(lastA);
  });
  const current = active ?? partners[0] ?? null;
  const thread = rows.filter((m) => m.sender_id === current || m.recipient_id === current);

  return (
    <div>
      <PageHeading title="Messages" description="Conversations with buyers, sellers, experts and transporters." />

      {partners.length === 0 ? (
        <EmptyState
          title="No conversations yet"
          body="Messages you exchange about orders, listings and crop-health cases will appear here."
        />
      ) : (
        <div className="grid gap-4 lg:grid-cols-[16rem_1fr]">
          <Card>
            <CardContent className="p-2">
              {partners.map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setActive(p)}
                  className={`w-full rounded-md px-3 py-2 text-left text-sm ${p === current ? "bg-secondary" : "hover:bg-secondary/60"}`}
                >
                  <span className="truncate text-sm font-medium">{names.get(p) ?? "AGROVIAX user"}</span>
                </button>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex h-[28rem] flex-col p-4">
              {current && (
                <p className="mb-2 border-b border-border pb-2 text-sm font-semibold">
                  {names.get(current) ?? "AGROVIAX user"}
                </p>
              )}
              <div className="flex-1 space-y-2 overflow-y-auto">
                {thread.map((m) => (
                  <div
                    key={m.id}
                    className={`max-w-[75%] rounded-lg px-3 py-2 text-sm ${
                      m.sender_id === uid ? "ml-auto bg-primary text-primary-foreground" : "bg-secondary"
                    }`}
                  >
                    {m.body}
                  </div>
                ))}
              </div>
              <form
                className="mt-3 flex gap-2"
                onSubmit={(e) => {
                  e.preventDefault();
                  const form = e.currentTarget;
                  const body = String(new FormData(form).get("body"));
                  if (current && body.trim()) send.mutate({ recipient: current, body });
                  form.reset();
                }}
              >
                <Input name="body" placeholder="Write a message…" className="h-9" />
                <Button type="submit" size="sm" className="h-9">
                  <Send className="h-4 w-4" />
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
