import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Building2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { PageHeading, EmptyState } from "@/components/dashboard/DashboardShell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { naira } from "@/lib/cart";

export const Route = createFileRoute("/_authenticated/dashboard/partner")({ component: PartnerPortal });

// A partner's own driver/vehicle aren't AGROVIAX-verified — this is
// operational text the partner company reports, not a verified record.
const STATUS = ["going_to_pickup", "picked_up", "in_transit", "near_destination", "arrived", "delivered"] as const;

function PartnerPortal() {
  const { user } = useAuth();
  const uid = user?.id;
  const qc = useQueryClient();

  const membership = useQuery({
    queryKey: ["partner-membership", uid],
    enabled: !!uid,
    queryFn: async () =>
      (await supabase.from("logistics_partner_staff").select("*, logistics_partners(*)").eq("user_id", uid!).maybeSingle()).data,
  });

  const partnerId = membership.data?.partner_id;

  const jobs = useQuery({
    queryKey: ["partner-jobs", partnerId],
    enabled: !!partnerId,
    queryFn: async () =>
      (await supabase.from("deliveries").select("*").eq("partner_id", partnerId!).order("created_at", { ascending: false })).data ?? [],
  });

  const assignOurDriver = useMutation({
    mutationFn: async ({ id, name, vehicle }: { id: string; name: string; vehicle: string }) => {
      const { error } = await supabase
        .from("deliveries")
        .update({ partner_driver_name: name, partner_vehicle_info: vehicle, status: "going_to_pickup" })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Driver assigned on your side");
      void qc.invalidateQueries({ queryKey: ["partner-jobs", partnerId] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const setStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const patch: Record<string, unknown> = { status };
      if (status === "picked_up") patch.pickup_confirmed_at = new Date().toISOString();
      if (status === "delivered") patch.delivery_confirmed_at = new Date().toISOString();
      const { error } = await supabase.from("deliveries").update(patch).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Status updated");
      void qc.invalidateQueries({ queryKey: ["partner-jobs", partnerId] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (membership.isLoading) return <Skeleton className="h-72" />;

  if (!membership.data) {
    return (
      <EmptyState
        title="No partner account linked"
        body="This login isn't linked to a logistics partner company yet — contact AGROVIAX if you believe this is a mistake."
      />
    );
  }

  const list = jobs.data ?? [];
  const active = list.filter((d) => d.status !== "delivered" && d.status !== "cancelled");
  const past = list.filter((d) => d.status === "delivered" || d.status === "cancelled");

  return (
    <div>
      <PageHeading
        title={`${membership.data.logistics_partners?.company_name ?? "Partner"} — Delivery jobs`}
        description="Only jobs AGROVIAX has routed to your company appear here."
      />

      <div className="mb-5 flex items-center gap-2 rounded-lg border border-border bg-secondary/30 px-4 py-2.5 text-sm">
        <Building2 className="h-4 w-4 text-primary" />
        Signed in as {membership.data.display_name}{membership.data.role_title ? ` · ${membership.data.role_title}` : ""}
      </div>

      <h2 className="text-lg font-semibold">Active jobs</h2>
      {active.length === 0 ? (
        <div className="mt-3">
          <EmptyState title="Nothing routed to you right now" body="New jobs AGROVIAX assigns to your company will appear here." />
        </div>
      ) : (
        <div className="mt-3 space-y-3">
          {active.map((d) => (
            <Card key={d.id}>
              <CardContent className="p-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="text-sm font-medium">
                      {d.pickup_location} → {d.dropoff_location}
                    </p>
                    <p className="text-xs text-muted-foreground">Fee {naira(d.fee)}</p>
                  </div>
                  <Badge variant="secondary" className="capitalize">
                    {d.status.replace(/_/g, " ")}
                  </Badge>
                </div>

                <form
                  className="mt-3 grid gap-2 sm:grid-cols-2"
                  onSubmit={(e) => {
                    e.preventDefault();
                    const f = new FormData(e.currentTarget);
                    assignOurDriver.mutate({
                      id: d.id,
                      name: String(f.get("driver_name") ?? "").trim(),
                      vehicle: String(f.get("vehicle_info") ?? "").trim(),
                    });
                  }}
                >
                  <Input name="driver_name" placeholder="Your driver's name" defaultValue={d.partner_driver_name ?? ""} className="h-9" />
                  <Input name="vehicle_info" placeholder="Vehicle info" defaultValue={d.partner_vehicle_info ?? ""} className="h-9" />
                  <Button type="submit" size="sm" variant="outline" className="sm:col-span-2 sm:w-fit">
                    Save driver &amp; vehicle
                  </Button>
                </form>

                <div className="mt-3">
                  <Label className="text-xs">Update status</Label>
                  <Select value={d.status} onValueChange={(status) => setStatus.mutate({ id: d.id, status })}>
                    <SelectTrigger className="mt-1 h-9 w-48 text-xs capitalize">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {STATUS.map((s) => (
                        <SelectItem key={s} value={s} className="capitalize">
                          {s.replace(/_/g, " ")}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {past.length > 0 && (
        <>
          <h2 className="mt-8 text-lg font-semibold">History</h2>
          <div className="mt-3 space-y-2">
            {past.map((d) => (
              <Card key={d.id}>
                <CardContent className="flex flex-wrap items-center justify-between gap-3 p-4">
                  <p className="text-sm">
                    {d.pickup_location} → {d.dropoff_location}
                  </p>
                  <Badge variant="outline" className="capitalize">
                    {d.status}
                  </Badge>
                </CardContent>
              </Card>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
