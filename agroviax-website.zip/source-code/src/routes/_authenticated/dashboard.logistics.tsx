import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { ShieldCheck, Clock, ShieldAlert } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { PageHeading, EmptyState } from "@/components/dashboard/DashboardShell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { naira } from "@/lib/cart";

export const Route = createFileRoute("/_authenticated/dashboard/logistics")({ component: Logistics });

// A driver's own status controls move a job forward one step at a time —
// they can't skip straight to "delivered" or reassign it to anyone else.
const DELIVERY_STATUS = [
  "assigned", "going_to_pickup", "picked_up", "in_transit", "near_destination", "arrived", "delivered",
] as const;

function Logistics() {
  const { user } = useAuth();
  const uid = user?.id;
  const qc = useQueryClient();

  const payoutAccount = useQuery({
    queryKey: ["payout-account", uid],
    enabled: !!uid,
    queryFn: async () => (await supabase.from("payout_accounts").select("user_id").eq("user_id", uid!).maybeSingle()).data,
  });
  const hasPayoutAccount = !!payoutAccount.data;

  const driver = useQuery({
    queryKey: ["driver-application", uid],
    enabled: !!uid,
    queryFn: async () => (await supabase.from("drivers").select("*").eq("user_id", uid!).maybeSingle()).data,
  });

  const apply = useMutation({
    mutationFn: async (f: FormData) => {
      const { error } = await supabase.from("drivers").insert({
        user_id: uid!,
        legal_name: String(f.get("legal_name") ?? "").trim(),
        display_name: String(f.get("display_name") ?? "").trim(),
        phone: String(f.get("phone") ?? "").trim() || null,
        license_number: String(f.get("license_number") ?? "").trim() || null,
        license_expiry: String(f.get("license_expiry") ?? "") || null,
        vehicle_type: String(f.get("vehicle_type") ?? "").trim() || null,
        plate_number: String(f.get("plate_number") ?? "").trim() || null,
        capacity_kg: f.get("capacity_kg") ? Number(f.get("capacity_kg")) : null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Application submitted — AGROVIAX will review and verify your details.");
      void qc.invalidateQueries({ queryKey: ["driver-application", uid] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const deliveries = useQuery({
    queryKey: ["deliveries", uid],
    enabled: !!uid && driver.data?.approval_status === "approved",
    queryFn: async () =>
      (await supabase.from("deliveries").select("*").eq("transporter_id", uid!).order("created_at", { ascending: false }))
        .data ?? [],
  });

  const setStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const patch: Record<string, unknown> = { status };
      if (status === "picked_up") patch.pickup_confirmed_at = new Date().toISOString();
      if (status === "delivered") patch.delivery_confirmed_at = new Date().toISOString();
      const { error } = await supabase.from("deliveries").update(patch).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Delivery updated");
      void qc.invalidateQueries({ queryKey: ["deliveries", uid] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (driver.isLoading) return <Skeleton className="h-72" />;

  // ---- Not yet an approved driver: show application status / form ----
  if (!driver.data || driver.data.approval_status !== "approved") {
    return (
      <div className="max-w-xl">
        <PageHeading
          title="AGROVIAX Logistics"
          description="AGROVIAX delivery jobs are handled by verified, company-approved drivers — not an open marketplace."
        />

        {driver.data ? (
          <Card>
            <CardContent className="p-6">
              {driver.data.approval_status === "pending" && (
                <div className="flex items-start gap-3">
                  <Clock className="mt-0.5 h-5 w-5 text-amber-600" />
                  <div>
                    <p className="text-sm font-semibold">Application under review</p>
                    <p className="mt-1 text-sm text-muted-foreground">
                      AGROVIAX is verifying your identity, licence and vehicle details. You'll be notified once a
                      decision is made — this isn't instant, and that's intentional.
                    </p>
                  </div>
                </div>
              )}
              {driver.data.approval_status === "rejected" && (
                <div className="flex items-start gap-3">
                  <ShieldAlert className="mt-0.5 h-5 w-5 text-destructive" />
                  <div>
                    <p className="text-sm font-semibold">Application not approved</p>
                    <p className="mt-1 text-sm text-muted-foreground">
                      Contact AGROVIAX support if you believe this was a mistake or your details have changed.
                    </p>
                  </div>
                </div>
              )}
              {driver.data.approval_status === "suspended" && (
                <div className="flex items-start gap-3">
                  <ShieldAlert className="mt-0.5 h-5 w-5 text-destructive" />
                  <div>
                    <p className="text-sm font-semibold">Driver access suspended</p>
                    <p className="mt-1 text-sm text-muted-foreground">
                      Your operational access has been paused. Contact AGROVIAX support for details.
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardContent className="p-6">
              <h2 className="flex items-center gap-2 text-base font-semibold">
                <ShieldCheck className="h-4 w-4 text-primary" /> Apply to become an AGROVIAX driver
              </h2>
              <p className="mt-1 text-xs text-muted-foreground">
                AGROVIAX verifies every driver's identity, licence and vehicle before granting delivery access.
                Submitting this doesn't grant access by itself — a logistics/admin reviewer approves it.
              </p>
              <form
                className="mt-4 space-y-3"
                onSubmit={(e) => {
                  e.preventDefault();
                  apply.mutate(new FormData(e.currentTarget));
                }}
              >
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="space-y-1.5">
                    <Label htmlFor="legal_name">Full legal name</Label>
                    <Input id="legal_name" name="legal_name" required />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="display_name">Display name (shown to buyers/sellers)</Label>
                    <Input id="display_name" name="display_name" placeholder="e.g. Musa D." required />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="phone">Phone</Label>
                  <Input id="phone" name="phone" inputMode="tel" />
                </div>
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="space-y-1.5">
                    <Label htmlFor="license_number">Driver's licence number</Label>
                    <Input id="license_number" name="license_number" />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="license_expiry">Licence expiry</Label>
                    <Input id="license_expiry" name="license_expiry" type="date" />
                  </div>
                </div>
                <div className="grid gap-3 sm:grid-cols-3">
                  <div className="space-y-1.5">
                    <Label htmlFor="vehicle_type">Vehicle type</Label>
                    <Input id="vehicle_type" name="vehicle_type" placeholder="Bike, van, truck…" />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="plate_number">Plate number</Label>
                    <Input id="plate_number" name="plate_number" />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="capacity_kg">Capacity (kg)</Label>
                    <Input id="capacity_kg" name="capacity_kg" type="number" min={0} />
                  </div>
                </div>
                <Button type="submit" disabled={apply.isPending}>
                  {apply.isPending ? "Submitting…" : "Submit application"}
                </Button>
              </form>
            </CardContent>
          </Card>
        )}
      </div>
    );
  }

  // ---- Approved driver: assigned jobs only, never an open pool ----
  const jobs = deliveries.data ?? [];
  const active = jobs.filter((d) => d.status !== "delivered" && d.status !== "cancelled");
  const past = jobs.filter((d) => d.status === "delivered" || d.status === "cancelled");

  return (
    <div>
      <PageHeading title="Logistics" description="Deliveries AGROVIAX has assigned to you." />

      {!hasPayoutAccount && (
        <div className="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-amber-300 bg-amber-50 px-4 py-3 text-sm text-amber-900 dark:border-amber-900 dark:bg-amber-950 dark:text-amber-200">
          <span>Add your payout bank details so delivery fees can reach you.</span>
          <Button asChild size="sm" variant="outline">
            <Link to="/dashboard/settings">Set up payout details</Link>
          </Button>
        </div>
      )}

      <h2 className="text-lg font-semibold">Active deliveries</h2>
      {active.length === 0 ? (
        <div className="mt-3">
          <EmptyState title="No deliveries assigned right now" body="AGROVIAX logistics will assign jobs to you here as orders need them." />
        </div>
      ) : (
        <div className="mt-3 space-y-3">
          {active.map((d) => (
            <Card key={d.id}>
              <CardContent className="flex flex-wrap items-center justify-between gap-3 p-4">
                <div>
                  <p className="text-sm font-medium">
                    {d.pickup_location} → {d.dropoff_location}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Fee {naira(d.fee)}
                    {d.scheduled_for ? ` · ${new Date(d.scheduled_for).toLocaleDateString()}` : ""}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <Badge variant="secondary" className="capitalize">
                    {d.status.replace(/_/g, " ")}
                  </Badge>
                  <Select value={d.status} onValueChange={(status) => setStatus.mutate({ id: d.id, status })}>
                    <SelectTrigger className="h-9 w-44 text-xs capitalize">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {DELIVERY_STATUS.map((s) => (
                        <SelectItem key={s} value={s} className="capitalize">
                          {s.replace(/_/g, " ")}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {past.length > 0 && (
        <>
          <h2 className="mt-8 text-lg font-semibold">History</h2>
          <div className="mt-3 space-y-2">
            {past.map((d) => (
              <Card key={d.id}>
                <CardContent className="flex flex-wrap items-center justify-between gap-3 p-4">
                  <p className="text-sm">
                    {d.pickup_location} → {d.dropoff_location}
                  </p>
                  <Badge variant="outline" className="capitalize">
                    {d.status}
                  </Badge>
                </CardContent>
              </Card>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
