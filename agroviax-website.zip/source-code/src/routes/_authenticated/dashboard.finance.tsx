import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus, Trash2, TrendingDown, TrendingUp, Wallet } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { PageHeading } from "@/components/dashboard/DashboardShell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { naira } from "@/lib/cart";
import { EXPENSE_CATEGORIES, COMMON_CROPS } from "@/lib/suggestions";

export const Route = createFileRoute("/_authenticated/dashboard/finance")({ component: Finance });

function Finance() {
  const { user } = useAuth();
  const uid = user?.id;
  const qc = useQueryClient();

  const farms = useQuery({
    queryKey: ["farms", uid],
    enabled: !!uid,
    queryFn: async () => (await supabase.from("farms").select("id, name").eq("owner_id", uid!)).data ?? [],
  });

  const expenses = useQuery({
    queryKey: ["expenses", uid],
    enabled: !!uid,
    queryFn: async () =>
      (await supabase.from("expenses").select("*").eq("owner_id", uid!).order("expense_date", { ascending: false }))
        .data ?? [],
  });

  const incomes = useQuery({
    queryKey: ["incomes", uid],
    enabled: !!uid,
    queryFn: async () =>
      (await supabase.from("incomes").select("*").eq("owner_id", uid!).order("income_date", { ascending: false })).data ??
      [],
  });

  const addExpense = useMutation({
    mutationFn: async (f: FormData) => {
      const { error } = await supabase.from("expenses").insert({
        owner_id: uid!,
        category: String(f.get("category")),
        description: String(f.get("description")) || null,
        amount: Number(f.get("amount")),
        expense_date: String(f.get("date")) || new Date().toISOString().slice(0, 10),
        farm_id: String(f.get("farm_id")) || (farms.data ?? [])[0]?.id || null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Expense recorded");
      void qc.invalidateQueries({ queryKey: ["expenses", uid] });
      void qc.invalidateQueries({ queryKey: ["dashboard-overview", uid] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const addIncome = useMutation({
    mutationFn: async (f: FormData) => {
      const { error } = await supabase.from("incomes").insert({
        owner_id: uid!,
        source: String(f.get("source")),
        description: String(f.get("description")) || null,
        amount: Number(f.get("amount")),
        income_date: String(f.get("date")) || new Date().toISOString().slice(0, 10),
        farm_id: String(f.get("farm_id")) || (farms.data ?? [])[0]?.id || null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Income recorded");
      void qc.invalidateQueries({ queryKey: ["incomes", uid] });
      void qc.invalidateQueries({ queryKey: ["dashboard-overview", uid] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const removeRow = useMutation({
    mutationFn: async ({ table, id }: { table: "expenses" | "incomes"; id: string }) => {
      const { error } = await supabase.from(table).delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: (_d, v) => {
      void qc.invalidateQueries({ queryKey: [v.table, uid] });
      void qc.invalidateQueries({ queryKey: ["dashboard-overview", uid] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (expenses.isLoading || incomes.isLoading) return <Skeleton className="h-72" />;

  const expTotal = (expenses.data ?? []).reduce((n, r) => n + Number(r.amount), 0);
  const incTotal = (incomes.data ?? []).reduce((n, r) => n + Number(r.amount), 0);
  const profit = incTotal - expTotal;

  return (
    <div>
      <datalist id="expense-category-suggestions">
        {EXPENSE_CATEGORIES.map((c) => (
          <option key={c} value={c} />
        ))}
      </datalist>
      <datalist id="income-source-suggestions">
        {COMMON_CROPS.map((c) => (
          <option key={c} value={`${c} sale`} />
        ))}
      </datalist>
      <PageHeading title="Farm finance" description="Record every naira in and out, and see profit build up per season." />

      <div className="grid gap-4 sm:grid-cols-3">
        <Stat icon={TrendingUp} label="Income" value={naira(incTotal)} tone="text-success" />
        <Stat icon={TrendingDown} label="Expenses" value={naira(expTotal)} tone="text-destructive" />
        <Stat icon={Wallet} label="Profit" value={naira(profit)} tone={profit >= 0 ? "text-forest" : "text-destructive"} />
      </div>

      <Tabs defaultValue="expenses" className="mt-6">
        <TabsList>
          <TabsTrigger value="expenses">Expenses</TabsTrigger>
          <TabsTrigger value="incomes">Income</TabsTrigger>
        </TabsList>

        <TabsContent value="expenses" className="mt-5">
          <form
            className="grid gap-2 rounded-lg border border-border p-3 sm:grid-cols-5"
            onSubmit={(e) => {
              e.preventDefault();
              const form = e.currentTarget;
              addExpense.mutate(new FormData(form));
              form.reset();
            }}
          >
            <Input name="category" placeholder="Category (seeds, labour…)" list="expense-category-suggestions" required className="h-9" />
            <Input name="description" placeholder="Description" className="h-9" />
            <Input name="amount" type="number" step="0.01" placeholder="Amount ₦" required className="h-9" />
            <Input name="date" type="date" className="h-9" />
            {(farms.data ?? []).length > 1 && (
              <Select name="farm_id" defaultValue={farms.data![0].id}>
                <SelectTrigger className="h-9"><SelectValue placeholder="Farm" /></SelectTrigger>
                <SelectContent>
                  {farms.data!.map((f) => (
                    <SelectItem key={f.id} value={f.id}>{f.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
            <Button type="submit" variant="secondary" className="h-9">
              <Plus className="mr-1.5 h-4 w-4" /> Add expense
            </Button>
          </form>
          <Rows
            rows={(expenses.data ?? []).map((r) => ({
              id: r.id,
              main: r.category,
              sub: r.description ?? "",
              date: r.expense_date,
              amount: Number(r.amount),
            }))}
            onDelete={(id) => removeRow.mutate({ table: "expenses", id })}
            empty="No expenses recorded yet."
          />
        </TabsContent>

        <TabsContent value="incomes" className="mt-5">
          <form
            className="grid gap-2 rounded-lg border border-border p-3 sm:grid-cols-5"
            onSubmit={(e) => {
              e.preventDefault();
              const form = e.currentTarget;
              addIncome.mutate(new FormData(form));
              form.reset();
            }}
          >
            <Input name="source" placeholder="Source (maize sale…)" list="income-source-suggestions" required className="h-9" />
            <Input name="description" placeholder="Description" className="h-9" />
            <Input name="amount" type="number" step="0.01" placeholder="Amount ₦" required className="h-9" />
            <Input name="date" type="date" className="h-9" />
            {(farms.data ?? []).length > 1 && (
              <Select name="farm_id" defaultValue={farms.data![0].id}>
                <SelectTrigger className="h-9"><SelectValue placeholder="Farm" /></SelectTrigger>
                <SelectContent>
                  {farms.data!.map((f) => (
                    <SelectItem key={f.id} value={f.id}>{f.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
            <Button type="submit" variant="secondary" className="h-9">
              <Plus className="mr-1.5 h-4 w-4" /> Add income
            </Button>
          </form>
          <Rows
            rows={(incomes.data ?? []).map((r) => ({
              id: r.id,
              main: r.source,
              sub: r.description ?? "",
              date: r.income_date,
              amount: Number(r.amount),
            }))}
            onDelete={(id) => removeRow.mutate({ table: "incomes", id })}
            empty="No income recorded yet."
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function Stat({
  icon: Icon,
  label,
  value,
  tone,
}: {
  icon: typeof Wallet;
  label: string;
  value: string;
  tone: string;
}) {
  return (
    <Card>
      <CardContent className="p-5">
        <Icon className={`h-5 w-5 ${tone}`} />
        <p className={`mt-3 font-display text-2xl ${tone}`}>{value}</p>
        <p className="text-xs uppercase tracking-widest text-muted-foreground">{label}</p>
      </CardContent>
    </Card>
  );
}

function Rows({
  rows,
  onDelete,
  empty,
}: {
  rows: { id: string; main: string; sub: string; date: string; amount: number }[];
  onDelete: (id: string) => void;
  empty: string;
}) {
  if (rows.length === 0) return <p className="mt-5 text-sm text-muted-foreground">{empty}</p>;
  return (
    <ul className="mt-4 divide-y divide-border rounded-lg border border-border">
      {rows.map((r) => (
        <li key={r.id} className="flex items-center justify-between gap-3 px-4 py-3">
          <div>
            <p className="text-sm font-medium capitalize">{r.main}</p>
            <p className="text-xs text-muted-foreground">
              {new Date(r.date).toLocaleDateString()}
              {r.sub ? ` · ${r.sub}` : ""}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <span className="font-medium">{naira(r.amount)}</span>
            <Button variant="ghost" size="sm" onClick={() => onDelete(r.id)}>
              <Trash2 className="h-3.5 w-3.5" />
            </Button>
          </div>
        </li>
      ))}
    </ul>
  );
}
