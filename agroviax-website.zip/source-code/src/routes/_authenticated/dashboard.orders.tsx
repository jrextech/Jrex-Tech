import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { releaseFunds } from "@/lib/release-funds.functions";
import { initializePayment } from "@/lib/payments.functions";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Package, Truck, CreditCard, RotateCcw } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { PageHeading, EmptyState } from "@/components/dashboard/DashboardShell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { naira } from "@/lib/cart";

export const Route = createFileRoute("/_authenticated/dashboard/orders")({ component: Orders });

const STATUSES = ["pending", "confirmed", "paid", "in_transit", "delivered", "cancelled"] as const;
const PAYMENT_LABELS: Record<string, string> = {
  pay_on_delivery: "Pay on delivery",
  bank_transfer: "Bank transfer (arranged directly with seller)",
  paystack: "Card / bank transfer via Paystack",
};

type Order = {
  id: string;
  buyer_id: string;
  seller_id: string | null;
  status: (typeof STATUSES)[number];
  total_amount: number;
  delivery_address: string;
  payment_method: string;
  buyer_confirmed_at: string | null;
  delivery_option: "buyer_pickup" | "need_transport";
  transport_fee: number;
  notes: string | null;
  created_at: string;
  order_items: { id: string; title: string; quantity: number; unit_price: number }[];
  deliveries: { id: string; status: string; pickup_location: string; dropoff_location: string; fee: number }[];
};

function Orders() {
  const { user } = useAuth();
  const uid = user?.id;
  const qc = useQueryClient();

  const ordersQuery = useQuery({
    queryKey: ["orders", uid],
    enabled: !!uid,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("orders")
        .select("*, order_items(id, title, quantity, unit_price), deliveries(id, status, pickup_location, dropoff_location, fee)")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as Order[];
    },
  });

  const setStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { error } = await supabase
        .from("orders")
        .update({ status: status as Order["status"] })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Order updated");
      void qc.invalidateQueries({ queryKey: ["orders", uid] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const postDelivery = useMutation({
    mutationFn: async ({ orderId, pickup, dropoff, fee }: { orderId: string; pickup: string; dropoff: string; fee: number }) => {
      const { error } = await supabase.from("deliveries").insert({
        order_id: orderId,
        pickup_location: pickup,
        dropoff_location: dropoff,
        fee,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Delivery job posted — available transporters have been notified.");
      void qc.invalidateQueries({ queryKey: ["orders", uid] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const purchases = (ordersQuery.data ?? []).filter((o) => o.buyer_id === uid);
  const sales = (ordersQuery.data ?? []).filter((o) => o.seller_id === uid);

  if (ordersQuery.isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-10 w-52" />
        <Skeleton className="h-40" />
      </div>
    );
  }

  return (
    <div>
      <PageHeading title="Orders" description="Purchases you have placed and sales you need to fulfil." />

      <Tabs defaultValue="purchases">
        <TabsList>
          <TabsTrigger value="purchases">Purchases ({purchases.length})</TabsTrigger>
          <TabsTrigger value="sales">Sales ({sales.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="purchases" className="mt-5">
          {purchases.length === 0 ? (
            <EmptyState
              title="No purchases yet"
              body="Add produce or inputs to your basket from the marketplace and place your first order."
              action={
                <Button asChild>
                  <Link to="/marketplace">Browse marketplace</Link>
                </Button>
              }
            />
          ) : (
            <div className="space-y-4">
              {purchases.map((o) => (
                <OrderCard
                  key={o.id}
                  order={o}
                  role="buyer"
                  onStatus={(s) => setStatus.mutate({ id: o.id, status: s })}
                  onPostDelivery={(v) => postDelivery.mutate({ orderId: o.id, ...v })}
                  posting={postDelivery.isPending}
                />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="sales" className="mt-5">
          {sales.length === 0 ? (
            <EmptyState title="No sales yet" body="When a buyer orders one of your listings it will appear here for you to confirm and fulfil." />
          ) : (
            <div className="space-y-4">
              {sales.map((o) => (
                <OrderCard
                  key={o.id}
                  order={o}
                  role="seller"
                  onStatus={(s) => setStatus.mutate({ id: o.id, status: s })}
                  onPostDelivery={(v) => postDelivery.mutate({ orderId: o.id, ...v })}
                  posting={postDelivery.isPending}
                />
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}

function OrderCard({
  order,
  role,
  onStatus,
  onPostDelivery,
  posting,
}: {
  order: Order;
  role: "buyer" | "seller";
  onStatus: (s: string) => void;
  onPostDelivery: (v: { pickup: string; dropoff: string; fee: number }) => void;
  posting: boolean;
}) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [refundOpen, setRefundOpen] = useState(false);
  const { user } = useAuth();
  const doReleaseFunds = useServerFn(releaseFunds);
  const doInitializePayment = useServerFn(initializePayment);

  // Guards against a duplicate charge: initializePayment itself refuses a
  // second payment row for the same order server-side (see
  // payments.functions.ts), and disabling the button while pending stops a
  // double-click from firing two requests before the first one returns.
  const payNow = useMutation({
    mutationFn: async () => {
      if (!user?.email) throw new Error("Your account has no email on file.");
      const { authorizationUrl } = await doInitializePayment({
        data: {
          orderId: order.id,
          buyerEmail: user.email,
          callbackUrl: `${window.location.origin}/dashboard/orders`,
        },
      });
      window.location.href = authorizationUrl;
    },
    onError: (e: Error) => toast.error(e.message || "Couldn't start payment — please try again."),
  });
  const delivery = order.deliveries?.[0];
  const canArrangeTransport =
    role === "seller" && !delivery && order.delivery_option === "need_transport" && (order.status === "confirmed" || order.status === "paid");

  const confirmReceipt = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from("orders")
        .update({ buyer_confirmed_at: new Date().toISOString(), status: "delivered" })
        .eq("id", order.id);
      if (error) throw error;
      // Best-effort: this only succeeds once the order was actually paid via
      // Paystack (payment_method 'paystack'). For pay_on_delivery / direct
      // bank_transfer orders there's no gateway payment to release — those
      // settle exactly as their name says, outside AGROVIAX.
      if (order.payment_method === "paystack") {
        try {
          await doReleaseFunds({ data: { orderId: order.id } });
        } catch {
          toast.error(
            "Receipt confirmed, but paying out the seller/transporter failed automatically — support has been notified to resolve it manually.",
          );
        }
      }
    },
    onSuccess: () => toast.success("Thanks — receipt confirmed."),
    onError: (e: Error) => toast.error(e.message || "Couldn't confirm receipt — please try again."),
  });

  const requestRefund = useMutation({
    mutationFn: async (f: FormData) => {
      const { error } = await supabase.from("refund_requests").insert({
        order_id: order.id,
        buyer_id: user!.id,
        reason: String(f.get("reason") ?? "").trim(),
        bank_name: String(f.get("bank_name") ?? "").trim(),
        account_number: String(f.get("account_number") ?? "").trim(),
        account_name: String(f.get("account_name") ?? "").trim(),
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Refund request sent — our team will review it.");
      setRefundOpen(false);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Card>
      <CardContent className="p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <p className="flex items-center gap-2 text-sm font-medium">
              <Package className="h-4 w-4 text-primary" /> Order #{order.id.slice(0, 8)}
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              {new Date(order.created_at).toLocaleString()} · deliver to {order.delivery_address}
            </p>
            <p className="mt-1 flex items-center gap-1.5 text-xs text-muted-foreground">
              <CreditCard className="h-3.5 w-3.5" /> {PAYMENT_LABELS[order.payment_method] ?? order.payment_method}
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              {order.delivery_option === "need_transport"
                ? `AGROVIAX transport requested${order.transport_fee ? ` · ${naira(order.transport_fee)} delivery fee` : ""}`
                : "Buyer arranging own pickup/delivery"}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <p className="font-display text-lg text-forest">{naira(order.total_amount)}</p>
            {role === "seller" ? (
              <Select value={order.status} onValueChange={onStatus}>
                <SelectTrigger className="h-9 w-40 text-xs capitalize">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {STATUSES.map((s) => (
                    <SelectItem key={s} value={s} className="capitalize">
                      {s.replace(/_/g, " ")}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            ) : (
              <Badge variant="secondary" className="capitalize">
                {order.status.replace(/_/g, " ")}
              </Badge>
            )}
          </div>
        </div>

        <ul className="mt-4 divide-y divide-border rounded-lg border border-border">
          {order.order_items.map((i) => (
            <li key={i.id} className="flex items-center justify-between px-4 py-2.5 text-sm">
              <span>
                {i.title} × {i.quantity}
              </span>
              <span className="text-muted-foreground">{naira(Number(i.unit_price) * i.quantity)}</span>
            </li>
          ))}
        </ul>

        {order.notes && <p className="mt-3 text-sm text-muted-foreground">Note: {order.notes}</p>}

        {delivery && (
          <div className="mt-4 flex items-center gap-2 rounded-lg border border-border bg-secondary/30 px-4 py-2.5 text-xs">
            <Truck className="h-4 w-4 text-primary" />
            <span className="capitalize">Delivery {delivery.status.replace(/_/g, " ")}</span>
            <span className="text-muted-foreground">
              · {delivery.pickup_location} → {delivery.dropoff_location} · {naira(delivery.fee)}
            </span>
          </div>
        )}

        <div className="mt-4 flex flex-wrap gap-2">
          {role === "buyer" && order.status === "pending" && order.payment_method === "paystack" && (
            <Button size="sm" disabled={payNow.isPending} onClick={() => payNow.mutate()}>
              {payNow.isPending ? "Redirecting…" : "Pay now"}
            </Button>
          )}

          {role === "buyer" && order.status === "pending" && (
            <Button variant="outline" size="sm" onClick={() => onStatus("cancelled")}>
              Cancel order
            </Button>
          )}

          {role === "buyer" && ["paid", "confirmed", "in_transit", "delivered"].includes(order.status) && !order.buyer_confirmed_at && (
            <Button size="sm" disabled={confirmReceipt.isPending} onClick={() => confirmReceipt.mutate()}>
              {confirmReceipt.isPending ? "Confirming…" : "Confirm receipt"}
            </Button>
          )}
          {order.buyer_confirmed_at && (
            <Badge variant="secondary">Receipt confirmed {new Date(order.buyer_confirmed_at).toLocaleDateString()}</Badge>
          )}

          {role === "buyer" && ["paid", "confirmed", "in_transit", "delivered"].includes(order.status) && (
            <Dialog open={refundOpen} onOpenChange={setRefundOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm">
                  <RotateCcw className="mr-1.5 h-3.5 w-3.5" /> Request refund
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Request a refund</DialogTitle>
                </DialogHeader>
                <form
                  className="space-y-3"
                  onSubmit={(e) => {
                    e.preventDefault();
                    requestRefund.mutate(new FormData(e.currentTarget));
                  }}
                >
                  <p className="text-xs text-muted-foreground">
                    Your bank details are only ever collected here, for this refund — not stored anywhere else on
                    your account.
                  </p>
                  <div className="space-y-1.5">
                    <Label htmlFor="reason">What went wrong?</Label>
                    <Textarea id="reason" name="reason" rows={3} required />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="bank_name">Bank name</Label>
                    <Input id="bank_name" name="bank_name" required />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="account_number">Account number</Label>
                    <Input id="account_number" name="account_number" inputMode="numeric" required />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="account_name">Account name</Label>
                    <Input id="account_name" name="account_name" required />
                  </div>
                  <DialogFooter>
                    <Button type="submit" disabled={requestRefund.isPending}>
                      {requestRefund.isPending ? "Sending…" : "Submit request"}
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          )}

          {canArrangeTransport && (
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm">
                  <Truck className="mr-1.5 h-3.5 w-3.5" /> Arrange transport
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Post a delivery job</DialogTitle>
                </DialogHeader>
                <form
                  className="space-y-3"
                  onSubmit={(e) => {
                    e.preventDefault();
                    const f = new FormData(e.currentTarget);
                    onPostDelivery({
                      pickup: String(f.get("pickup") ?? "").trim(),
                      dropoff: String(f.get("dropoff") ?? "").trim(),
                      fee: Number(f.get("fee") ?? 0),
                    });
                    setDialogOpen(false);
                  }}
                >
                  <div className="space-y-1.5">
                    <Label htmlFor="pickup">Pickup location</Label>
                    <Input id="pickup" name="pickup" placeholder="Your farm or warehouse address" required />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="dropoff">Drop-off location</Label>
                    <Input id="dropoff" name="dropoff" defaultValue={order.delivery_address} required />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="fee">Delivery fee offered (₦)</Label>
                    <Input id="fee" name="fee" type="number" min={0} step="1" defaultValue={0} required />
                  </div>
                  <DialogFooter>
                    <Button type="submit" disabled={posting}>
                      {posting ? "Posting…" : "Post job"}
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
