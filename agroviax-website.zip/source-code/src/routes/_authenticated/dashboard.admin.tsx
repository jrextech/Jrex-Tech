import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { createDriverAccount, createLogisticsPartner, createPartnerStaffAccount, createDepartmentAdminAccount } from "@/lib/staff-accounts.functions";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { BadgeCheck, Plus, Trash2, Mail, MailOpen, Landmark, RotateCcw, Truck, ShieldCheck, ShieldX, History } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { PageHeading, EmptyState } from "@/components/dashboard/DashboardShell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { naira } from "@/lib/cart";

export const Route = createFileRoute("/_authenticated/dashboard/admin")({ component: Admin });

const DEPARTMENT_LABELS: Record<string, string> = {
  super_admin: "Super Admin",
  marketplace: "Business & Marketplace Admin",
  agriculture: "Agriculture & Crop Health Admin",
  logistics: "Logistics & Operations Admin",
  finance: "Finance Admin",
  support: "Customer & Support Admin",
  it_security: "Technology & Security Admin",
  marketing: "Marketing & Communications Admin",
};
// Which tabs each department can see. Super Admin sees everything; every
// other department sees only the areas the Compressed Admin Structure
// document assigns to it — this mirrors the RLS on the underlying tables,
// so a department that can't see a tab also can't write to it if it
// somehow reached the data another way.
const DEPARTMENT_TABS: Record<string, string[]> = {
  super_admin: ["listings", "prices", "inbox", "fees", "refunds", "drivers", "cases", "announcements", "audit", "staff"],
  marketplace: ["listings", "prices"],
  finance: ["fees", "refunds"],
  logistics: ["drivers"],
  support: ["inbox"],
  agriculture: ["cases"],
  marketing: ["announcements"],
  it_security: ["audit"],
};

function Admin() {
  const { user, roles } = useAuth();
  const qc = useQueryClient();
  const isAdmin = roles.includes("admin");

  const myDepartment = useQuery({
    queryKey: ["my-admin-department", user?.id],
    enabled: isAdmin && !!user?.id,
    queryFn: async () => (await supabase.from("admin_staff").select("department, title").eq("user_id", user!.id).maybeSingle()).data,
  });
  const department = myDepartment.data?.department ?? null;
  const isSuperAdmin = department === "super_admin";
  const visibleTabs = department ? (DEPARTMENT_TABS[department] ?? []) : [];
  const canSee = (tab: string) => visibleTabs.includes(tab);

  const products = useQuery({
    queryKey: ["admin-products"],
    enabled: isAdmin,
    queryFn: async () =>
      (await supabase.from("products").select("*").order("created_at", { ascending: false }).limit(100)).data ?? [],
  });

  const prices = useQuery({
    queryKey: ["admin-prices"],
    enabled: isAdmin,
    queryFn: async () => (await supabase.from("market_prices").select("*").order("crop_type")).data ?? [],
  });

  const orders = useQuery({
    queryKey: ["admin-orders"],
    enabled: isAdmin,
    queryFn: async () =>
      (await supabase.from("orders").select("id, status, total_amount, created_at").order("created_at", { ascending: false }))
        .data ?? [],
  });

  const inbox = useQuery({
    queryKey: ["admin-contact-messages"],
    enabled: isAdmin,
    queryFn: async () =>
      (await supabase.from("contact_messages").select("*").order("created_at", { ascending: false })).data ?? [],
  });

  const markInboxStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: "read" | "resolved" }) => {
      const { error } = await supabase.from("contact_messages").update({ status }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["admin-contact-messages"] }),
    onError: (e: Error) => toast.error(e.message),
  });

  const toggleVerified = useMutation({
    mutationFn: async ({ id, verified }: { id: string; verified: boolean }) => {
      const { error } = await supabase.from("products").update({ verified }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Listing moderated");
      void qc.invalidateQueries({ queryKey: ["admin-products"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const addPrice = useMutation({
    mutationFn: async (f: FormData) => {
      const { error } = await supabase.from("market_prices").insert({
        crop_type: String(f.get("crop_type")),
        market_name: String(f.get("market_name")),
        region: String(f.get("region")),
        price: Number(f.get("price")),
        unit: String(f.get("unit")),
        recorded_on: new Date().toISOString().slice(0, 10),
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Price published");
      void qc.invalidateQueries({ queryKey: ["admin-prices"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const removePrice = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("market_prices").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["admin-prices"] }),
    onError: (e: Error) => toast.error(e.message),
  });

  const feeTiers = useQuery({
    queryKey: ["admin-fee-tiers"],
    enabled: isAdmin,
    queryFn: async () => (await supabase.from("platform_fee_tiers").select("*").order("sort_order")).data ?? [],
  });

  const vehicleTiers = useQuery({
    queryKey: ["admin-vehicle-tiers"],
    enabled: isAdmin,
    queryFn: async () => (await supabase.from("vehicle_tiers").select("*").order("sort_order")).data ?? [],
  });

  const settings = useQuery({
    queryKey: ["admin-settings"],
    enabled: isAdmin,
    queryFn: async () => {
      const { data } = await supabase.from("platform_settings").select("*");
      return Object.fromEntries((data ?? []).map((r) => [r.key, r.value])) as Record<string, any>;
    },
  });

  const refunds = useQuery({
    queryKey: ["admin-refunds"],
    enabled: isAdmin,
    queryFn: async () =>
      (await supabase.from("refund_requests").select("*").order("created_at", { ascending: false })).data ?? [],
  });

  const updateFeeTier = useMutation({
    mutationFn: async ({ id, fee_percent }: { id: string; fee_percent: number }) => {
      const { error } = await supabase.from("platform_fee_tiers").update({ fee_percent }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Fee tier updated");
      void qc.invalidateQueries({ queryKey: ["admin-fee-tiers"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const updateVehicleTier = useMutation({
    mutationFn: async (v: { id: string; km_per_litre: number; base_handling_fee: number }) => {
      const { error } = await supabase
        .from("vehicle_tiers")
        .update({ km_per_litre: v.km_per_litre, base_handling_fee: v.base_handling_fee })
        .eq("id", v.id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Vehicle tier updated");
      void qc.invalidateQueries({ queryKey: ["admin-vehicle-tiers"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const updateSetting = useMutation({
    mutationFn: async ({ key, value }: { key: string; value: any }) => {
      const { error } = await supabase.from("platform_settings").update({ value }).eq("key", key);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Setting saved");
      void qc.invalidateQueries({ queryKey: ["admin-settings"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const updateRefund = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: "approved" | "rejected" | "paid" }) => {
      const { error } = await supabase.from("refund_requests").update({ status }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Refund updated");
      void qc.invalidateQueries({ queryKey: ["admin-refunds"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const drivers = useQuery({
    queryKey: ["admin-drivers"],
    enabled: isAdmin,
    queryFn: async () => (await supabase.from("drivers").select("*").order("created_at", { ascending: false })).data ?? [],
  });

  const partners = useQuery({
    queryKey: ["admin-partners"],
    enabled: isAdmin,
    queryFn: async () => (await supabase.from("logistics_partners").select("*").order("created_at", { ascending: false })).data ?? [],
  });

  const partnerStaff = useQuery({
    queryKey: ["admin-partner-staff"],
    enabled: isAdmin,
    queryFn: async () => (await supabase.from("logistics_partner_staff").select("*")).data ?? [],
  });

  const [newDriverCreds, setNewDriverCreds] = useState<{ email: string; temporaryPassword: string } | null>(null);
  const [newPartnerStaffCreds, setNewPartnerStaffCreds] = useState<{ email: string; temporaryPassword: string } | null>(null);
  const [createDriverOpen, setCreateDriverOpen] = useState(false);
  const [createPartnerOpen, setCreatePartnerOpen] = useState(false);
  const [addStaffPartnerId, setAddStaffPartnerId] = useState<string | null>(null);

  const doCreateDriverAccount = useServerFn(createDriverAccount);
  const doCreateLogisticsPartner = useServerFn(createLogisticsPartner);
  const doCreatePartnerStaffAccount = useServerFn(createPartnerStaffAccount);

  async function callerToken() {
    const { data } = await supabase.auth.getSession();
    const token = data.session?.access_token;
    if (!token) throw new Error("Your session expired — sign in again.");
    return token;
  }

  const createDriver = useMutation({
    mutationFn: async (f: FormData) => {
      const callerAccessToken = await callerToken();
      return doCreateDriverAccount({
        data: {
          callerAccessToken,
          email: String(f.get("email") ?? "").trim(),
          legalName: String(f.get("legal_name") ?? "").trim(),
          displayName: String(f.get("display_name") ?? "").trim(),
          phone: String(f.get("phone") ?? "").trim() || undefined,
          licenseNumber: String(f.get("license_number") ?? "").trim() || undefined,
          licenseExpiry: String(f.get("license_expiry") ?? "") || undefined,
          vehicleType: String(f.get("vehicle_type") ?? "").trim() || undefined,
          plateNumber: String(f.get("plate_number") ?? "").trim() || undefined,
          capacityKg: f.get("capacity_kg") ? Number(f.get("capacity_kg")) : undefined,
          branchArea: String(f.get("branch_area") ?? "").trim() || undefined,
          identityVerified: f.get("identity_verified") === "on",
          licenseVerified: f.get("license_verified") === "on",
          vehicleVerified: f.get("vehicle_verified") === "on",
          approveNow: f.get("approve_now") === "on",
        },
      });
    },
    onSuccess: (result) => {
      setNewDriverCreds(result);
      setCreateDriverOpen(false);
      void qc.invalidateQueries({ queryKey: ["admin-drivers"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const createPartner = useMutation({
    mutationFn: async (f: FormData) => {
      const callerAccessToken = await callerToken();
      return doCreateLogisticsPartner({
        data: {
          callerAccessToken,
          companyName: String(f.get("company_name") ?? "").trim(),
          contactName: String(f.get("contact_name") ?? "").trim(),
          contactEmail: String(f.get("contact_email") ?? "").trim() || undefined,
          contactPhone: String(f.get("contact_phone") ?? "").trim() || undefined,
          notes: String(f.get("notes") ?? "").trim() || undefined,
        },
      });
    },
    onSuccess: () => {
      toast.success("Partner company registered");
      setCreatePartnerOpen(false);
      void qc.invalidateQueries({ queryKey: ["admin-partners"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const createPartnerStaff = useMutation({
    mutationFn: async (f: FormData) => {
      if (!addStaffPartnerId) throw new Error("No partner selected.");
      const callerAccessToken = await callerToken();
      return doCreatePartnerStaffAccount({
        data: {
          callerAccessToken,
          partnerId: addStaffPartnerId,
          email: String(f.get("email") ?? "").trim(),
          displayName: String(f.get("display_name") ?? "").trim(),
          roleTitle: String(f.get("role_title") ?? "").trim() || undefined,
        },
      });
    },
    onSuccess: (result) => {
      setNewPartnerStaffCreds(result);
      setAddStaffPartnerId(null);
      void qc.invalidateQueries({ queryKey: ["admin-partner-staff"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const [createStaffOpen, setCreateStaffOpen] = useState(false);
  const doCreateDepartmentAdminAccount = useServerFn(createDepartmentAdminAccount);

  const allStaff = useQuery({
    queryKey: ["admin-all-staff"],
    enabled: isSuperAdmin,
    queryFn: async () => (await supabase.from("admin_staff").select("*").order("created_at", { ascending: false })).data ?? [],
  });

  const auditLog = useQuery({
    queryKey: ["admin-audit-log"],
    enabled: canSee("audit"),
    queryFn: async () =>
      (await supabase.from("audit_log").select("*").order("created_at", { ascending: false }).limit(100)).data ?? [],
  });

  const allCases = useQuery({
    queryKey: ["admin-all-cases"],
    enabled: canSee("cases"),
    queryFn: async () =>
      (await supabase.from("disease_cases").select("*, expert_reviews(id, diagnosis, created_at)").order("created_at", { ascending: false }).limit(100))
        .data ?? [],
  });

  const announcements = useQuery({
    queryKey: ["admin-announcements"],
    enabled: canSee("announcements"),
    queryFn: async () => (await supabase.from("announcements").select("*").order("created_at", { ascending: false })).data ?? [],
  });

  const saveAnnouncement = useMutation({
    mutationFn: async (f: FormData) => {
      const { error } = await supabase.from("announcements").insert({
        title: String(f.get("title") ?? "").trim(),
        body: String(f.get("body") ?? "").trim(),
        ends_at: f.get("ends_at") ? new Date(String(f.get("ends_at"))).toISOString() : null,
        created_by: user?.id,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Announcement published");
      void qc.invalidateQueries({ queryKey: ["admin-announcements"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const toggleAnnouncement = useMutation({
    mutationFn: async ({ id, is_active }: { id: string; is_active: boolean }) => {
      const { error } = await supabase.from("announcements").update({ is_active }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["admin-announcements"] }),
    onError: (e: Error) => toast.error(e.message),
  });

  const deleteAnnouncement = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("announcements").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["admin-announcements"] }),
    onError: (e: Error) => toast.error(e.message),
  });

  const createDeptAdmin = useMutation({
    mutationFn: async (f: FormData) => {
      const callerAccessToken = await callerToken();
      return doCreateDepartmentAdminAccount({
        data: {
          callerAccessToken,
          email: String(f.get("email") ?? "").trim(),
          displayName: String(f.get("display_name") ?? "").trim(),
          department: String(f.get("department") ?? "marketplace") as
            | "super_admin" | "finance" | "marketplace" | "agriculture" | "logistics" | "support" | "marketing" | "it_security",
          title: String(f.get("title") ?? "").trim() || undefined,
        },
      });
    },
    onSuccess: (result) => {
      setNewDriverCreds(result);
      setCreateStaffOpen(false);
      void qc.invalidateQueries({ queryKey: ["admin-all-staff"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const unassignedDeliveries = useQuery({
    queryKey: ["admin-unassigned-deliveries"],
    enabled: isAdmin,
    queryFn: async () =>
      (await supabase.from("deliveries").select("*").is("transporter_id", null).is("partner_id", null).order("created_at"))
        .data ?? [],
  });

  const updateDriverStatus = useMutation({
    mutationFn: async ({
      userId,
      patch,
    }: {
      userId: string;
      patch: Partial<{
        approval_status: "approved" | "suspended" | "rejected";
        id_verification_status: "verified" | "rejected";
        license_status: "verified" | "expired" | "rejected";
        vehicle_status: "verified" | "rejected";
        operational_status: "available" | "suspended" | "inactive";
      }>;
    }) => {
      const fullPatch: Record<string, unknown> = { ...patch };
      if (patch.approval_status === "approved") {
        fullPatch.approved_by = user?.id;
        fullPatch.approved_at = new Date().toISOString();
        fullPatch.operational_status = "available";
        fullPatch.employment_status = "active";
      }
      const { error } = await supabase.from("drivers").update(fullPatch).eq("user_id", userId);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Driver record updated");
      void qc.invalidateQueries({ queryKey: ["admin-drivers"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const assignDriver = useMutation({
    mutationFn: async ({ deliveryId, driverId }: { deliveryId: string; driverId: string }) => {
      const { error } = await supabase.from("deliveries").update({ transporter_id: driverId }).eq("id", deliveryId);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Driver assigned to job");
      void qc.invalidateQueries({ queryKey: ["admin-unassigned-deliveries"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const routeToPartner = useMutation({
    mutationFn: async ({ deliveryId, partnerId }: { deliveryId: string; partnerId: string }) => {
      const { error } = await supabase
        .from("deliveries")
        .update({ provider_type: "partner", partner_id: partnerId, status: "assigned" })
        .eq("id", deliveryId);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Job routed to partner company");
      void qc.invalidateQueries({ queryKey: ["admin-unassigned-deliveries"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (!isAdmin) {
    return (
      <div>
        <PageHeading title="Administration" description="This area is restricted to platform administrators." />
      </div>
    );
  }

  if (products.isLoading || myDepartment.isLoading) return <Skeleton className="h-72" />;

  if (!department) {
    return (
      <EmptyState
        title="No department assigned"
        body="Your account has admin access but isn't yet linked to a department — ask a Super Admin to assign one from Staff & Departments."
      />
    );
  }

  return (
    <div>
      <PageHeading
        title="Administration"
        description={`Signed in as ${DEPARTMENT_LABELS[department]}${myDepartment.data?.title ? ` — ${myDepartment.data.title}` : ""}.`}
      />

      <div className="grid gap-4 sm:grid-cols-3">
        <Stat label="Listings" value={String((products.data ?? []).length)} />
        <Stat label="Orders" value={String((orders.data ?? []).length)} />
        <Stat label="Tracked prices" value={String((prices.data ?? []).length)} />
      </div>

      {visibleTabs.length === 0 && !isSuperAdmin ? (
        <div className="mt-6">
          <EmptyState
            title={`No management tools here yet for ${DEPARTMENT_LABELS[department]}`}
            body="This department's dedicated dashboard tools haven't been built yet — the platform team is working department by department."
          />
        </div>
      ) : (
        <Tabs defaultValue={visibleTabs[0] ?? "staff"} className="mt-6">
          <TabsList>
            {canSee("listings") && <TabsTrigger value="listings">Listings</TabsTrigger>}
            {canSee("prices") && <TabsTrigger value="prices">Market prices</TabsTrigger>}
            {canSee("inbox") && (
              <TabsTrigger value="inbox">
                Inbox
                {(inbox.data ?? []).some((m) => m.status === "new") && (
                  <span className="ml-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-destructive text-[10px] text-destructive-foreground">
                    {(inbox.data ?? []).filter((m) => m.status === "new").length}
                  </span>
                )}
              </TabsTrigger>
            )}
            {canSee("fees") && <TabsTrigger value="fees">Fees &amp; payouts</TabsTrigger>}
            {canSee("refunds") && (
              <TabsTrigger value="refunds">
                Refunds
                {(refunds.data ?? []).some((r) => r.status === "pending") && (
                  <span className="ml-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-destructive text-[10px] text-destructive-foreground">
                    {(refunds.data ?? []).filter((r) => r.status === "pending").length}
                  </span>
                )}
              </TabsTrigger>
            )}
            {canSee("drivers") && (
              <TabsTrigger value="drivers">
                Drivers
                {(drivers.data ?? []).some((d) => d.approval_status === "pending") && (
                  <span className="ml-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-destructive text-[10px] text-destructive-foreground">
                    {(drivers.data ?? []).filter((d) => d.approval_status === "pending").length}
                  </span>
                )}
              </TabsTrigger>
            )}
            {canSee("cases") && <TabsTrigger value="cases">Crop-health oversight</TabsTrigger>}
            {canSee("announcements") && <TabsTrigger value="announcements">Announcements</TabsTrigger>}
            {canSee("audit") && <TabsTrigger value="audit">Audit log</TabsTrigger>}
            {isSuperAdmin && <TabsTrigger value="staff">Staff &amp; departments</TabsTrigger>}
          </TabsList>

          {canSee("listings") && (
          <TabsContent value="listings" className="mt-5 space-y-3">
          {(products.data ?? []).map((p) => (
            <Card key={p.id}>
              <CardContent className="flex flex-wrap items-center justify-between gap-3 p-4">
                <div>
                  <p className="text-sm font-medium">{p.title}</p>
                  <p className="text-xs text-muted-foreground">
                    {p.seller_name} · {p.location} · {naira(p.price)}/{p.unit}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={p.verified ? "default" : "secondary"}>{p.verified ? "Verified" : "Unverified"}</Badge>
                  <Button size="sm" variant="outline" onClick={() => toggleVerified.mutate({ id: p.id, verified: !p.verified })}>
                    <BadgeCheck className="mr-1.5 h-3.5 w-3.5" />
                    {p.verified ? "Revoke" : "Verify"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
          )}

          {canSee("prices") && (
        <TabsContent value="prices" className="mt-5">
          <form
            className="grid gap-2 rounded-lg border border-border p-3 sm:grid-cols-6"
            onSubmit={(e) => {
              e.preventDefault();
              const form = e.currentTarget;
              addPrice.mutate(new FormData(form));
              form.reset();
            }}
          >
            <Input name="crop_type" placeholder="Crop" list="crop-type-suggestions" required className="h-9" />
            <Input name="market_name" placeholder="Market" list="market-name-suggestions" required className="h-9" />
            <Input name="region" placeholder="Region" list="region-suggestions" required className="h-9" />
            <Input name="price" type="number" step="0.01" placeholder="Price ₦" required className="h-9" />
            <Input name="unit" placeholder="Unit (kg)" list="unit-suggestions" required className="h-9" />
            <Button type="submit" variant="secondary" className="h-9">
              <Plus className="mr-1.5 h-4 w-4" /> Publish
            </Button>
            <datalist id="crop-type-suggestions">
              {Array.from(new Set((prices.data ?? []).map((p) => p.crop_type))).map((v) => (
                <option key={v} value={v} />
              ))}
            </datalist>
            <datalist id="market-name-suggestions">
              {Array.from(new Set((prices.data ?? []).map((p) => p.market_name))).map((v) => (
                <option key={v} value={v} />
              ))}
            </datalist>
            <datalist id="region-suggestions">
              {Array.from(new Set((prices.data ?? []).map((p) => p.region))).map((v) => (
                <option key={v} value={v} />
              ))}
            </datalist>
            <datalist id="unit-suggestions">
              <option value="kg" />
              <option value="tuber" />
              <option value="litre" />
              <option value="bag" />
              <option value="crate" />
            </datalist>
          </form>

          <ul className="mt-4 divide-y divide-border rounded-lg border border-border">
            {(prices.data ?? []).map((p) => (
              <li key={p.id} className="flex items-center justify-between px-4 py-3">
                <div>
                  <p className="text-sm font-medium">{p.crop_type}</p>
                  <p className="text-xs text-muted-foreground">
                    {p.market_name} · {p.region}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-sm font-medium">
                    {naira(p.price)}/{p.unit}
                  </span>
                  <Button variant="ghost" size="sm" onClick={() => removePrice.mutate(p.id)}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        </TabsContent>
          )}

          {canSee("inbox") && (
        <TabsContent value="inbox" className="mt-5 space-y-3">
          {(inbox.data ?? []).length === 0 ? (
            <EmptyState title="No messages yet" body="Submissions from the public contact form will land here." />
          ) : (
            (inbox.data ?? []).map((m) => (
              <Card key={m.id} className={m.status === "new" ? "border-primary/40" : undefined}>
                <CardContent className="p-4">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div>
                      <p className="text-sm font-medium">{m.subject}</p>
                      <p className="text-xs text-muted-foreground">
                        {m.name} · {m.email} · {new Date(m.created_at).toLocaleString()}
                      </p>
                    </div>
                    <Badge variant={m.status === "new" ? "default" : m.status === "resolved" ? "secondary" : "outline"}>
                      {m.status}
                    </Badge>
                  </div>
                  <p className="mt-3 text-sm text-muted-foreground">{m.body}</p>
                  <div className="mt-3 flex gap-2">
                    {m.status === "new" && (
                      <Button size="sm" variant="outline" onClick={() => markInboxStatus.mutate({ id: m.id, status: "read" })}>
                        <MailOpen className="mr-1.5 h-3.5 w-3.5" /> Mark read
                      </Button>
                    )}
                    {m.status !== "resolved" && (
                      <Button size="sm" variant="outline" onClick={() => markInboxStatus.mutate({ id: m.id, status: "resolved" })}>
                        <Mail className="mr-1.5 h-3.5 w-3.5" /> Mark resolved
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>
          )}

          {canSee("fees") && (
        <TabsContent value="fees" className="mt-5 space-y-6">
          <Card>
            <CardContent className="p-5">
              <h3 className="flex items-center gap-2 text-sm font-semibold">
                <Landmark className="h-4 w-4" /> Platform commission tiers
              </h3>
              <p className="mt-1 text-xs text-muted-foreground">
                Percentage taken from the product subtotal only, never shown to the buyer — it comes out of what the
                seller receives. Delivery fees always go to the transporter in full.
              </p>
              <div className="mt-4 space-y-2">
                {(feeTiers.data ?? []).map((t) => (
                  <div key={t.id} className="flex items-center justify-between gap-3 rounded-lg border border-border p-3">
                    <span className="text-sm">
                      {naira(t.min_amount)} – {t.max_amount ? naira(t.max_amount) : "and above"}
                    </span>
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        step="0.1"
                        defaultValue={t.fee_percent}
                        className="h-8 w-20 text-sm"
                        onBlur={(e) => {
                          const v = Number(e.target.value);
                          if (v !== Number(t.fee_percent)) updateFeeTier.mutate({ id: t.id, fee_percent: v });
                        }}
                      />
                      <span className="text-xs text-muted-foreground">%</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-5">
              <h3 className="text-sm font-semibold">Transport fee formula</h3>
              <p className="mt-1 text-xs text-muted-foreground">
                fee = (base handling fee for the vehicle tier + distance ÷ km-per-litre × fuel price) × margin.
                Vehicle tier is chosen automatically from the order's total weight.
              </p>
              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label>Reference fuel price (₦/litre)</Label>
                  <Input
                    type="number"
                    defaultValue={settings.data?.fuel_price_per_litre?.amount ?? 1200}
                    className="h-9"
                    onBlur={(e) =>
                      updateSetting.mutate({
                        key: "fuel_price_per_litre",
                        value: { amount: Number(e.target.value), note: "Manually updated reference price, NGN/litre", updated_at: new Date().toISOString() },
                      })
                    }
                  />
                  <p className="text-xs text-muted-foreground">
                    No live nationwide feed exists — update this periodically from NNPC/market reports.
                  </p>
                </div>
                <div className="space-y-1.5">
                  <Label>Margin multiplier</Label>
                  <Input
                    type="number"
                    step="0.1"
                    defaultValue={settings.data?.transport_fee_margin?.multiplier ?? 1.4}
                    className="h-9"
                    onBlur={(e) =>
                      updateSetting.mutate({ key: "transport_fee_margin", value: { multiplier: Number(e.target.value) } })
                    }
                  />
                  <p className="text-xs text-muted-foreground">Covers the transporter's time and profit above raw fuel cost.</p>
                </div>
              </div>

              <div className="mt-5 space-y-2">
                {(vehicleTiers.data ?? []).map((v) => (
                  <div key={v.id} className="grid gap-2 rounded-lg border border-border p-3 sm:grid-cols-4 sm:items-center">
                    <span className="text-sm sm:col-span-2">{v.label}</span>
                    <div className="space-y-1">
                      <Label className="text-xs text-muted-foreground">km/litre</Label>
                      <Input
                        type="number"
                        step="0.1"
                        defaultValue={v.km_per_litre}
                        className="h-8 text-sm"
                        onBlur={(e) => {
                          const km = Number(e.target.value);
                          if (km !== Number(v.km_per_litre)) updateVehicleTier.mutate({ id: v.id, km_per_litre: km, base_handling_fee: Number(v.base_handling_fee) });
                        }}
                      />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs text-muted-foreground">Base fee ₦</Label>
                      <Input
                        type="number"
                        defaultValue={v.base_handling_fee}
                        className="h-8 text-sm"
                        onBlur={(e) => {
                          const fee = Number(e.target.value);
                          if (fee !== Number(v.base_handling_fee)) updateVehicleTier.mutate({ id: v.id, km_per_litre: Number(v.km_per_litre), base_handling_fee: fee });
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-5">
              <h3 className="text-sm font-semibold">Platform's own payout account</h3>
              <p className="mt-1 text-xs text-muted-foreground">Where AGROVIAX's commission settles.</p>
              <form
                className="mt-4 grid gap-3 sm:grid-cols-3"
                onSubmit={(e) => {
                  e.preventDefault();
                  const f = new FormData(e.currentTarget);
                  updateSetting.mutate({
                    key: "platform_payout_account",
                    value: {
                      bank_name: String(f.get("bank_name") ?? ""),
                      account_number: String(f.get("account_number") ?? ""),
                      account_name: String(f.get("account_name") ?? ""),
                    },
                  });
                }}
              >
                <Input name="bank_name" placeholder="Bank name" defaultValue={settings.data?.platform_payout_account?.bank_name ?? ""} className="h-9" />
                <Input name="account_number" placeholder="Account number" defaultValue={settings.data?.platform_payout_account?.account_number ?? ""} className="h-9" />
                <Input name="account_name" placeholder="Account name" defaultValue={settings.data?.platform_payout_account?.account_name ?? ""} className="h-9" />
                <Button type="submit" variant="secondary" className="h-9 sm:col-span-3 sm:w-fit">Save platform account</Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
          )}

          {canSee("refunds") && (
        <TabsContent value="refunds" className="mt-5 space-y-3">
          {(refunds.data ?? []).length === 0 ? (
            <EmptyState title="No refund requests" body="Buyer refund requests will appear here for review." />
          ) : (
            (refunds.data ?? []).map((r) => (
              <Card key={r.id} className={r.status === "pending" ? "border-primary/40" : undefined}>
                <CardContent className="p-4">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div>
                      <p className="text-sm font-medium">Order #{r.order_id.slice(0, 8)}</p>
                      <p className="text-xs text-muted-foreground">{new Date(r.created_at).toLocaleString()}</p>
                    </div>
                    <Badge variant={r.status === "pending" ? "default" : r.status === "paid" ? "secondary" : "outline"}>
                      {r.status}
                    </Badge>
                  </div>
                  <p className="mt-3 text-sm text-muted-foreground">{r.reason}</p>
                  <p className="mt-2 flex items-center gap-1.5 text-xs text-muted-foreground">
                    <RotateCcw className="h-3.5 w-3.5" /> {r.bank_name} · {r.account_number} · {r.account_name}
                  </p>
                  {r.status === "pending" && (
                    <div className="mt-3 flex gap-2">
                      <Button size="sm" variant="outline" onClick={() => updateRefund.mutate({ id: r.id, status: "approved" })}>
                        Approve
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => updateRefund.mutate({ id: r.id, status: "rejected" })}>
                        Reject
                      </Button>
                    </div>
                  )}
                  {r.status === "approved" && (
                    <Button size="sm" variant="outline" className="mt-3" onClick={() => updateRefund.mutate({ id: r.id, status: "paid" })}>
                      Mark paid
                    </Button>
                  )}
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>
          )}

          {canSee("drivers") && (
        <TabsContent value="drivers" className="mt-5 space-y-6">
          <Card>
            <CardContent className="p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <h3 className="text-sm font-semibold">Driver accounts &amp; verification</h3>
                  <p className="mt-1 text-xs max-w-xl text-muted-foreground">
                    There is no public driver sign-up. This is the only place a driver's login is created — after
                    you've recruited and (physically) verified them, create their account here and hand them the
                    temporary password shown once on screen.
                  </p>
                </div>
                <Dialog open={createDriverOpen} onOpenChange={setCreateDriverOpen}>
                  <DialogTrigger asChild>
                    <Button size="sm">
                      <Plus className="mr-1.5 h-4 w-4" /> Create driver account
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-h-[85vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>Create a driver account</DialogTitle>
                    </DialogHeader>
                    <form
                      className="space-y-3"
                      onSubmit={(e) => {
                        e.preventDefault();
                        createDriver.mutate(new FormData(e.currentTarget));
                      }}
                    >
                      <div className="grid gap-3 sm:grid-cols-2">
                        <div className="space-y-1.5">
                          <Label htmlFor="d_email">Login email</Label>
                          <Input id="d_email" name="email" type="email" required />
                        </div>
                        <div className="space-y-1.5">
                          <Label htmlFor="d_display_name">Display name (shown to buyers/sellers)</Label>
                          <Input id="d_display_name" name="display_name" required />
                        </div>
                      </div>
                      <div className="grid gap-3 sm:grid-cols-2">
                        <div className="space-y-1.5">
                          <Label htmlFor="d_legal_name">Full legal name</Label>
                          <Input id="d_legal_name" name="legal_name" required />
                        </div>
                        <div className="space-y-1.5">
                          <Label htmlFor="d_phone">Phone</Label>
                          <Input id="d_phone" name="phone" inputMode="tel" />
                        </div>
                      </div>
                      <div className="grid gap-3 sm:grid-cols-2">
                        <div className="space-y-1.5">
                          <Label htmlFor="d_license_number">Licence number</Label>
                          <Input id="d_license_number" name="license_number" />
                        </div>
                        <div className="space-y-1.5">
                          <Label htmlFor="d_license_expiry">Licence expiry</Label>
                          <Input id="d_license_expiry" name="license_expiry" type="date" />
                        </div>
                      </div>
                      <div className="grid gap-3 sm:grid-cols-3">
                        <div className="space-y-1.5">
                          <Label htmlFor="d_vehicle_type">Vehicle type</Label>
                          <Input id="d_vehicle_type" name="vehicle_type" />
                        </div>
                        <div className="space-y-1.5">
                          <Label htmlFor="d_plate_number">Plate number</Label>
                          <Input id="d_plate_number" name="plate_number" />
                        </div>
                        <div className="space-y-1.5">
                          <Label htmlFor="d_capacity_kg">Capacity (kg)</Label>
                          <Input id="d_capacity_kg" name="capacity_kg" type="number" min={0} />
                        </div>
                      </div>
                      <div className="space-y-1.5">
                        <Label htmlFor="d_branch_area">Branch / operating area (optional)</Label>
                        <Input id="d_branch_area" name="branch_area" />
                      </div>

                      <div className="space-y-2 rounded-lg border border-border p-3">
                        <p className="text-xs font-medium">Only check what you've actually verified in person:</p>
                        <label className="flex items-center gap-2 text-sm">
                          <input type="checkbox" name="identity_verified" /> Identity verified
                        </label>
                        <label className="flex items-center gap-2 text-sm">
                          <input type="checkbox" name="license_verified" /> Licence verified
                        </label>
                        <label className="flex items-center gap-2 text-sm">
                          <input type="checkbox" name="vehicle_verified" /> Vehicle verified
                        </label>
                        <label className="flex items-center gap-2 text-sm">
                          <input type="checkbox" name="approve_now" /> Approve for delivery assignments now
                        </label>
                      </div>

                      <DialogFooter>
                        <Button type="submit" disabled={createDriver.isPending}>
                          {createDriver.isPending ? "Creating…" : "Create account"}
                        </Button>
                      </DialogFooter>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>
              <div className="mt-4 space-y-3">
                {(drivers.data ?? []).length === 0 ? (
                  <EmptyState title="No driver applications yet" body="Applications submitted from the Logistics dashboard will appear here." />
                ) : (
                  (drivers.data ?? []).map((d) => (
                    <Card key={d.user_id} className={d.approval_status === "pending" ? "border-primary/40" : undefined}>
                      <CardContent className="p-4">
                        <div className="flex flex-wrap items-start justify-between gap-2">
                          <div>
                            <p className="text-sm font-medium">
                              {d.legal_name} <span className="text-muted-foreground">({d.display_name})</span>
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {d.phone ?? "no phone on file"} · applied {new Date(d.created_at).toLocaleDateString()}
                            </p>
                          </div>
                          <Badge
                            variant={
                              d.approval_status === "approved" ? "secondary" : d.approval_status === "pending" ? "default" : "outline"
                            }
                          >
                            {d.approval_status}
                          </Badge>
                        </div>

                        <div className="mt-3 grid gap-2 text-xs text-muted-foreground sm:grid-cols-3">
                          <span>Licence: {d.license_number ?? "—"} {d.license_expiry ? `(exp. ${d.license_expiry})` : ""} · {d.license_status}</span>
                          <span>Vehicle: {d.vehicle_type ?? "—"} {d.plate_number ?? ""} · {d.vehicle_status}</span>
                          <span>ID verification: {d.id_verification_status}</span>
                        </div>

                        <div className="mt-3 flex flex-wrap gap-2">
                          {d.id_verification_status === "pending" && (
                            <Button size="sm" variant="outline" onClick={() => updateDriverStatus.mutate({ userId: d.user_id, patch: { id_verification_status: "verified" } })}>
                              Verify ID
                            </Button>
                          )}
                          {d.license_status === "pending" && (
                            <Button size="sm" variant="outline" onClick={() => updateDriverStatus.mutate({ userId: d.user_id, patch: { license_status: "verified" } })}>
                              Verify licence
                            </Button>
                          )}
                          {d.vehicle_status === "pending" && (
                            <Button size="sm" variant="outline" onClick={() => updateDriverStatus.mutate({ userId: d.user_id, patch: { vehicle_status: "verified" } })}>
                              Verify vehicle
                            </Button>
                          )}
                          {d.approval_status === "pending" && (
                            <>
                              <Button
                                size="sm"
                                onClick={() => updateDriverStatus.mutate({ userId: d.user_id, patch: { approval_status: "approved" } })}
                              >
                                <ShieldCheck className="mr-1.5 h-3.5 w-3.5" /> Approve driver
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => updateDriverStatus.mutate({ userId: d.user_id, patch: { approval_status: "rejected" } })}
                              >
                                <ShieldX className="mr-1.5 h-3.5 w-3.5" /> Reject
                              </Button>
                            </>
                          )}
                          {d.approval_status === "approved" && (
                            <Button
                              size="sm"
                              variant="outline"
                              className="border-destructive/40 text-destructive hover:bg-destructive/10"
                              onClick={() => updateDriverStatus.mutate({ userId: d.user_id, patch: { approval_status: "suspended" } })}
                            >
                              Suspend
                            </Button>
                          )}
                          {d.approval_status === "suspended" && (
                            <Button
                              size="sm"
                              onClick={() => updateDriverStatus.mutate({ userId: d.user_id, patch: { approval_status: "approved" } })}
                            >
                              Reinstate
                            </Button>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-5">
              <h3 className="flex items-center gap-2 text-sm font-semibold">
                <Truck className="h-4 w-4" /> Unassigned delivery jobs
              </h3>
              <p className="mt-1 text-xs text-muted-foreground">
                Assign to an approved internal driver, or route to an external logistics partner company — jobs
                wait here until one of the two happens.
              </p>
              <div className="mt-4 space-y-2">
                {(unassignedDeliveries.data ?? []).length === 0 ? (
                  <p className="text-sm text-muted-foreground">Nothing waiting on assignment.</p>
                ) : (
                  (unassignedDeliveries.data ?? []).map((job) => (
                    <div key={job.id} className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border p-3">
                      <div>
                        <p className="text-sm">
                          {job.pickup_location} → {job.dropoff_location}
                        </p>
                        <p className="text-xs text-muted-foreground">Fee {naira(job.fee)}</p>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        <Select onValueChange={(driverId) => assignDriver.mutate({ deliveryId: job.id, driverId })}>
                          <SelectTrigger className="h-9 w-52 text-xs">
                            <SelectValue placeholder="Assign internal driver…" />
                          </SelectTrigger>
                          <SelectContent>
                            {(drivers.data ?? [])
                              .filter((d) => d.approval_status === "approved")
                              .map((d) => (
                                <SelectItem key={d.user_id} value={d.user_id}>
                                  {d.display_name} ({d.vehicle_type ?? "vehicle n/a"})
                                </SelectItem>
                              ))}
                          </SelectContent>
                        </Select>
                        <Select onValueChange={(partnerId) => routeToPartner.mutate({ deliveryId: job.id, partnerId })}>
                          <SelectTrigger className="h-9 w-52 text-xs">
                            <SelectValue placeholder="Route to partner company…" />
                          </SelectTrigger>
                          <SelectContent>
                            {(partners.data ?? [])
                              .filter((p) => p.status === "approved")
                              .map((p) => (
                                <SelectItem key={p.id} value={p.id}>
                                  {p.company_name}
                                </SelectItem>
                              ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <h3 className="text-sm font-semibold">External logistics partners</h3>
                  <p className="mt-1 max-w-xl text-xs text-muted-foreground">
                    A separate, controlled category from internal drivers — a partner company's own staff log in to
                    see only the jobs routed to them, and manage their own driver/vehicle assignment on their side.
                  </p>
                </div>
                <Dialog open={createPartnerOpen} onOpenChange={setCreatePartnerOpen}>
                  <DialogTrigger asChild>
                    <Button size="sm" variant="outline">
                      <Plus className="mr-1.5 h-4 w-4" /> Register partner company
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Register a logistics partner</DialogTitle>
                    </DialogHeader>
                    <form
                      className="space-y-3"
                      onSubmit={(e) => {
                        e.preventDefault();
                        createPartner.mutate(new FormData(e.currentTarget));
                      }}
                    >
                      <div className="space-y-1.5">
                        <Label htmlFor="p_company_name">Company name</Label>
                        <Input id="p_company_name" name="company_name" required />
                      </div>
                      <div className="grid gap-3 sm:grid-cols-2">
                        <div className="space-y-1.5">
                          <Label htmlFor="p_contact_name">Contact name</Label>
                          <Input id="p_contact_name" name="contact_name" required />
                        </div>
                        <div className="space-y-1.5">
                          <Label htmlFor="p_contact_phone">Contact phone</Label>
                          <Input id="p_contact_phone" name="contact_phone" inputMode="tel" />
                        </div>
                      </div>
                      <div className="space-y-1.5">
                        <Label htmlFor="p_contact_email">Contact email</Label>
                        <Input id="p_contact_email" name="contact_email" type="email" />
                      </div>
                      <div className="space-y-1.5">
                        <Label htmlFor="p_notes">Notes</Label>
                        <Textarea id="p_notes" name="notes" rows={2} />
                      </div>
                      <DialogFooter>
                        <Button type="submit" disabled={createPartner.isPending}>
                          {createPartner.isPending ? "Registering…" : "Register company"}
                        </Button>
                      </DialogFooter>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>

              <div className="mt-4 space-y-3">
                {(partners.data ?? []).length === 0 ? (
                  <EmptyState title="No partner companies yet" body="Register one to route delivery jobs their way." />
                ) : (
                  (partners.data ?? []).map((p) => {
                    const staffForPartner = (partnerStaff.data ?? []).filter((s) => s.partner_id === p.id);
                    return (
                      <Card key={p.id}>
                        <CardContent className="p-4">
                          <div className="flex flex-wrap items-start justify-between gap-2">
                            <div>
                              <p className="text-sm font-medium">{p.company_name}</p>
                              <p className="text-xs text-muted-foreground">
                                {p.contact_name} · {p.contact_phone ?? "no phone"} · {p.contact_email ?? "no email"}
                              </p>
                            </div>
                            <Badge variant={p.status === "approved" ? "secondary" : "outline"}>{p.status}</Badge>
                          </div>

                          {staffForPartner.length > 0 && (
                            <ul className="mt-3 space-y-1">
                              {staffForPartner.map((s) => (
                                <li key={s.user_id} className="text-xs text-muted-foreground">
                                  {s.display_name} {s.role_title ? `· ${s.role_title}` : ""}
                                </li>
                              ))}
                            </ul>
                          )}

                          <Dialog open={addStaffPartnerId === p.id} onOpenChange={(open) => setAddStaffPartnerId(open ? p.id : null)}>
                            <DialogTrigger asChild>
                              <Button size="sm" variant="outline" className="mt-3">
                                <Plus className="mr-1.5 h-3.5 w-3.5" /> Add staff login
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Add a staff login for {p.company_name}</DialogTitle>
                              </DialogHeader>
                              <form
                                className="space-y-3"
                                onSubmit={(e) => {
                                  e.preventDefault();
                                  createPartnerStaff.mutate(new FormData(e.currentTarget));
                                }}
                              >
                                <div className="space-y-1.5">
                                  <Label htmlFor="s_email">Login email</Label>
                                  <Input id="s_email" name="email" type="email" required />
                                </div>
                                <div className="space-y-1.5">
                                  <Label htmlFor="s_display_name">Display name</Label>
                                  <Input id="s_display_name" name="display_name" required />
                                </div>
                                <div className="space-y-1.5">
                                  <Label htmlFor="s_role_title">Role/title (optional)</Label>
                                  <Input id="s_role_title" name="role_title" placeholder="Dispatcher, Ops manager…" />
                                </div>
                                <DialogFooter>
                                  <Button type="submit" disabled={createPartnerStaff.isPending}>
                                    {createPartnerStaff.isPending ? "Creating…" : "Create login"}
                                  </Button>
                                </DialogFooter>
                              </form>
                            </DialogContent>
                          </Dialog>
                        </CardContent>
                      </Card>
                    );
                  })
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
          )}

          {isSuperAdmin && (
            <TabsContent value="staff" className="mt-5 space-y-6">
              <Card>
                <CardContent className="p-5">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <h3 className="text-sm font-semibold">Staff &amp; departments</h3>
                      <p className="mt-1 max-w-xl text-xs text-muted-foreground">
                        Every admin belongs to exactly one department and only sees that department's tools —
                        enforced by the database, not just hidden in this screen. Only a Super Admin can create or
                        change a department assignment.
                      </p>
                    </div>
                    <Dialog open={createStaffOpen} onOpenChange={setCreateStaffOpen}>
                      <DialogTrigger asChild>
                        <Button size="sm">
                          <Plus className="mr-1.5 h-4 w-4" /> Create admin account
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Create a department admin account</DialogTitle>
                        </DialogHeader>
                        <form
                          className="space-y-3"
                          onSubmit={(e) => {
                            e.preventDefault();
                            createDeptAdmin.mutate(new FormData(e.currentTarget));
                          }}
                        >
                          <div className="space-y-1.5">
                            <Label htmlFor="a_email">Login email</Label>
                            <Input id="a_email" name="email" type="email" required />
                          </div>
                          <div className="space-y-1.5">
                            <Label htmlFor="a_display_name">Display name</Label>
                            <Input id="a_display_name" name="display_name" required />
                          </div>
                          <div className="space-y-1.5">
                            <Label htmlFor="a_department">Department</Label>
                            <Select name="department" defaultValue="marketplace">
                              <SelectTrigger id="a_department">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                {Object.entries(DEPARTMENT_LABELS).map(([value, label]) => (
                                  <SelectItem key={value} value={value}>
                                    {label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-1.5">
                            <Label htmlFor="a_title">Title (optional)</Label>
                            <Input id="a_title" name="title" placeholder="e.g. Settlement Officer" />
                          </div>
                          <DialogFooter>
                            <Button type="submit" disabled={createDeptAdmin.isPending}>
                              {createDeptAdmin.isPending ? "Creating…" : "Create account"}
                            </Button>
                          </DialogFooter>
                        </form>
                      </DialogContent>
                    </Dialog>
                  </div>

                  <div className="mt-4 space-y-2">
                    {(allStaff.data ?? []).length === 0 ? (
                      <EmptyState title="No department admins yet" body="Create the first one above." />
                    ) : (
                      (allStaff.data ?? []).map((s) => (
                        <div key={s.user_id} className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-border p-3">
                          <div>
                            <p className="text-sm font-medium">{DEPARTMENT_LABELS[s.department] ?? s.department}</p>
                            <p className="text-xs text-muted-foreground">
                              {s.title ?? "no title"} · added {new Date(s.created_at).toLocaleDateString()}
                            </p>
                          </div>
                          <Badge variant={s.department === "super_admin" ? "default" : "secondary"}>{s.department}</Badge>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          )}

          {canSee("cases") && (
            <TabsContent value="cases" className="mt-5 space-y-3">
              <p className="text-xs text-muted-foreground">
                Every crop-health case on the platform, most recent first — oversight only; farmers and experts
                still own their own cases and reviews.
              </p>
              {(allCases.data ?? []).length === 0 ? (
                <EmptyState title="No cases yet" body="Crop-health scans will appear here once farmers start using it." />
              ) : (
                (allCases.data ?? []).map((c) => (
                  <Card key={c.id}>
                    <CardContent className="p-4">
                      <div className="flex flex-wrap items-start justify-between gap-2">
                        <div>
                          <p className="text-sm font-medium">
                            {c.crop_type} · AI: {c.ai_disease ?? "pending"} {c.ai_confidence ? `(${Math.round(Number(c.ai_confidence))}%)` : ""}
                          </p>
                          <p className="text-xs text-muted-foreground">{new Date(c.created_at).toLocaleString()}</p>
                        </div>
                        <Badge variant="secondary" className="capitalize">
                          {c.status.replace(/_/g, " ")}
                        </Badge>
                      </div>
                      {(c.expert_reviews ?? []).length > 0 && (
                        <p className="mt-2 text-xs text-muted-foreground">
                          Expert diagnosis: {(c.expert_reviews as { diagnosis: string }[])[0].diagnosis}
                        </p>
                      )}
                    </CardContent>
                  </Card>
                ))
              )}
            </TabsContent>
          )}

          {canSee("announcements") && (
            <TabsContent value="announcements" className="mt-5 space-y-6">
              <Card>
                <CardContent className="p-5">
                  <h3 className="text-sm font-semibold">Publish an announcement</h3>
                  <p className="mt-1 text-xs text-muted-foreground">Shown as a site-wide banner while active.</p>
                  <form
                    className="mt-4 space-y-3"
                    onSubmit={(e) => {
                      e.preventDefault();
                      saveAnnouncement.mutate(new FormData(e.currentTarget));
                      e.currentTarget.reset();
                    }}
                  >
                    <div className="space-y-1.5">
                      <Label htmlFor="an_title">Title</Label>
                      <Input id="an_title" name="title" required />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="an_body">Message</Label>
                      <Textarea id="an_body" name="body" rows={2} required />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="an_ends_at">Ends (optional)</Label>
                      <Input id="an_ends_at" name="ends_at" type="datetime-local" />
                    </div>
                    <Button type="submit" disabled={saveAnnouncement.isPending}>
                      {saveAnnouncement.isPending ? "Publishing…" : "Publish"}
                    </Button>
                  </form>
                </CardContent>
              </Card>

              <div className="space-y-2">
                {(announcements.data ?? []).map((a) => (
                  <Card key={a.id}>
                    <CardContent className="flex flex-wrap items-start justify-between gap-3 p-4">
                      <div>
                        <p className="text-sm font-medium">{a.title}</p>
                        <p className="text-xs text-muted-foreground">{a.body}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={a.is_active ? "default" : "outline"}>{a.is_active ? "Active" : "Off"}</Badge>
                        <Button size="sm" variant="outline" onClick={() => toggleAnnouncement.mutate({ id: a.id, is_active: !a.is_active })}>
                          {a.is_active ? "Turn off" : "Turn on"}
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => deleteAnnouncement.mutate(a.id)}>
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          )}

          {canSee("audit") && (
            <TabsContent value="audit" className="mt-5">
              <Card>
                <CardContent className="p-5">
                  <h3 className="flex items-center gap-2 text-sm font-semibold">
                    <History className="h-4 w-4" /> Audit log
                  </h3>
                  <p className="mt-1 text-xs text-muted-foreground">
                    Every sensitive change (fee tiers, driver approvals, refund decisions, admin/department
                    assignment) is recorded here automatically — who, what, and when.
                  </p>
                  <div className="mt-4 max-h-96 space-y-2 overflow-y-auto">
                    {(auditLog.data ?? []).length === 0 ? (
                      <p className="text-sm text-muted-foreground">No audit events yet.</p>
                    ) : (
                      (auditLog.data ?? []).map((a) => (
                        <div key={a.id} className="rounded-lg border border-border p-3 text-xs">
                          <div className="flex items-center justify-between">
                            <span className="font-medium">
                              {a.action} · {a.table_name}
                            </span>
                            <span className="text-muted-foreground">{new Date(a.created_at).toLocaleString()}</span>
                          </div>
                          <p className="mt-1 text-muted-foreground">record: {a.record_id ?? "—"}</p>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          )}
        </Tabs>
      )}

      {/* One-time credential reveal — shown immediately after account creation and never again. */}
      <Dialog open={!!newDriverCreds} onOpenChange={(open) => !open && setNewDriverCreds(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Account created</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">
            Hand these to the driver directly — this password is shown once and isn't stored anywhere.
          </p>
          <div className="rounded-lg border border-border bg-secondary/40 p-4 font-mono text-sm">
            <p>Email: {newDriverCreds?.email}</p>
            <p>Temporary password: {newDriverCreds?.temporaryPassword}</p>
          </div>
          <p className="text-xs text-muted-foreground">
            They'll log in at the normal AGROVIAX sign-in page and should change this password from Settings
            immediately.
          </p>
          <DialogFooter>
            <Button onClick={() => setNewDriverCreds(null)}>Done</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!newPartnerStaffCreds} onOpenChange={(open) => !open && setNewPartnerStaffCreds(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Partner staff account created</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">
            Send these to the partner company's staff member directly — shown once, not stored anywhere.
          </p>
          <div className="rounded-lg border border-border bg-secondary/40 p-4 font-mono text-sm">
            <p>Email: {newPartnerStaffCreds?.email}</p>
            <p>Temporary password: {newPartnerStaffCreds?.temporaryPassword}</p>
          </div>
          <DialogFooter>
            <Button onClick={() => setNewPartnerStaffCreds(null)}>Done</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <Card>
      <CardContent className="p-5">
        <p className="font-display text-2xl">{value}</p>
        <p className="text-xs uppercase tracking-widest text-muted-foreground">{label}</p>
      </CardContent>
    </Card>
  );
}
