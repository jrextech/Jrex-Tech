import { createFileRoute, Outlet } from "@tanstack/react-router";
import { DashboardShell } from "@/components/dashboard/DashboardShell";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "Your Dashboard | AGROVIAX" },
      { name: "description", content: "Your AGROVIAX workspace for farms, listings, crop health and logistics." },
      { property: "og:title", content: "AGROVIAX Dashboard" },
      { property: "og:description", content: "Your role-based agricultural workspace." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: () => (
    <DashboardShell>
      <Outlet />
    </DashboardShell>
  ),
});
