import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Stethoscope } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { PageHeading, EmptyState } from "@/components/dashboard/DashboardShell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";

export const Route = createFileRoute("/_authenticated/dashboard/expert")({ component: ExpertDesk });

function ExpertDesk() {
  const { user } = useAuth();
  const uid = user?.id;
  const qc = useQueryClient();

  const cases = useQuery({
    queryKey: ["expert-queue"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("disease_cases")
        .select("*, expert_reviews(id, diagnosis, recommendation)")
        .in("status", ["expert_requested", "expert_reviewed"])
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  const submitReview = useMutation({
    mutationFn: async ({ caseId, diagnosis, recommendation }: { caseId: string; diagnosis: string; recommendation: string }) => {
      const { error } = await supabase
        .from("expert_reviews")
        .insert({ case_id: caseId, expert_id: uid!, diagnosis, recommendation });
      if (error) throw error;
      const { error: statusError } = await supabase
        .from("disease_cases")
        .update({ status: "expert_reviewed" })
        .eq("id", caseId);
      if (statusError) throw statusError;
    },
    onSuccess: () => {
      toast.success("Review submitted to the farmer");
      void qc.invalidateQueries({ queryKey: ["expert-queue"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (cases.isLoading) return <Skeleton className="h-72" />;

  return (
    <div>
      <PageHeading title="Expert desk" description="Crop-health cases farmers have escalated for human review." />

      {(cases.data ?? []).length === 0 ? (
        <EmptyState title="Queue is clear" body="No farmer has requested an expert review right now." />
      ) : (
        <div className="space-y-4">
          {(cases.data ?? []).map((c) => {
            const reviewed = c.status === "expert_reviewed";
            return (
              <Card key={c.id}>
                <CardContent className="p-5">
                  <div className="flex flex-wrap items-start gap-4">
                    {c.media_url && (
                      <img
                        src={c.media_url}
                        alt={`${c.crop_type} case photo`}
                        className="h-28 w-28 shrink-0 rounded-lg border border-border object-cover"
                      />
                    )}
                    <div className="flex-1">
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div>
                          <h2 className="text-base font-semibold">
                            {c.crop_type} · AI says {c.ai_disease ?? "unknown"}
                          </h2>
                          <p className="mt-1 text-xs text-muted-foreground">{new Date(c.created_at).toLocaleString()}</p>
                        </div>
                        <Badge variant="secondary" className="capitalize">
                          {c.status.replace(/_/g, " ")}
                        </Badge>
                      </div>

                      {c.symptoms_note && <p className="mt-3 text-sm text-muted-foreground">Farmer note: {c.symptoms_note}</p>}
                      {c.ai_summary && <p className="mt-2 text-sm text-muted-foreground">AI summary: {c.ai_summary}</p>}
                    </div>
                  </div>

                  {!reviewed && (
                    <form
                      className="mt-4 space-y-3"
                      onSubmit={(e) => {
                        e.preventDefault();
                        const f = new FormData(e.currentTarget);
                        submitReview.mutate({
                          caseId: c.id,
                          diagnosis: String(f.get("diagnosis")),
                          recommendation: String(f.get("recommendation")),
                        });
                      }}
                    >
                      <Textarea name="diagnosis" rows={2} placeholder="Your diagnosis" required />
                      <Textarea name="recommendation" rows={3} placeholder="Recommended treatment and next steps" required />
                      <Button type="submit" size="sm" disabled={submitReview.isPending}>
                        <Stethoscope className="mr-1.5 h-4 w-4" /> Submit review
                      </Button>
                    </form>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
