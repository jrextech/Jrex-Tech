import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth, ROLE_LABELS } from "@/hooks/useAuth";
import { PageHeading } from "@/components/dashboard/DashboardShell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { NIGERIAN_STATES } from "@/lib/suggestions";

export const Route = createFileRoute("/_authenticated/dashboard/profile")({ component: Profile });

function Profile() {
  const { user, roles } = useAuth();
  const uid = user?.id;
  const qc = useQueryClient();

  const profile = useQuery({
    queryKey: ["profile", uid],
    enabled: !!uid,
    queryFn: async () => (await supabase.from("profiles").select("*").eq("id", uid!).maybeSingle()).data,
  });

  const save = useMutation({
    mutationFn: async (f: FormData) => {
      const payload = {
        full_name: String(f.get("full_name")),
        phone: String(f.get("phone")) || null,
        location: String(f.get("location")) || null,
        organization: String(f.get("organization")) || null,
        bio: String(f.get("bio")) || null,
      };
      const { error } = profile.data
        ? await supabase.from("profiles").update(payload).eq("id", uid!)
        : await supabase.from("profiles").insert({ id: uid!, ...payload });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Profile saved");
      void qc.invalidateQueries({ queryKey: ["profile", uid] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (profile.isLoading) return <Skeleton className="h-72" />;

  return (
    <div>
      <PageHeading title="Profile" description="How other people on AGROVIAX see you." />

      <Card className="max-w-2xl">
        <CardContent className="p-6">
          <div className="flex flex-wrap gap-2">
            {roles.map((r) => (
              <Badge key={r} variant="secondary">
                {ROLE_LABELS[r]}
              </Badge>
            ))}
            {profile.data?.verified && <Badge>Verified</Badge>}
          </div>

          <form
            className="mt-6 space-y-4"
            onSubmit={(e) => {
              e.preventDefault();
              save.mutate(new FormData(e.currentTarget));
            }}
          >
            <div className="space-y-1.5">
              <Label htmlFor="full_name">Full name</Label>
              <Input
                id="full_name"
                name="full_name"
                required
                defaultValue={profile.data?.full_name ?? (user?.user_metadata?.["full_name"] as string) ?? ""}
              />
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="phone">Phone</Label>
                <Input id="phone" name="phone" defaultValue={profile.data?.phone ?? ""} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="location">Location</Label>
                <Input id="location" name="location" list="ng-state-suggestions" defaultValue={profile.data?.location ?? ""} />
                <datalist id="ng-state-suggestions">
                  {NIGERIAN_STATES.map((s) => (
                    <option key={s} value={s} />
                  ))}
                </datalist>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="organization">Organisation</Label>
              <Input id="organization" name="organization" defaultValue={profile.data?.organization ?? ""} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="bio">About</Label>
              <Textarea id="bio" name="bio" rows={4} defaultValue={profile.data?.bio ?? ""} />
            </div>
            <p className="text-xs text-muted-foreground">Signed in as {user?.email}</p>
            <Button type="submit" disabled={save.isPending}>
              {save.isPending ? "Saving…" : "Save profile"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
