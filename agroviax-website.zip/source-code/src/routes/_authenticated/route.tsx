import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    // getSession() reads the already-persisted session from local storage —
    // it's synchronous-fast and reflects the session supabase.auth.signInWithPassword()
    // just set. getUser() instead makes a fresh network round-trip to re-verify the
    // token, which can race against that same sign-in call and bounce a user who
    // just logged in straight back to /auth. getSession() is what auth-gated routes
    // should use; only re-verify with getUser() for something security-sensitive.
    const { data, error } = await supabase.auth.getSession();
    if (error || !data.session) throw redirect({ to: "/auth", search: { mode: "signin" } });
    return { user: data.session.user };
  },
  component: () => <Outlet />,
});
