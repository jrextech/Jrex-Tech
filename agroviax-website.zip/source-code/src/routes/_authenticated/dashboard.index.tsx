import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Sprout, Store, Receipt, Wallet, ScanLine, Truck, ArrowRight, TrendingUp } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { PageHeading } from "@/components/dashboard/DashboardShell";
import { useAuth, ROLE_LABELS } from "@/hooks/useAuth";
import { naira } from "@/lib/cart";

export const Route = createFileRoute("/_authenticated/dashboard/")({
  component: Overview,
});

function Overview() {
  const { user, roles, primaryRole } = useAuth();
  const uid = user?.id;
  const manages = roles.some((r) => ["farmer", "business", "admin"].includes(r));
  const isExpert = roles.includes("expert");
  const isTransporter = roles.includes("transporter");

  const { data, isLoading } = useQuery({
    queryKey: ["dashboard-overview", uid, manages, isExpert],
    enabled: !!uid,
    queryFn: async () => {
      const [farms, crops, listings, buyOrders, sellOrders, expenses, incomes, cases, deliveries, pendingReviews] =
        await Promise.all([
          manages
            ? supabase.from("farms").select("id, name, location, size, size_unit").eq("owner_id", uid!)
            : Promise.resolve({ data: [] }),
          manages ? supabase.from("crops").select("id, crop_type, status").eq("owner_id", uid!) : Promise.resolve({ data: [] }),
          manages
            ? supabase.from("products").select("id, title, status, price, unit").eq("seller_id", uid!)
            : Promise.resolve({ data: [] }),
          supabase.from("orders").select("id, total_amount, status, created_at").eq("buyer_id", uid!),
          supabase.from("orders").select("id, total_amount, status, created_at").eq("seller_id", uid!),
          manages ? supabase.from("expenses").select("amount").eq("owner_id", uid!) : Promise.resolve({ data: [] }),
          manages ? supabase.from("incomes").select("amount").eq("owner_id", uid!) : Promise.resolve({ data: [] }),
          supabase.from("disease_cases").select("id, crop_type, status, created_at").eq("farmer_id", uid!),
          supabase.from("deliveries").select("id, status").eq("transporter_id", uid!),
          isExpert
            ? supabase.from("disease_cases").select("id", { count: "exact", head: true }).eq("status", "expert_requested")
            : Promise.resolve({ count: 0 }),
        ]);
      const sum = (rows: { amount: number }[] | null) => (rows ?? []).reduce((n, r) => n + Number(r.amount), 0);
      return {
        farms: farms.data ?? [],
        crops: crops.data ?? [],
        listings: listings.data ?? [],
        buyOrders: buyOrders.data ?? [],
        sellOrders: sellOrders.data ?? [],
        expenses: sum(expenses.data),
        incomes: sum(incomes.data),
        cases: cases.data ?? [],
        deliveries: deliveries.data ?? [],
        pendingReviews: pendingReviews.count ?? 0,
      };
    },
  });

  const name = (user?.user_metadata?.["full_name"] as string) ?? user?.email?.split("@")[0] ?? "there";

  if (isLoading || !data) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-10 w-64" />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <Skeleton key={i} className="h-28" />
          ))}
        </div>
      </div>
    );
  }

  const profit = data.incomes - data.expenses;

  const stats = manages
    ? [
        { label: "Farms", value: String(data.farms.length), icon: Sprout, to: "/dashboard/farms" as const },
        { label: "Active crops", value: String(data.crops.filter((c) => c.status !== "harvested").length), icon: Sprout, to: "/dashboard/farms" as const },
        { label: "Live listings", value: String(data.listings.filter((l) => l.status === "active").length), icon: Store, to: "/dashboard/listings" as const },
        { label: "Orders received", value: String(data.sellOrders.length), icon: Receipt, to: "/dashboard/orders" as const },
        { label: "Total income", value: naira(data.incomes), icon: Wallet, to: "/dashboard/finance" as const },
        { label: "Total expenses", value: naira(data.expenses), icon: Wallet, to: "/dashboard/finance" as const },
        { label: "Orders placed", value: String(data.buyOrders.length), icon: Receipt, to: "/dashboard/orders" as const },
        { label: "Crop-health cases", value: String(data.cases.length), icon: ScanLine, to: "/dashboard/cases" as const },
      ]
    : [
        { label: "Orders placed", value: String(data.buyOrders.length), icon: Receipt, to: "/dashboard/orders" as const },
        { label: "Crop-health cases", value: String(data.cases.length), icon: ScanLine, to: "/dashboard/cases" as const },
        ...(isTransporter
          ? [{ label: "Delivery jobs", value: String(data.deliveries.length), icon: Truck, to: "/dashboard/logistics" as const }]
          : []),
        ...(isExpert
          ? [{ label: "Pending reviews", value: String(data.pendingReviews), icon: ScanLine, to: "/dashboard/expert" as const }]
          : []),
      ];

  return (
    <div>
      <PageHeading
        title={`Welcome back, ${name}`}
        description={
          roles.length > 1
            ? `You hold ${roles.length} roles: ${roles.map((r) => ROLE_LABELS[r]).join(", ")}.`
            : `Your ${ROLE_LABELS[primaryRole].toLowerCase()} workspace across the agricultural cycle.`
        }
        action={
          <Button asChild>
            <Link to="/marketplace">
              Go to marketplace <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => (
          <Link key={s.label} to={s.to}>
            <Card className="h-full transition-shadow hover:shadow-md">
              <CardContent className="p-5">
                <s.icon className="h-5 w-5 text-primary" />
                <p className="mt-3 font-display text-2xl">{s.value}</p>
                <p className="text-xs uppercase tracking-widest text-muted-foreground">{s.label}</p>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        {manages && (
          <Card className="lg:col-span-1">
            <CardContent className="p-5">
              <div className="flex items-center gap-2">
                <TrendingUp className={`h-5 w-5 ${profit >= 0 ? "text-success" : "text-destructive"}`} />
                <h2 className="text-base font-semibold">Season profit</h2>
              </div>
              <p className={`mt-3 font-display text-3xl ${profit >= 0 ? "text-forest" : "text-destructive"}`}>
                {naira(profit)}
              </p>
              <p className="mt-1 text-xs text-muted-foreground">
                {naira(data.incomes)} income − {naira(data.expenses)} expenses
              </p>
              <Button asChild variant="outline" size="sm" className="mt-4">
                <Link to="/dashboard/finance">Open finance</Link>
              </Button>
            </CardContent>
          </Card>
        )}

        <Card className={manages ? "lg:col-span-2" : "lg:col-span-3"}>
          <CardContent className="p-5">
            <h2 className="text-base font-semibold">Recent orders</h2>
            {[...data.buyOrders, ...data.sellOrders].length === 0 ? (
              <p className="mt-3 text-sm text-muted-foreground">No orders yet — browse the marketplace to get started.</p>
            ) : (
              <ul className="mt-3 divide-y divide-border">
                {[...data.buyOrders, ...data.sellOrders]
                  .sort((a, b) => (a.created_at < b.created_at ? 1 : -1))
                  .slice(0, 5)
                  .map((o) => (
                    <li key={o.id} className="flex items-center justify-between py-2.5 text-sm">
                      <span className="font-mono text-xs text-muted-foreground">#{o.id.slice(0, 8)}</span>
                      <Badge variant="secondary" className="capitalize">
                        {o.status}
                      </Badge>
                      <span className="font-medium">{naira(o.total_amount)}</span>
                    </li>
                  ))}
              </ul>
            )}
            <Button asChild variant="outline" size="sm" className="mt-4">
              <Link to="/dashboard/orders">All orders</Link>
            </Button>
          </CardContent>
        </Card>
      </div>

      {isExpert && (
        <Card className="mt-6">
          <CardContent className="p-5">
            <div className="flex items-center gap-2">
              <ScanLine className="h-5 w-5 text-primary" />
              <h2 className="text-base font-semibold">Expert desk</h2>
            </div>
            <p className="mt-2 text-sm text-muted-foreground">
              {data.pendingReviews} case{data.pendingReviews === 1 ? "" : "s"} waiting for your review.
            </p>
            <Button asChild variant="outline" size="sm" className="mt-4">
              <Link to="/dashboard/expert">Open expert desk</Link>
            </Button>
          </CardContent>
        </Card>
      )}

      {roles.includes("transporter") && (
        <Card className="mt-6">
          <CardContent className="p-5">
            <div className="flex items-center gap-2">
              <Truck className="h-5 w-5 text-primary" />
              <h2 className="text-base font-semibold">Delivery jobs</h2>
            </div>
            <p className="mt-2 text-sm text-muted-foreground">
              {data.deliveries.length} assigned · {data.deliveries.filter((d) => d.status !== "delivered").length} in
              progress
            </p>
            <Button asChild variant="outline" size="sm" className="mt-4">
              <Link to="/dashboard/logistics">Open logistics</Link>
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
