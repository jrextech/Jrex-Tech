import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Mail, Phone, MapPin, Send } from "lucide-react";
import { toast } from "sonner";
import { PublicLayout, PageHero } from "@/components/site/PublicLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact AGROVIAX — Support for Farmers & Buyers" },
      {
        name: "description",
        content:
          "Get in touch with the AGROVIAX team about accounts, verification, marketplace orders, logistics or partnership enquiries.",
      },
      { property: "og:title", content: "Contact AGROVIAX" },
      { property: "og:description", content: "Support and partnership enquiries for the AGROVIAX platform." },
    ],
  }),
  component: Contact,
});

const CHANNELS = [
  { icon: Mail, label: "Email", value: "support@agroviax.com" },
  { icon: Phone, label: "Phone & WhatsApp", value: "+234 800 000 0000" },
  { icon: MapPin, label: "Office", value: "Agricultural Innovation Hub, Abuja" },
];

function Contact() {
  const [sending, setSending] = useState(false);

  return (
    <PublicLayout>
      <PageHero
        eyebrow="Contact"
        title="Talk to the AGROVIAX team"
        description="Questions about verification, an order, a delivery or a partnership? Send us a message and we'll come back to you."
      />

      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 lg:grid-cols-[1fr_1.3fr]">
        <div className="space-y-5">
          {CHANNELS.map((c) => (
            <div key={c.label} className="flex gap-4 rounded-xl border border-border bg-card p-5">
              <c.icon className="h-5 w-5 shrink-0 text-primary" />
              <div>
                <p className="text-xs uppercase tracking-widest text-muted-foreground">{c.label}</p>
                <p className="mt-1 text-sm font-medium">{c.value}</p>
              </div>
            </div>
          ))}
          <div className="rounded-xl border border-border bg-secondary/40 p-5 text-sm text-muted-foreground">
            Support hours are Monday to Saturday, 8am to 6pm. Marketplace order issues are prioritised.
          </div>
        </div>

        <form
          className="space-y-5 rounded-xl border border-border bg-card p-6"
          onSubmit={async (e) => {
            e.preventDefault();
            const form = e.currentTarget;
            const data = new FormData(form);
            const name = String(data.get("name") ?? "").trim();
            const email = String(data.get("email") ?? "").trim();
            const subject = String(data.get("subject") ?? "").trim();
            const body = String(data.get("message") ?? "").trim();
            if (!name || !email || !subject || !body) return;

            setSending(true);
            const { error } = await supabase.from("contact_messages").insert({ name, email, subject, body });
            setSending(false);

            if (error) {
              toast.error("Couldn't send your message — please try again.");
              return;
            }
            form.reset();
            toast.success("Message received — we'll be in touch shortly.");
          }}
        >
          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <Label htmlFor="name">Full name</Label>
              <Input id="name" name="name" required className="mt-2" placeholder="Your name" />
            </div>
            <div>
              <Label htmlFor="email">Email</Label>
              <Input id="email" name="email" type="email" required className="mt-2" placeholder="you@example.com" />
            </div>
          </div>
          <div>
            <Label htmlFor="subject">Subject</Label>
            <Input id="subject" name="subject" required className="mt-2" placeholder="What is this about?" />
          </div>
          <div>
            <Label htmlFor="message">Message</Label>
            <Textarea id="message" name="message" required rows={6} className="mt-2" placeholder="Tell us more…" />
          </div>
          <Button type="submit" disabled={sending} size="lg">
            <Send className="mr-2 h-4 w-4" />
            {sending ? "Sending…" : "Send message"}
          </Button>
        </form>
      </div>
    </PublicLayout>
  );
}
