import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { TrendingUp, TrendingDown, Minus, Search } from "lucide-react";
import { PublicLayout, PageHero } from "@/components/site/PublicLayout";
import { Input } from "@/components/ui/input";
import { listMarketPrices } from "@/lib/public.functions";

const pricesQuery = queryOptions({ queryKey: ["market-prices"], queryFn: () => listMarketPrices() });

export const Route = createFileRoute("/market-prices")({
  head: () => ({
    meta: [
      { title: "Live Crop Market Prices by Region | AGROVIAX" },
      {
        name: "description",
        content:
          "Compare current crop prices across agricultural markets and regions, with movement against the previous recorded price.",
      },
      { property: "og:title", content: "Live Crop Market Prices | AGROVIAX" },
      { property: "og:description", content: "Crop prices by market and region, updated regularly." },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(pricesQuery),
  component: MarketPrices,
});

function MarketPrices() {
  const { data } = useSuspenseQuery(pricesQuery);
  const [search, setSearch] = useState("");
  const [region, setRegion] = useState("all");

  const regions = useMemo(
    () => Array.from(new Set(data.prices.map((p) => p.region).filter(Boolean))) as string[],
    [data.prices],
  );

  const rows = data.prices.filter(
    (p) =>
      (region === "all" || p.region === region) &&
      (!search ||
        p.crop_type.toLowerCase().includes(search.toLowerCase()) ||
        p.market_name.toLowerCase().includes(search.toLowerCase())),
  );

  return (
    <PublicLayout>
      <PageHero
        eyebrow="Market intelligence"
        title="Know what your crop is worth before you sell it."
        description="Prices recorded across tracked markets and regions, with the direction of movement against the last recording, so you can time the sale and pick the right market."
      />

      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
        <div className="flex flex-col gap-4 sm:flex-row">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search crop or market…"
              className="pl-9"
            />
          </div>
          <select
            value={region}
            onChange={(e) => setRegion(e.target.value)}
            className="h-10 rounded-md border border-input bg-background px-3 text-sm"
          >
            <option value="all">All regions</option>
            {regions.map((r) => (
              <option key={r} value={r}>
                {r}
              </option>
            ))}
          </select>
        </div>

        <div className="mt-8 overflow-hidden rounded-xl border border-border">
          <table className="w-full text-left text-sm">
            <thead className="bg-secondary/60 text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="px-4 py-3">Crop</th>
                <th className="px-4 py-3">Market</th>
                <th className="hidden px-4 py-3 sm:table-cell">Region</th>
                <th className="px-4 py-3 text-right">Price</th>
                <th className="px-4 py-3 text-right">Change</th>
                <th className="hidden px-4 py-3 text-right md:table-cell">Recorded</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border bg-card">
              {rows.map((p) => {
                const prev = p.previous_price ? Number(p.previous_price) : null;
                const change = prev ? Number(p.price) - prev : 0;
                const pct = prev ? (change / prev) * 100 : 0;
                return (
                  <tr key={p.id} className="hover:bg-secondary/30">
                    <td className="px-4 py-3 font-medium">{p.crop_type}</td>
                    <td className="px-4 py-3 text-muted-foreground">{p.market_name}</td>
                    <td className="hidden px-4 py-3 text-muted-foreground sm:table-cell">{p.region}</td>
                    <td className="px-4 py-3 text-right font-display text-base">
                      ₦{Number(p.price).toLocaleString()}
                      <span className="text-xs text-muted-foreground">/{p.unit}</span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <span
                        className={`inline-flex items-center gap-1 text-xs font-medium ${
                          change > 0 ? "text-success" : change < 0 ? "text-destructive" : "text-muted-foreground"
                        }`}
                      >
                        {change > 0 ? (
                          <TrendingUp className="h-3.5 w-3.5" />
                        ) : change < 0 ? (
                          <TrendingDown className="h-3.5 w-3.5" />
                        ) : (
                          <Minus className="h-3.5 w-3.5" />
                        )}
                        {change === 0 ? "0%" : `${pct > 0 ? "+" : ""}${pct.toFixed(1)}%`}
                      </span>
                    </td>
                    <td className="hidden px-4 py-3 text-right text-xs text-muted-foreground md:table-cell">
                      {p.recorded_on}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {rows.length === 0 && (
          <p className="mt-6 text-center text-sm text-muted-foreground">No price records match your filters.</p>
        )}
      </div>
    </PublicLayout>
  );
}
