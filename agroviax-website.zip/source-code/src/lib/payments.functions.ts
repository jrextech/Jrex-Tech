import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { supabaseAdmin } from "@/integrations/supabase/admin";
import { initializeTransaction, listBanks } from "@/lib/paystack";

/**
 * Starts a Paystack charge for an order that already exists (created by
 * CartDrawer's checkout mutation with status 'pending'). Deliberately does
 * NOT trust an amount passed from the browser — it re-reads the order's
 * real total_amount from the database using the admin client and charges
 * that, so a tampered client request can't pay less than the real total.
 */
const InitializePaymentInput = z.object({
  orderId: z.string().uuid(),
  buyerEmail: z.string().email(),
  callbackUrl: z.string().url(),
});

export const initializePayment = createServerFn({ method: "POST" })
  .validator(InitializePaymentInput)
  .handler(async ({ data }) => {
    const db = supabaseAdmin();

    const { data: order, error } = await db
      .from("orders")
      .select("id, buyer_id, total_amount, platform_fee, transport_fee, seller_payout_amount, status")
      .eq("id", data.orderId)
      .single();
    if (error || !order) throw new Error("Order not found.");
    if (order.status !== "pending") throw new Error("This order has already been paid or is no longer payable.");

    const reference = `agx_${order.id}_${Date.now()}`;

    const { data: existingPayment } = await db.from("payments").select("id").eq("order_id", order.id).maybeSingle();
    if (existingPayment) throw new Error("A payment already exists for this order.");

    const transaction = await initializeTransaction({
      email: data.buyerEmail,
      amountNaira: Number(order.total_amount),
      reference,
      callbackUrl: data.callbackUrl,
      metadata: { order_id: order.id },
    });

    const { error: insertError } = await db.from("payments").insert({
      order_id: order.id,
      provider: "paystack",
      reference,
      amount: order.total_amount,
      platform_amount: order.platform_fee,
      seller_amount: order.seller_payout_amount ?? 0,
      transport_amount: order.transport_fee,
      status: "pending",
    });
    if (insertError) throw new Error("Could not record the payment attempt: " + insertError.message);

    return { authorizationUrl: transaction.authorization_url, reference };
  });

/** Nigerian bank list for the payout-details dropdown in Settings. */
export const getBankList = createServerFn({ method: "GET" }).handler(async () => {
  return listBanks();
});
