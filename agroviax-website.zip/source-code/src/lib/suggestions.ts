// Shared suggestion lists used as <datalist> options across the app's forms
// (native browser autocomplete — no extra library needed). Keeping these in
// one place means every "crop name" or "location" field suggests the same
// consistent values.

export const COMMON_CROPS = [
  "Maize", "Rice", "Tomato", "Cassava", "Cowpea", "Yam", "Pepper", "Onion",
  "Plantain", "Groundnut", "Millet", "Sorghum", "Soybean", "Cucumber",
  "Watermelon", "Okra", "Sesame", "Palm Oil", "Beans", "Ginger",
];

export const NIGERIAN_STATES = [
  "Abia", "Adamawa", "Akwa Ibom", "Anambra", "Bauchi", "Bayelsa", "Benue",
  "Borno", "Cross River", "Delta", "Ebonyi", "Edo", "Ekiti", "Enugu",
  "FCT (Abuja)", "Gombe", "Imo", "Jigawa", "Kaduna", "Kano", "Katsina",
  "Kebbi", "Kogi", "Kwara", "Lagos", "Nasarawa", "Niger", "Ogun", "Ondo",
  "Osun", "Oyo", "Plateau", "Rivers", "Sokoto", "Taraba", "Yobe", "Zamfara",
];

export const EXPENSE_CATEGORIES = [
  "Seeds", "Fertilizer", "Crop protection", "Labour", "Irrigation",
  "Equipment rental", "Fuel", "Transport", "Storage", "Packaging",
];
