export type ThemeChoice = "light" | "dark" | "system";
const KEY = "agroviax-theme";

export function getStoredTheme(): ThemeChoice {
  if (typeof window === "undefined") return "system";
  return (localStorage.getItem(KEY) as ThemeChoice) || "system";
}

export function applyTheme(choice: ThemeChoice) {
  if (typeof document === "undefined") return;
  const prefersDark = window.matchMedia?.("(prefers-color-scheme: dark)").matches;
  const dark = choice === "dark" || (choice === "system" && prefersDark);
  document.documentElement.classList.toggle("dark", dark);
}

export function setTheme(choice: ThemeChoice) {
  localStorage.setItem(KEY, choice);
  applyTheme(choice);
}
