import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { supabaseAdmin } from "@/integrations/supabase/admin";
import { createTransferRecipient, initiateTransfer } from "@/lib/paystack";

/**
 * Pays the seller (and transporter, if one was used) their share of an
 * order — the "release" step of the escrow flow. Only call this after the
 * BUYER has confirmed receipt (dashboard.orders.tsx sets buyer_confirmed_at
 * and calls this). Deliberately does not trust the caller's word about
 * which order or how much — it re-derives everything from the database.
 *
 * Idempotent: if payment.status is already 'released', this is a no-op,
 * so a double-click or retry can't pay someone twice.
 */
const ReleaseFundsInput = z.object({ orderId: z.string().uuid() });

async function payoutRecipient(
  userId: string,
  amountNaira: number,
  reason: string,
  orderId: string,
  db: ReturnType<typeof supabaseAdmin>,
) {
  if (amountNaira <= 0) return;

  const { data: account } = await db.from("payout_accounts").select("*").eq("user_id", userId).maybeSingle();
  if (!account) throw new Error(`Recipient has no payout account on file (user ${userId}). Payout skipped — resolve manually.`);

  let recipientCode = account.paystack_recipient_code;
  if (!recipientCode) {
    const recipient = await createTransferRecipient({
      name: account.account_name,
      accountNumber: account.account_number,
      bankCode: account.bank_code,
    });
    recipientCode = recipient.recipient_code;
    await db.from("payout_accounts").update({ paystack_recipient_code: recipientCode }).eq("user_id", userId);
  }

  await initiateTransfer({
    amountNaira,
    recipientCode,
    reason,
    reference: `agx_payout_${orderId}_${userId}_${Date.now()}`,
  });
}

export const releaseFunds = createServerFn({ method: "POST" })
  .validator(ReleaseFundsInput)
  .handler(async ({ data }) => {
    const db = supabaseAdmin();

    const { data: order, error } = await db
      .from("orders")
      .select("id, seller_id, buyer_confirmed_at, seller_payout_amount, transport_fee, delivery_option, deliveries(transporter_id)")
      .eq("id", data.orderId)
      .single();
    if (error || !order) throw new Error("Order not found.");
    if (!order.buyer_confirmed_at) throw new Error("Funds can only be released after the buyer confirms receipt.");

    const { data: payment } = await db.from("payments").select("*").eq("order_id", order.id).maybeSingle();
    if (!payment) throw new Error("No payment record for this order — nothing to release.");
    if (payment.status !== "paid") {
      if (payment.status === "released") return { alreadyReleased: true };
      throw new Error(`Payment status is "${payment.status}", not "paid" — cannot release yet.`);
    }

    if (order.seller_id) {
      await payoutRecipient(order.seller_id, Number(order.seller_payout_amount ?? 0), `AGROVIAX order ${order.id}`, order.id, db);
    }

    const transporterId = (order.deliveries as unknown as { transporter_id: string | null }[] | null)?.[0]?.transporter_id;
    if (order.delivery_option === "need_transport" && transporterId) {
      await payoutRecipient(transporterId, Number(order.transport_fee ?? 0), `AGROVIAX delivery for order ${order.id}`, order.id, db);
    }

    await db.from("payments").update({ status: "released" }).eq("id", payment.id);
    return { released: true };
  });
