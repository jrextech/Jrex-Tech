import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const AnalyzeInput = z.object({
  imageDataUrl: z.string().min(32),
  cropType: z.string().min(1).max(80),
  notes: z.string().max(1000).optional(),
});

export type CropAnalysis = {
  disease: string;
  confidence: number;
  severity: "low" | "moderate" | "high";
  summary: string;
  symptoms: string[];
  treatment: string[];
  prevention: string[];
  expertRecommended: boolean;
};

export const analyzeCropPhoto = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => AnalyzeInput.parse(input))
  .handler(async ({ data }): Promise<CropAnalysis> => {
    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) throw new Error("AI is not configured for this project.");

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "google/gemini-3.6-flash",
        messages: [
          {
            role: "system",
            content:
              "You are an agricultural plant pathologist. Analyse the crop photo and respond ONLY with JSON matching: {\"disease\": string, \"confidence\": number 0-100, \"severity\": \"low\"|\"moderate\"|\"high\", \"summary\": string, \"symptoms\": string[], \"treatment\": string[], \"prevention\": string[], \"expertRecommended\": boolean}. Use practical, low-cost measures suited to smallholder farms. If the photo is not a plant, set disease to \"Unclear image\" and confidence to 0.",
          },
          {
            role: "user",
            content: [
              {
                type: "text",
                text: `Crop type: ${data.cropType}. Farmer's notes: ${data.notes || "none provided"}.`,
              },
              { type: "image_url", image_url: { url: data.imageDataUrl } },
            ],
          },
        ],
        response_format: { type: "json_object" },
      }),
    });

    if (!response.ok) {
      const body = await response.text();
      if (response.status === 429) throw new Error("Too many analyses right now — please try again shortly.");
      if (response.status === 402) throw new Error("AI credits are exhausted for this workspace.");
      throw new Error(`Crop analysis failed [${response.status}]: ${body.slice(0, 200)}`);
    }

    const payload = (await response.json()) as { choices?: Array<{ message?: { content?: string } }> };
    const raw = payload.choices?.[0]?.message?.content ?? "{}";
    const parsed = JSON.parse(raw) as Partial<CropAnalysis>;

    return {
      disease: parsed.disease ?? "Undetermined",
      confidence: Math.max(0, Math.min(100, Number(parsed.confidence ?? 0))),
      severity: parsed.severity ?? "moderate",
      summary: parsed.summary ?? "",
      symptoms: parsed.symptoms ?? [],
      treatment: parsed.treatment ?? [],
      prevention: parsed.prevention ?? [],
      expertRecommended: parsed.expertRecommended ?? true,
    };
  });
