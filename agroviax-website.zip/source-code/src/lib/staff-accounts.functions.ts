import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { supabaseAdmin } from "@/integrations/supabase/admin";

/**
 * Both functions below use the service-role client, which bypasses RLS
 * entirely — so unlike ordinary queries, RLS cannot be the thing that stops
 * a non-admin from calling this. Every handler re-verifies the CALLER is a
 * real admin by checking the access token they pass in against Supabase
 * Auth and the user_roles table, before doing anything. Never trust that a
 * button was only rendered for admins — the server call itself must refuse
 * a non-admin caller even if they somehow invoke it directly.
 */
async function requireAdmin(callerAccessToken: string) {
  const db = supabaseAdmin();
  const { data: userResult, error } = await db.auth.getUser(callerAccessToken);
  if (error || !userResult.user) throw new Error("Not signed in.");

  const { data: roleRow } = await db
    .from("user_roles")
    .select("role")
    .eq("user_id", userResult.user.id)
    .eq("role", "admin")
    .maybeSingle();
  if (!roleRow) throw new Error("Only an AGROVIAX admin can do this.");

  return userResult.user;
}

function randomPassword() {
  // 12 random bytes -> base64url-ish, trimmed to a readable temp password.
  const bytes = crypto.getRandomValues(new Uint8Array(12));
  return Array.from(bytes, (b) => b.toString(36).padStart(2, "0")).join("").slice(0, 16);
}

const CreateDriverInput = z.object({
  callerAccessToken: z.string(),
  email: z.string().email(),
  legalName: z.string().min(1),
  displayName: z.string().min(1),
  phone: z.string().optional(),
  licenseNumber: z.string().optional(),
  licenseExpiry: z.string().optional(),
  vehicleType: z.string().optional(),
  plateNumber: z.string().optional(),
  capacityKg: z.number().optional(),
  branchArea: z.string().optional(),
  // The admin marks these true only once they've physically verified them
  // (Section 4A) — nothing here is auto-verified just because an admin
  // typed it into a form.
  identityVerified: z.boolean(),
  licenseVerified: z.boolean(),
  vehicleVerified: z.boolean(),
  approveNow: z.boolean(),
});

/**
 * Creates a real login for a driver AGROVIAX has recruited and vetted
 * offline. There is no public sign-up path for this role (Logistics
 * Architecture Update, "Staff-Only Driver Portal") — this function is the
 * only way a drivers row and its auth account come into existence.
 * Returns a one-time temporary password for the admin to relay to the
 * driver directly (matching the physical-recruitment handoff described in
 * the plan) — it is never stored anywhere and never shown again.
 */
export const createDriverAccount = createServerFn({ method: "POST" })
  .validator(CreateDriverInput)
  .handler(async ({ data }) => {
    const admin = await requireAdmin(data.callerAccessToken);
    const db = supabaseAdmin();

    const tempPassword = randomPassword();
    const { data: created, error: createError } = await db.auth.admin.createUser({
      email: data.email,
      password: tempPassword,
      email_confirm: true,
      user_metadata: { full_name: data.displayName },
    });
    if (createError || !created.user) throw new Error(createError?.message || "Could not create the driver's account.");

    const { error: roleError } = await db.from("user_roles").insert({ user_id: created.user.id, role: "transporter" });
    if (roleError) throw new Error("Account created, but assigning the transporter role failed: " + roleError.message);

    const { error: driverError } = await db.from("drivers").insert({
      user_id: created.user.id,
      legal_name: data.legalName,
      display_name: data.displayName,
      phone: data.phone || null,
      license_number: data.licenseNumber || null,
      license_expiry: data.licenseExpiry || null,
      vehicle_type: data.vehicleType || null,
      plate_number: data.plateNumber || null,
      capacity_kg: data.capacityKg ?? null,
      branch_area: data.branchArea || null,
      id_verification_status: data.identityVerified ? "verified" : "pending",
      license_status: data.licenseVerified ? "verified" : "pending",
      vehicle_status: data.vehicleVerified ? "verified" : "pending",
      approval_status: data.approveNow ? "approved" : "pending",
      approved_by: data.approveNow ? admin.id : null,
      approved_at: data.approveNow ? new Date().toISOString() : null,
      operational_status: data.approveNow ? "available" : "inactive",
      employment_status: data.approveNow ? "active" : "pending",
      created_by: admin.id,
    });
    if (driverError) throw new Error("Account created, but the driver record failed to save: " + driverError.message);

    return { email: data.email, temporaryPassword: tempPassword };
  });

const CreatePartnerInput = z.object({
  callerAccessToken: z.string(),
  companyName: z.string().min(1),
  contactName: z.string().min(1),
  contactEmail: z.string().email().optional(),
  contactPhone: z.string().optional(),
  notes: z.string().optional(),
});

/** Registers a new external logistics partner company. Not yet a login — see createPartnerStaffAccount. */
export const createLogisticsPartner = createServerFn({ method: "POST" })
  .validator(CreatePartnerInput)
  .handler(async ({ data }) => {
    const admin = await requireAdmin(data.callerAccessToken);
    const db = supabaseAdmin();
    const { data: partner, error } = await db
      .from("logistics_partners")
      .insert({
        company_name: data.companyName,
        contact_name: data.contactName,
        contact_email: data.contactEmail || null,
        contact_phone: data.contactPhone || null,
        notes: data.notes || null,
        status: "approved",
        created_by: admin.id,
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { partnerId: partner.id };
  });

const CreatePartnerStaffInput = z.object({
  callerAccessToken: z.string(),
  partnerId: z.string().uuid(),
  email: z.string().email(),
  displayName: z.string().min(1),
  roleTitle: z.string().optional(),
});

/** Creates a login for a named staff member at an already-registered partner company. */
export const createPartnerStaffAccount = createServerFn({ method: "POST" })
  .validator(CreatePartnerStaffInput)
  .handler(async ({ data }) => {
    await requireAdmin(data.callerAccessToken);
    const db = supabaseAdmin();

    const tempPassword = randomPassword();
    const { data: created, error: createError } = await db.auth.admin.createUser({
      email: data.email,
      password: tempPassword,
      email_confirm: true,
      user_metadata: { full_name: data.displayName },
    });
    if (createError || !created.user) throw new Error(createError?.message || "Could not create the partner staff account.");

    const { error: staffError } = await db.from("logistics_partner_staff").insert({
      user_id: created.user.id,
      partner_id: data.partnerId,
      display_name: data.displayName,
      role_title: data.roleTitle || null,
    });
    if (staffError) throw new Error("Account created, but linking it to the partner company failed: " + staffError.message);

    const { error: roleError } = await db.from("user_roles").insert({ user_id: created.user.id, role: "logistics_partner" });
    if (roleError) throw new Error("Account created, but assigning the partner role failed: " + roleError.message);

    return { email: data.email, temporaryPassword: tempPassword };
  });

const CreateDepartmentAdminInput = z.object({
  callerAccessToken: z.string(),
  email: z.string().email(),
  displayName: z.string().min(1),
  department: z.enum([
    "super_admin", "finance", "marketplace", "agriculture", "logistics", "support", "marketing", "it_security",
  ]),
  title: z.string().optional(),
});

/**
 * Creates a login for a new department admin. Only an existing super_admin
 * may call this — requireSuperAdmin() checks the *specific* department, not
 * just "is some kind of admin", so a Finance Admin can't use this to mint
 * themselves a super_admin account. This is the actual enforcement; the
 * admin dashboard only shows this form to super_admins as a courtesy, it
 * isn't what makes this safe.
 */
async function requireSuperAdmin(callerAccessToken: string) {
  const db = supabaseAdmin();
  const { data: userResult, error } = await db.auth.getUser(callerAccessToken);
  if (error || !userResult.user) throw new Error("Not signed in.");

  const { data: staffRow } = await db
    .from("admin_staff")
    .select("department")
    .eq("user_id", userResult.user.id)
    .eq("department", "super_admin")
    .maybeSingle();
  if (!staffRow) throw new Error("Only an AGROVIAX Super Admin can create department admin accounts.");

  return userResult.user;
}

export const createDepartmentAdminAccount = createServerFn({ method: "POST" })
  .validator(CreateDepartmentAdminInput)
  .handler(async ({ data }) => {
    const superAdmin = await requireSuperAdmin(data.callerAccessToken);
    const db = supabaseAdmin();

    const tempPassword = randomPassword();
    const { data: created, error: createError } = await db.auth.admin.createUser({
      email: data.email,
      password: tempPassword,
      email_confirm: true,
      user_metadata: { full_name: data.displayName },
    });
    if (createError || !created.user) throw new Error(createError?.message || "Could not create the admin account.");

    const { error: roleError } = await db.from("user_roles").insert({ user_id: created.user.id, role: "admin" });
    if (roleError) throw new Error("Account created, but assigning the admin role failed: " + roleError.message);

    const { error: staffError } = await db.from("admin_staff").insert({
      user_id: created.user.id,
      department: data.department,
      title: data.title || null,
      created_by: superAdmin.id,
    });
    if (staffError) throw new Error("Account created, but assigning the department failed: " + staffError.message);

    return { email: data.email, temporaryPassword: tempPassword };
  });
