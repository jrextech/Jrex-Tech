/**
 * Server-only Paystack helper. Never import this from a component or any
 * file that ships to the browser — it reads PAYSTACK_SECRET_KEY, which
 * must never reach the client. Only src/lib/payments.functions.ts and
 * src/routes/api.webhooks.paystack.ts should import this.
 *
 * ── Why "collect, then pay out" instead of Transaction Splits ──
 * Paystack Transaction Splits route money to subaccounts automatically on
 * Paystack's own settlement schedule unless every subaccount is configured
 * for manual settlement — and even then, "manually settle a subaccount
 * right now, only this one order" isn't a simple single API call. For a
 * platform that needs to hold funds until a buyer confirms delivery and
 * release them at that exact moment (this is the whole point of the
 * escrow flow described in the safe-payment document), the reliable,
 * fully-controllable pattern is:
 *   1. Charge the full order amount to AGROVIAX's own Paystack balance
 *      (no split at charge time).
 *   2. Hold it — the money is just sitting in the platform's balance.
 *   3. When (and only when) the order is confirmed delivered, initiate a
 *      Paystack Transfer for the seller's share and the transporter's
 *      share to their registered bank accounts. The platform's own
 *      commission needs no transfer — it was never anyone else's money.
 * This needs Transfers enabled on your Paystack business account (a
 * one-time compliance step in the Paystack dashboard) before it will work.
 */

const BASE_URL = "https://api.paystack.co";

function secretKey(): string {
  const key = process.env["PAYSTACK_SECRET_KEY"];
  if (!key) throw new Error("PAYSTACK_SECRET_KEY is not set — add it to your .env (see .env.example).");
  return key;
}

async function paystackFetch(path: string, init: RequestInit = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    ...init,
    headers: {
      Authorization: `Bearer ${secretKey()}`,
      "Content-Type": "application/json",
      ...(init.headers ?? {}),
    },
  });
  const body = await res.json();
  if (!res.ok || body.status === false) {
    throw new Error(body.message || `Paystack request to ${path} failed (${res.status})`);
  }
  return body;
}

/** Kicks off a charge. Returns the URL to redirect the buyer to. */
export async function initializeTransaction(input: {
  email: string;
  amountNaira: number;
  reference: string;
  callbackUrl: string;
  metadata?: Record<string, unknown>;
}) {
  const body = await paystackFetch("/transaction/initialize", {
    method: "POST",
    body: JSON.stringify({
      email: input.email,
      amount: Math.round(input.amountNaira * 100), // Paystack works in kobo
      reference: input.reference,
      callback_url: input.callbackUrl,
      metadata: input.metadata,
    }),
  });
  return body.data as { authorization_url: string; access_code: string; reference: string };
}

/** Server-side truth check — never trust a browser redirect alone (per the safe-payment doc). */
export async function verifyTransaction(reference: string) {
  const body = await paystackFetch(`/transaction/verify/${encodeURIComponent(reference)}`);
  return body.data as { status: string; amount: number; reference: string; metadata: Record<string, unknown> };
}

/** One-time per bank account — Paystack needs a "recipient" object before you can pay one. */
export async function createTransferRecipient(input: { name: string; accountNumber: string; bankCode: string }) {
  const body = await paystackFetch("/transferrecipient", {
    method: "POST",
    body: JSON.stringify({
      type: "nuban",
      name: input.name,
      account_number: input.accountNumber,
      bank_code: input.bankCode,
      currency: "NGN",
    }),
  });
  return body.data as { recipient_code: string };
}

/** The actual payout — this is the "release" step, called only after delivery is confirmed. */
export async function initiateTransfer(input: { amountNaira: number; recipientCode: string; reason: string; reference: string }) {
  const body = await paystackFetch("/transfer", {
    method: "POST",
    body: JSON.stringify({
      source: "balance",
      amount: Math.round(input.amountNaira * 100),
      recipient: input.recipientCode,
      reason: input.reason,
      reference: input.reference,
    }),
  });
  return body.data as { transfer_code: string; status: string };
}

/** Verifies a webhook body genuinely came from Paystack, not a forged request. */
export async function verifyWebhookSignature(rawBody: string, signatureHeader: string | null): Promise<boolean> {
  if (!signatureHeader) return false;
  const secret = process.env["PAYSTACK_SECRET_KEY"];
  if (!secret) return false;
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-512" }, false, ["sign"]);
  const sigBuffer = await crypto.subtle.sign("HMAC", key, enc.encode(rawBody));
  const computed = Array.from(new Uint8Array(sigBuffer)).map((b) => b.toString(16).padStart(2, "0")).join("");
  return computed === signatureHeader;
}

/** Nigerian bank list, for the payout-details form's bank-code dropdown (Paystack needs bank_code, not just a name). */
export async function listBanks() {
  const body = await paystackFetch("/bank?country=nigeria&currency=NGN");
  return body.data as { name: string; code: string }[];
}
