import { createServerFn } from "@tanstack/react-start";

export const listProducts = createServerFn({ method: "GET" }).handler(async () => {
  const { getPublicSupabase } = await import("./supabase-public.server");
  const supabase = getPublicSupabase();
  const [{ data: products }, { data: categories }] = await Promise.all([
    supabase
      .from("products")
      .select(
        "id, title, description, price, unit, currency, quantity_available, location, image_url, organic, verified, seller_name, category_slug, created_at",
      )
      .eq("status", "active")
      .order("created_at", { ascending: false }),
    supabase.from("categories").select("slug, name, kind, description").order("name"),
  ]);
  return { products: products ?? [], categories: categories ?? [] };
});

export const getProduct = createServerFn({ method: "GET" })
  .inputValidator((data: { id: string }) => data)
  .handler(async ({ data }) => {
    const { getPublicSupabase } = await import("./supabase-public.server");
    const supabase = getPublicSupabase();
    const { data: product } = await supabase
      .from("products")
      .select("*")
      .eq("id", data.id)
      .eq("status", "active")
      .maybeSingle();
    if (!product) return { product: null, related: [] };
    const { data: related } = await supabase
      .from("products")
      .select("id, title, price, unit, image_url, location, seller_name")
      .eq("category_slug", product.category_slug)
      .eq("status", "active")
      .neq("id", product.id)
      .limit(4);
    return { product, related: related ?? [] };
  });

export const listMarketPrices = createServerFn({ method: "GET" }).handler(async () => {
  const { getPublicSupabase } = await import("./supabase-public.server");
  const supabase = getPublicSupabase();
  const { data } = await supabase
    .from("market_prices")
    .select("id, crop_type, market_name, region, price, unit, previous_price, recorded_on")
    .order("crop_type");
  return { prices: data ?? [] };
});

export const listDiseases = createServerFn({ method: "GET" }).handler(async () => {
  const { getPublicSupabase } = await import("./supabase-public.server");
  const supabase = getPublicSupabase();
  const { data } = await supabase.from("diseases").select("*").order("name");
  return { diseases: data ?? [] };
});

export const listCropGuides = createServerFn({ method: "GET" }).handler(async () => {
  const { getPublicSupabase } = await import("./supabase-public.server");
  const supabase = getPublicSupabase();
  const { data } = await supabase
    .from("crop_guides")
    .select("slug, crop_name, overview, season")
    .order("crop_name");
  return { guides: data ?? [] };
});

export const getCropGuide = createServerFn({ method: "GET" })
  .inputValidator((data: { slug: string }) => data)
  .handler(async ({ data }) => {
    const { getPublicSupabase } = await import("./supabase-public.server");
    const supabase = getPublicSupabase();
    const { data: guide } = await supabase.from("crop_guides").select("*").eq("slug", data.slug).maybeSingle();
    return { guide };
  });

export const getHomeSnapshot = createServerFn({ method: "GET" }).handler(async () => {
  const { getPublicSupabase } = await import("./supabase-public.server");
  const supabase = getPublicSupabase();
  const [{ data: prices }, { data: products }] = await Promise.all([
    supabase
      .from("market_prices")
      .select("crop_type, market_name, price, unit, previous_price")
      .order("crop_type")
      .limit(6),
    supabase
      .from("products")
      .select("id, title, price, unit, image_url, location, seller_name, organic, verified")
      .eq("status", "active")
      .order("created_at", { ascending: false })
      .limit(6),
  ]);
  return { prices: prices ?? [], products: products ?? [] };
});
