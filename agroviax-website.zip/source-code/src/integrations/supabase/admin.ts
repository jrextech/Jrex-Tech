/**
 * Server-only Supabase client using the SERVICE ROLE key. This bypasses
 * Row Level Security entirely, so it must never be imported into any file
 * that ships to the browser — only server functions / API routes that run
 * on the server (payments.functions.ts, api.webhooks.paystack.ts,
 * release-funds.functions.ts). The regular src/integrations/supabase/client.ts
 * (anon key, RLS-respecting) is what every component should keep using.
 */
import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

let _adminClient: ReturnType<typeof createClient<Database>> | undefined;

export function supabaseAdmin() {
  if (_adminClient) return _adminClient;

  const url = process.env["SUPABASE_URL"];
  const serviceKey = process.env["SUPABASE_SERVICE_ROLE_KEY"];
  if (!url || !serviceKey) {
    throw new Error(
      "SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY must be set (see .env.example) for server-side payment code to write across users' data.",
    );
  }

  _adminClient = createClient<Database>(url, serviceKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
  return _adminClient;
}
