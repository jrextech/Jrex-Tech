export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.15"
  }
  public: {
    Tables: {
      bulk_requests: {
        Row: {
          buyer_id: string
          created_at: string
          crop_type: string
          details: string | null
          id: string
          location: string | null
          needed_by: string | null
          quantity: number
          status: string
          target_price: number | null
          unit: string
        }
        Insert: {
          buyer_id: string
          created_at?: string
          crop_type: string
          details?: string | null
          id?: string
          location?: string | null
          needed_by?: string | null
          quantity?: number
          status?: string
          target_price?: number | null
          unit?: string
        }
        Update: {
          buyer_id?: string
          created_at?: string
          crop_type?: string
          details?: string | null
          id?: string
          location?: string | null
          needed_by?: string | null
          quantity?: number
          status?: string
          target_price?: number | null
          unit?: string
        }
        Relationships: []
      }
      categories: {
        Row: {
          description: string | null
          id: string
          kind: string
          name: string
          slug: string
        }
        Insert: {
          description?: string | null
          id?: string
          kind?: string
          name: string
          slug: string
        }
        Update: {
          description?: string | null
          id?: string
          kind?: string
          name?: string
          slug?: string
        }
        Relationships: []
      }
      crop_activities: {
        Row: {
          activity_date: string
          activity_type: string
          cost: number
          created_at: string
          crop_id: string | null
          farm_id: string | null
          id: string
          notes: string | null
          owner_id: string
        }
        Insert: {
          activity_date?: string
          activity_type: string
          cost?: number
          created_at?: string
          crop_id?: string | null
          farm_id?: string | null
          id?: string
          notes?: string | null
          owner_id: string
        }
        Update: {
          activity_date?: string
          activity_type?: string
          cost?: number
          created_at?: string
          crop_id?: string | null
          farm_id?: string | null
          id?: string
          notes?: string | null
          owner_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "crop_activities_crop_id_fkey"
            columns: ["crop_id"]
            isOneToOne: false
            referencedRelation: "crops"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "crop_activities_farm_id_fkey"
            columns: ["farm_id"]
            isOneToOne: false
            referencedRelation: "farms"
            referencedColumns: ["id"]
          },
        ]
      }
      crop_guides: {
        Row: {
          crop_name: string
          diseases: string
          fertilization: string
          harvesting: string
          id: string
          market_info: string
          overview: string
          pests: string
          planting: string
          season: string
          slug: string
          soil: string
          spacing: string
          storage: string
        }
        Insert: {
          crop_name: string
          diseases?: string
          fertilization?: string
          harvesting?: string
          id?: string
          market_info?: string
          overview?: string
          pests?: string
          planting?: string
          season?: string
          slug: string
          soil?: string
          spacing?: string
          storage?: string
        }
        Update: {
          crop_name?: string
          diseases?: string
          fertilization?: string
          harvesting?: string
          id?: string
          market_info?: string
          overview?: string
          pests?: string
          planting?: string
          season?: string
          slug?: string
          soil?: string
          spacing?: string
          storage?: string
        }
        Relationships: []
      }
      crops: {
        Row: {
          actual_yield: number | null
          created_at: string
          crop_type: string
          expected_harvest: string | null
          expected_yield: number | null
          farm_id: string
          id: string
          notes: string | null
          owner_id: string
          planting_date: string | null
          quantity_planted: number | null
          status: Database["public"]["Enums"]["crop_status"]
          updated_at: string
          variety: string | null
        }
        Insert: {
          actual_yield?: number | null
          created_at?: string
          crop_type: string
          expected_harvest?: string | null
          expected_yield?: number | null
          farm_id: string
          id?: string
          notes?: string | null
          owner_id: string
          planting_date?: string | null
          quantity_planted?: number | null
          status?: Database["public"]["Enums"]["crop_status"]
          updated_at?: string
          variety?: string | null
        }
        Update: {
          actual_yield?: number | null
          created_at?: string
          crop_type?: string
          expected_harvest?: string | null
          expected_yield?: number | null
          farm_id?: string
          id?: string
          notes?: string | null
          owner_id?: string
          planting_date?: string | null
          quantity_planted?: number | null
          status?: Database["public"]["Enums"]["crop_status"]
          updated_at?: string
          variety?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "crops_farm_id_fkey"
            columns: ["farm_id"]
            isOneToOne: false
            referencedRelation: "farms"
            referencedColumns: ["id"]
          },
        ]
      }
      deliveries: {
        Row: {
          created_at: string
          dropoff_location: string
          fee: number
          id: string
          order_id: string | null
          pickup_location: string
          scheduled_for: string | null
          status: string
          transporter_id: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          dropoff_location?: string
          fee?: number
          id?: string
          order_id?: string | null
          pickup_location?: string
          scheduled_for?: string | null
          status?: string
          transporter_id?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          dropoff_location?: string
          fee?: number
          id?: string
          order_id?: string | null
          pickup_location?: string
          scheduled_for?: string | null
          status?: string
          transporter_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "deliveries_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      disease_cases: {
        Row: {
          ai_confidence: number | null
          ai_disease: string | null
          ai_prevention: string | null
          ai_summary: string | null
          ai_treatment: string | null
          created_at: string
          crop_id: string | null
          crop_type: string
          farm_id: string | null
          farmer_id: string
          id: string
          media_type: string
          media_url: string | null
          status: Database["public"]["Enums"]["case_status"]
          symptoms_note: string | null
          updated_at: string
        }
        Insert: {
          ai_confidence?: number | null
          ai_disease?: string | null
          ai_prevention?: string | null
          ai_summary?: string | null
          ai_treatment?: string | null
          created_at?: string
          crop_id?: string | null
          crop_type?: string
          farm_id?: string | null
          farmer_id: string
          id?: string
          media_type?: string
          media_url?: string | null
          status?: Database["public"]["Enums"]["case_status"]
          symptoms_note?: string | null
          updated_at?: string
        }
        Update: {
          ai_confidence?: number | null
          ai_disease?: string | null
          ai_prevention?: string | null
          ai_summary?: string | null
          ai_treatment?: string | null
          created_at?: string
          crop_id?: string | null
          crop_type?: string
          farm_id?: string | null
          farmer_id?: string
          id?: string
          media_type?: string
          media_url?: string | null
          status?: Database["public"]["Enums"]["case_status"]
          symptoms_note?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "disease_cases_crop_id_fkey"
            columns: ["crop_id"]
            isOneToOne: false
            referencedRelation: "crops"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "disease_cases_farm_id_fkey"
            columns: ["farm_id"]
            isOneToOne: false
            referencedRelation: "farms"
            referencedColumns: ["id"]
          },
        ]
      }
      diseases: {
        Row: {
          affected_crops: string
          causes: string
          id: string
          name: string
          prevention: string
          severity: string
          slug: string
          symptoms: string
          treatment: string
        }
        Insert: {
          affected_crops?: string
          causes?: string
          id?: string
          name: string
          prevention?: string
          severity?: string
          slug: string
          symptoms?: string
          treatment?: string
        }
        Update: {
          affected_crops?: string
          causes?: string
          id?: string
          name?: string
          prevention?: string
          severity?: string
          slug?: string
          symptoms?: string
          treatment?: string
        }
        Relationships: []
      }
      expenses: {
        Row: {
          amount: number
          category: string
          created_at: string
          crop_id: string | null
          description: string | null
          expense_date: string
          farm_id: string | null
          id: string
          owner_id: string
        }
        Insert: {
          amount?: number
          category: string
          created_at?: string
          crop_id?: string | null
          description?: string | null
          expense_date?: string
          farm_id?: string | null
          id?: string
          owner_id: string
        }
        Update: {
          amount?: number
          category?: string
          created_at?: string
          crop_id?: string | null
          description?: string | null
          expense_date?: string
          farm_id?: string | null
          id?: string
          owner_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "expenses_crop_id_fkey"
            columns: ["crop_id"]
            isOneToOne: false
            referencedRelation: "crops"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "expenses_farm_id_fkey"
            columns: ["farm_id"]
            isOneToOne: false
            referencedRelation: "farms"
            referencedColumns: ["id"]
          },
        ]
      }
      expert_reviews: {
        Row: {
          case_id: string
          created_at: string
          diagnosis: string
          expert_id: string
          id: string
          recommendation: string
        }
        Insert: {
          case_id: string
          created_at?: string
          diagnosis: string
          expert_id: string
          id?: string
          recommendation: string
        }
        Update: {
          case_id?: string
          created_at?: string
          diagnosis?: string
          expert_id?: string
          id?: string
          recommendation?: string
        }
        Relationships: [
          {
            foreignKeyName: "expert_reviews_case_id_fkey"
            columns: ["case_id"]
            isOneToOne: false
            referencedRelation: "disease_cases"
            referencedColumns: ["id"]
          },
        ]
      }
      farms: {
        Row: {
          created_at: string
          description: string | null
          id: string
          irrigation_method: string | null
          location: string
          name: string
          owner_id: string
          size: number
          size_unit: string
          soil_type: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          irrigation_method?: string | null
          location?: string
          name: string
          owner_id: string
          size?: number
          size_unit?: string
          soil_type?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          irrigation_method?: string | null
          location?: string
          name?: string
          owner_id?: string
          size?: number
          size_unit?: string
          soil_type?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      harvests: {
        Row: {
          created_at: string
          crop_id: string | null
          farm_id: string | null
          harvest_date: string
          id: string
          notes: string | null
          owner_id: string
          quality_grade: string | null
          quantity: number
          unit: string
        }
        Insert: {
          created_at?: string
          crop_id?: string | null
          farm_id?: string | null
          harvest_date?: string
          id?: string
          notes?: string | null
          owner_id: string
          quality_grade?: string | null
          quantity?: number
          unit?: string
        }
        Update: {
          created_at?: string
          crop_id?: string | null
          farm_id?: string | null
          harvest_date?: string
          id?: string
          notes?: string | null
          owner_id?: string
          quality_grade?: string | null
          quantity?: number
          unit?: string
        }
        Relationships: [
          {
            foreignKeyName: "harvests_crop_id_fkey"
            columns: ["crop_id"]
            isOneToOne: false
            referencedRelation: "crops"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "harvests_farm_id_fkey"
            columns: ["farm_id"]
            isOneToOne: false
            referencedRelation: "farms"
            referencedColumns: ["id"]
          },
        ]
      }
      incomes: {
        Row: {
          amount: number
          created_at: string
          crop_id: string | null
          description: string | null
          farm_id: string | null
          id: string
          income_date: string
          owner_id: string
          source: string
        }
        Insert: {
          amount?: number
          created_at?: string
          crop_id?: string | null
          description?: string | null
          farm_id?: string | null
          id?: string
          income_date?: string
          owner_id: string
          source?: string
        }
        Update: {
          amount?: number
          created_at?: string
          crop_id?: string | null
          description?: string | null
          farm_id?: string | null
          id?: string
          income_date?: string
          owner_id?: string
          source?: string
        }
        Relationships: [
          {
            foreignKeyName: "incomes_crop_id_fkey"
            columns: ["crop_id"]
            isOneToOne: false
            referencedRelation: "crops"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "incomes_farm_id_fkey"
            columns: ["farm_id"]
            isOneToOne: false
            referencedRelation: "farms"
            referencedColumns: ["id"]
          },
        ]
      }
      inventory: {
        Row: {
          created_at: string
          farm_id: string | null
          id: string
          item_name: string
          item_type: string
          low_stock_threshold: number
          owner_id: string
          quantity: number
          unit: string
          unit_cost: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          farm_id?: string | null
          id?: string
          item_name: string
          item_type?: string
          low_stock_threshold?: number
          owner_id: string
          quantity?: number
          unit?: string
          unit_cost?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          farm_id?: string | null
          id?: string
          item_name?: string
          item_type?: string
          low_stock_threshold?: number
          owner_id?: string
          quantity?: number
          unit?: string
          unit_cost?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "inventory_farm_id_fkey"
            columns: ["farm_id"]
            isOneToOne: false
            referencedRelation: "farms"
            referencedColumns: ["id"]
          },
        ]
      }
      market_prices: {
        Row: {
          created_at: string
          crop_type: string
          id: string
          market_name: string
          previous_price: number | null
          price: number
          recorded_on: string
          region: string
          unit: string
        }
        Insert: {
          created_at?: string
          crop_type: string
          id?: string
          market_name: string
          previous_price?: number | null
          price: number
          recorded_on?: string
          region: string
          unit?: string
        }
        Update: {
          created_at?: string
          crop_type?: string
          id?: string
          market_name?: string
          previous_price?: number | null
          price?: number
          recorded_on?: string
          region?: string
          unit?: string
        }
        Relationships: []
      }
      messages: {
        Row: {
          body: string
          created_at: string
          id: string
          read_at: string | null
          recipient_id: string
          sender_id: string
        }
        Insert: {
          body: string
          created_at?: string
          id?: string
          read_at?: string | null
          recipient_id: string
          sender_id: string
        }
        Update: {
          body?: string
          created_at?: string
          id?: string
          read_at?: string | null
          recipient_id?: string
          sender_id?: string
        }
        Relationships: []
      }
      notifications: {
        Row: {
          body: string | null
          created_at: string
          id: string
          kind: string
          read_at: string | null
          title: string
          user_id: string
        }
        Insert: {
          body?: string | null
          created_at?: string
          id?: string
          kind?: string
          read_at?: string | null
          title: string
          user_id: string
        }
        Update: {
          body?: string | null
          created_at?: string
          id?: string
          kind?: string
          read_at?: string | null
          title?: string
          user_id?: string
        }
        Relationships: []
      }
      order_items: {
        Row: {
          id: string
          order_id: string
          product_id: string | null
          quantity: number
          title: string
          unit_price: number
        }
        Insert: {
          id?: string
          order_id: string
          product_id?: string | null
          quantity?: number
          title: string
          unit_price?: number
        }
        Update: {
          id?: string
          order_id?: string
          product_id?: string | null
          quantity?: number
          title?: string
          unit_price?: number
        }
        Relationships: [
          {
            foreignKeyName: "order_items_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_items_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      orders: {
        Row: {
          buyer_id: string
          created_at: string
          delivery_address: string
          id: string
          notes: string | null
          seller_id: string | null
          status: Database["public"]["Enums"]["order_status"]
          total_amount: number
          updated_at: string
        }
        Insert: {
          buyer_id: string
          created_at?: string
          delivery_address?: string
          id?: string
          notes?: string | null
          seller_id?: string | null
          status?: Database["public"]["Enums"]["order_status"]
          total_amount?: number
          updated_at?: string
        }
        Update: {
          buyer_id?: string
          created_at?: string
          delivery_address?: string
          id?: string
          notes?: string | null
          seller_id?: string | null
          status?: Database["public"]["Enums"]["order_status"]
          total_amount?: number
          updated_at?: string
        }
        Relationships: []
      }
      products: {
        Row: {
          category_slug: string
          created_at: string
          currency: string
          description: string | null
          id: string
          image_url: string | null
          location: string
          organic: boolean
          price: number
          quantity_available: number
          seller_id: string | null
          seller_name: string
          status: string
          title: string
          unit: string
          updated_at: string
          verified: boolean
        }
        Insert: {
          category_slug?: string
          created_at?: string
          currency?: string
          description?: string | null
          id?: string
          image_url?: string | null
          location?: string
          organic?: boolean
          price?: number
          quantity_available?: number
          seller_id?: string | null
          seller_name?: string
          status?: string
          title: string
          unit?: string
          updated_at?: string
          verified?: boolean
        }
        Update: {
          category_slug?: string
          created_at?: string
          currency?: string
          description?: string | null
          id?: string
          image_url?: string | null
          location?: string
          organic?: boolean
          price?: number
          quantity_available?: number
          seller_id?: string | null
          seller_name?: string
          status?: string
          title?: string
          unit?: string
          updated_at?: string
          verified?: boolean
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          bio: string | null
          created_at: string
          full_name: string
          id: string
          location: string | null
          organization: string | null
          phone: string | null
          rating: number
          updated_at: string
          verified: boolean
        }
        Insert: {
          avatar_url?: string | null
          bio?: string | null
          created_at?: string
          full_name?: string
          id: string
          location?: string | null
          organization?: string | null
          phone?: string | null
          rating?: number
          updated_at?: string
          verified?: boolean
        }
        Update: {
          avatar_url?: string | null
          bio?: string | null
          created_at?: string
          full_name?: string
          id?: string
          location?: string | null
          organization?: string | null
          phone?: string | null
          rating?: number
          updated_at?: string
          verified?: boolean
        }
        Relationships: []
      }
      seller_reviews: {
        Row: {
          comment: string | null
          created_at: string
          id: string
          rating: number
          reviewer_id: string
          seller_id: string
        }
        Insert: {
          comment?: string | null
          created_at?: string
          id?: string
          rating?: number
          reviewer_id: string
          seller_id: string
        }
        Update: {
          comment?: string | null
          created_at?: string
          id?: string
          rating?: number
          reviewer_id?: string
          seller_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      vehicles: {
        Row: {
          available: boolean
          base_location: string | null
          capacity_kg: number
          created_at: string
          id: string
          plate_number: string
          transporter_id: string
          vehicle_type: string
        }
        Insert: {
          available?: boolean
          base_location?: string | null
          capacity_kg?: number
          created_at?: string
          id?: string
          plate_number: string
          transporter_id: string
          vehicle_type: string
        }
        Update: {
          available?: boolean
          base_location?: string | null
          capacity_kg?: number
          created_at?: string
          id?: string
          plate_number?: string
          transporter_id?: string
          vehicle_type?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role:
        | "farmer"
        | "buyer"
        | "business"
        | "expert"
        | "transporter"
        | "admin"
      case_status:
        | "analyzing"
        | "analyzed"
        | "expert_requested"
        | "expert_reviewed"
      crop_status:
        | "planned"
        | "planted"
        | "growing"
        | "ready_for_harvest"
        | "harvested"
        | "completed"
      order_status:
        | "pending"
        | "confirmed"
        | "paid"
        | "in_transit"
        | "delivered"
        | "cancelled"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: [
        "farmer",
        "buyer",
        "business",
        "expert",
        "transporter",
        "admin",
      ],
      case_status: [
        "analyzing",
        "analyzed",
        "expert_requested",
        "expert_reviewed",
      ],
      crop_status: [
        "planned",
        "planted",
        "growing",
        "ready_for_harvest",
        "harvested",
        "completed",
      ],
      order_status: [
        "pending",
        "confirmed",
        "paid",
        "in_transit",
        "delivered",
        "cancelled",
      ],
    },
  },
} as const
