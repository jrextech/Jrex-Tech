import { useEffect, useState } from "react";
import type { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

export type AppRole = "farmer" | "buyer" | "business" | "expert" | "transporter" | "admin" | "logistics_partner";

export const ROLE_LABELS: Record<AppRole, string> = {
  farmer: "Farmer",
  buyer: "Buyer",
  business: "Agricultural Business",
  expert: "Agricultural Expert",
  transporter: "Transporter",
  admin: "Administrator",
  logistics_partner: "Logistics Partner",
};

export function useAuth() {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [roles, setRoles] = useState<AppRole[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;

    const loadRoles = async (uid: string) => {
      const { data } = await supabase.from("user_roles").select("role").eq("user_id", uid);
      if (active) setRoles((data ?? []).map((r) => r.role as AppRole));
    };

    supabase.auth.getSession().then(({ data }) => {
      if (!active) return;
      setSession(data.session);
      setUser(data.session?.user ?? null);
      if (data.session?.user) void loadRoles(data.session.user.id);
      setLoading(false);
    });

    const { data: sub } = supabase.auth.onAuthStateChange((event, next) => {
      if (!active) return;
      setSession(next);
      setUser(next?.user ?? null);
      if (next?.user && event !== "TOKEN_REFRESHED") {
        void loadRoles(next.user.id);
      }
      if (!next) setRoles([]);
    });

    return () => {
      active = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  const primaryRole: AppRole = roles.includes("admin") ? "admin" : (roles[0] ?? "farmer");

  return { session, user, roles, primaryRole, loading, isAuthenticated: !!user };
}
