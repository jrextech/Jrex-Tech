import { Link } from "@tanstack/react-router";
import logo from "@/assets/agroviax-logo.png";
import { cn } from "@/lib/utils";

export function Logo({
  className,
  tone = "dark",
  withWordmark = true,
}: {
  className?: string;
  tone?: "dark" | "light";
  withWordmark?: boolean;
}) {
  return (
    <Link to="/" className={cn("flex items-center gap-2.5", className)} aria-label="AGROVIAX home">
      <img src={logo} alt="AGROVIAX leaf and growth-arrow logo" width={36} height={36} className="h-9 w-9" />
      {withWordmark && (
        <span
          className={cn(
            "font-display text-xl font-semibold tracking-tight",
            tone === "light" ? "text-forest-foreground" : "text-forest",
          )}
        >
          AGROVIAX
        </span>
      )}
    </Link>
  );
}
