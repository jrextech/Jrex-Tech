import { useMemo, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ShoppingCart, Minus, Plus, Trash2, Loader2, Truck } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useCart, naira, type CartItem } from "@/lib/cart";
import { initializePayment } from "@/lib/payments.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
  SheetFooter,
} from "@/components/ui/sheet";

type SellerGroup = {
  sellerId: string;
  sellerName: string;
  items: CartItem[];
  subtotal: number;
  canOfferTransport: boolean; // at least one item's seller opted into "need_transport"
  totalWeightKg: number;
  pickupLocation: string | null;
};

function groupBySeller(items: CartItem[]): SellerGroup[] {
  const map = new Map<string, SellerGroup>();
  for (const item of items) {
    const key = item.seller_id ?? "unknown";
    const existing = map.get(key);
    const weight = (item.weight_kg ?? 1) * item.quantity;
    if (existing) {
      existing.items.push(item);
      existing.subtotal += item.price * item.quantity;
      existing.totalWeightKg += weight;
      if (item.transport_option === "need_transport") existing.canOfferTransport = true;
    } else {
      map.set(key, {
        sellerId: key,
        sellerName: item.seller_name,
        items: [item],
        subtotal: item.price * item.quantity,
        canOfferTransport: item.transport_option === "need_transport",
        totalWeightKg: weight,
        pickupLocation: item.pickup_location,
      });
    }
  }
  return Array.from(map.values());
}

export function CartDrawer() {
  const cart = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [address, setAddress] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<"pay_on_delivery" | "bank_transfer" | "paystack">("pay_on_delivery");
  // Per-seller state, keyed by sellerId
  const [deliveryChoice, setDeliveryChoice] = useState<Record<string, "buyer_pickup" | "need_transport">>({});
  const [distanceKm, setDistanceKm] = useState<Record<string, string>>({});

  const groups = useMemo(() => groupBySeller(cart.items), [cart.items]);

  const fees = useQuery({
    queryKey: [
      "transport-fee-estimates",
      groups.map((g) => `${g.sellerId}:${deliveryChoice[g.sellerId]}:${distanceKm[g.sellerId]}`).join(","),
    ],
    enabled: groups.some((g) => deliveryChoice[g.sellerId] === "need_transport" && Number(distanceKm[g.sellerId]) > 0),
    queryFn: async () => {
      const results: Record<string, number> = {};
      await Promise.all(
        groups.map(async (g) => {
          if (deliveryChoice[g.sellerId] !== "need_transport") return;
          const km = Number(distanceKm[g.sellerId]);
          if (!km || km <= 0) return;
          const { data, error } = await supabase.rpc("calculate_transport_fee", {
            p_distance_km: km,
            p_weight_kg: g.totalWeightKg,
          });
          if (!error && typeof data === "number") results[g.sellerId] = data;
        }),
      );
      return results;
    },
  });

  const transportFeeFor = (sellerId: string) => fees.data?.[sellerId] ?? 0;
  const grandTotal = groups.reduce((n, g) => n + g.subtotal + transportFeeFor(g.sellerId), 0);

  const doInitializePayment = useServerFn(initializePayment);

  const checkout = useMutation({
    mutationFn: async () => {
      if (!user) throw new Error("Sign in to place an order.");
      if (!address.trim()) throw new Error("Add a delivery address.");
      for (const g of groups) {
        if (g.canOfferTransport && deliveryChoice[g.sellerId] === "need_transport" && !(Number(distanceKm[g.sellerId]) > 0)) {
          throw new Error(`Enter the delivery distance for ${g.sellerName}'s order so we can price transport.`);
        }
      }

      const createdOrderIds: string[] = [];

      for (const g of groups) {
        const wantsTransport = g.canOfferTransport && deliveryChoice[g.sellerId] === "need_transport";
        const transportFee = wantsTransport ? transportFeeFor(g.sellerId) : 0;

        // Platform commission comes out of the seller's share — it is never
        // added on top of what the buyer pays, and never shown to the buyer.
        const { data: platformFee } = await supabase.rpc("calculate_platform_fee", { p_amount: g.subtotal });
        const platformAmount = Number(platformFee ?? 0);

        const { data: order, error } = await supabase
          .from("orders")
          .insert({
            buyer_id: user.id,
            seller_id: g.sellerId === "unknown" ? null : g.sellerId,
            total_amount: g.subtotal + transportFee,
            delivery_address: address.trim(),
            payment_method: paymentMethod,
            delivery_option: wantsTransport ? "need_transport" : "buyer_pickup",
            transport_fee: transportFee,
            platform_fee: platformAmount,
            seller_payout_amount: g.subtotal - platformAmount,
            status: "pending",
          })
          .select("id")
          .single();
        if (error) throw error;
        createdOrderIds.push(order.id);

        const { error: itemsError } = await supabase.from("order_items").insert(
          g.items.map((i) => ({
            order_id: order.id,
            product_id: i.id,
            title: i.title,
            quantity: i.quantity,
            unit_price: i.price,
          })),
        );
        if (itemsError) throw itemsError;

        if (wantsTransport) {
          const { error: deliveryError } = await supabase.from("deliveries").insert({
            order_id: order.id,
            pickup_location: g.pickupLocation || "Seller location (see order)",
            dropoff_location: address.trim(),
            fee: transportFee,
          });
          if (deliveryError) throw deliveryError;
        }
      }

      if (paymentMethod === "paystack") {
        // Paystack's hosted checkout handles one charge at a time. With more
        // than one seller in the basket, only the first order is paid here —
        // the rest stay "pending" and get a "Pay now" prompt in Orders.
        const { authorizationUrl } = await doInitializePayment({
          data: {
            orderId: createdOrderIds[0],
            buyerEmail: user.email!,
            callbackUrl: `${window.location.origin}/dashboard/orders`,
          },
        });
        return { redirectTo: authorizationUrl, multipleOrders: createdOrderIds.length > 1 };
      }
      return { redirectTo: null, multipleOrders: false };
    },
    onSuccess: (result) => {
      cart.clear();
      setAddress("");
      setDeliveryChoice({});
      setDistanceKm({});
      setOpen(false);
      void qc.invalidateQueries({ queryKey: ["orders"] });
      void qc.invalidateQueries({ queryKey: ["dashboard-overview"] });

      if (result.redirectTo) {
        if (result.multipleOrders) {
          toast.message("Redirecting to pay your first order — the rest are saved as pending, pay them from Orders.");
        }
        window.location.href = result.redirectTo;
        return;
      }
      toast.success("Order placed! Track it from your dashboard.");
      navigate({ to: "/dashboard/orders" });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="outline" size="sm" className="relative">
          <ShoppingCart className="h-4 w-4" />
          {cart.count > 0 && (
            <span className="absolute -right-2 -top-2 flex h-5 w-5 items-center justify-center rounded-full bg-gold text-[11px] font-semibold text-gold-foreground">
              {cart.count}
            </span>
          )}
        </Button>
      </SheetTrigger>
      <SheetContent className="flex w-full flex-col overflow-y-auto sm:max-w-md">
        <SheetHeader>
          <SheetTitle>Your basket</SheetTitle>
        </SheetHeader>

        {cart.items.length === 0 ? (
          <p className="mt-8 text-center text-sm text-muted-foreground">
            Nothing here yet — add produce or inputs from the marketplace.
          </p>
        ) : (
          <>
            <div className="mt-4 flex-1 space-y-5">
              {groups.map((g) => (
                <div key={g.sellerId} className="space-y-3 rounded-lg border border-border p-3">
                  <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{g.sellerName}</p>

                  {g.items.map((item) => (
                    <div key={item.id} className="flex items-center gap-3">
                      {item.image_url && (
                        <img src={item.image_url} alt={item.title} className="h-14 w-14 rounded-md object-cover" />
                      )}
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium">{item.title}</p>
                        <p className="text-xs text-muted-foreground">{naira(item.price)}/{item.unit}</p>
                        <div className="mt-2 flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => cart.setQuantity(item.id, item.quantity - 1)}
                            className="flex h-6 w-6 items-center justify-center rounded border border-border"
                            aria-label="Decrease quantity"
                          >
                            <Minus className="h-3 w-3" />
                          </button>
                          <span className="w-6 text-center text-xs">{item.quantity}</span>
                          <button
                            type="button"
                            onClick={() => cart.setQuantity(item.id, item.quantity + 1)}
                            className="flex h-6 w-6 items-center justify-center rounded border border-border"
                            aria-label="Increase quantity"
                          >
                            <Plus className="h-3 w-3" />
                          </button>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => cart.remove(item.id)}
                        className="text-muted-foreground hover:text-destructive"
                        aria-label="Remove item"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  ))}

                  {g.canOfferTransport ? (
                    <div className="space-y-2 border-t border-border pt-3">
                      <p className="flex items-center gap-1.5 text-xs font-medium">
                        <Truck className="h-3.5 w-3.5" /> Delivery for this seller's items
                      </p>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => setDeliveryChoice((p) => ({ ...p, [g.sellerId]: "buyer_pickup" }))}
                          className={`rounded-md border p-2 text-left text-xs font-medium ${
                            (deliveryChoice[g.sellerId] ?? "buyer_pickup") === "buyer_pickup"
                              ? "border-primary bg-primary/5 text-primary"
                              : "border-border text-muted-foreground"
                          }`}
                        >
                          I'll arrange pickup
                        </button>
                        <button
                          type="button"
                          onClick={() => setDeliveryChoice((p) => ({ ...p, [g.sellerId]: "need_transport" }))}
                          className={`rounded-md border p-2 text-left text-xs font-medium ${
                            deliveryChoice[g.sellerId] === "need_transport"
                              ? "border-primary bg-primary/5 text-primary"
                              : "border-border text-muted-foreground"
                          }`}
                        >
                          I need a transporter
                        </button>
                      </div>
                      {deliveryChoice[g.sellerId] === "need_transport" && (
                        <div className="space-y-1.5">
                          <Label htmlFor={`distance-${g.sellerId}`} className="text-xs">
                            Approx. distance to your delivery address (km)
                          </Label>
                          <Input
                            id={`distance-${g.sellerId}`}
                            type="number"
                            min={1}
                            className="h-8 text-sm"
                            placeholder="e.g. 25"
                            value={distanceKm[g.sellerId] ?? ""}
                            onChange={(e) => setDistanceKm((p) => ({ ...p, [g.sellerId]: e.target.value }))}
                          />
                          {transportFeeFor(g.sellerId) > 0 && (
                            <p className="text-xs text-muted-foreground">
                              Estimated transport fee: <span className="font-medium text-foreground">{naira(transportFeeFor(g.sellerId))}</span>
                              {" "}(based on distance, item weight and reference fuel price)
                            </p>
                          )}
                        </div>
                      )}
                    </div>
                  ) : (
                    <p className="border-t border-border pt-2 text-xs text-muted-foreground">
                      This seller arranges their own delivery — no AGROVIAX transport fee applies.
                    </p>
                  )}

                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>Subtotal</span>
                    <span>{naira(g.subtotal)}</span>
                  </div>
                </div>
              ))}
            </div>

            <SheetFooter className="mt-4 flex-col gap-3 sm:flex-col">
              <div className="w-full space-y-1.5">
                <Label htmlFor="delivery-address">Delivery / pickup address</Label>
                <Input
                  id="delivery-address"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Street, city, state"
                />
              </div>
              <div className="w-full space-y-1.5">
                <Label htmlFor="payment-method">Payment method</Label>
                <Select value={paymentMethod} onValueChange={(v) => setPaymentMethod(v as typeof paymentMethod)}>
                  <SelectTrigger id="payment-method">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pay_on_delivery">Pay on delivery</SelectItem>
                    <SelectItem value="bank_transfer">Bank transfer (arrange directly with seller)</SelectItem>
                    <SelectItem value="paystack">Card / bank transfer via Paystack (secure, held until you confirm)</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground">
                  You'll settle payment with the seller directly by this method — AGROVIAX doesn't process card
                  payments yet.
                </p>
              </div>
              <div className="flex w-full items-center justify-between text-sm font-medium">
                <span>Total</span>
                <span className="font-display text-lg text-forest">{naira(grandTotal)}</span>
              </div>
              {user ? (
                <Button className="w-full" disabled={checkout.isPending} onClick={() => checkout.mutate()}>
                  {checkout.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Placing order…
                    </>
                  ) : (
                    "Place order"
                  )}
                </Button>
              ) : (
                <Button
                  className="w-full"
                  onClick={() => {
                    setOpen(false);
                    navigate({ to: "/auth", search: { mode: "signin" } });
                  }}
                >
                  Sign in to check out
                </Button>
              )}
            </SheetFooter>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
