import { Link } from "@tanstack/react-router";
import { Logo } from "@/components/brand/Logo";

const GROUPS = [
  {
    title: "Platform",
    links: [
      { to: "/marketplace", label: "Marketplace" },
      { to: "/market-prices", label: "Market Prices" },
      { to: "/crop-health", label: "Crop Health AI" },
      { to: "/services", label: "Services & Transport" },
    ],
  },
  {
    title: "Knowledge",
    links: [
      { to: "/crop-guides", label: "Crop Guides" },
      { to: "/disease-library", label: "Disease Library" },
      { to: "/how-it-works", label: "How It Works" },
      { to: "/pricing", label: "Pricing" },
    ],
  },
  {
    title: "Company",
    links: [
      { to: "/about", label: "About AGROVIAX" },
      { to: "/faq", label: "FAQ" },
      { to: "/contact", label: "Contact" },
    ],
  },
] as const;

export function SiteFooter() {
  return (
    <footer className="mt-24 bg-forest text-forest-foreground">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-[1.4fr_1fr_1fr_1fr]">
        <div>
          <Logo tone="light" />
          <p className="mt-4 max-w-xs text-sm text-forest-foreground/70">
            One connected agricultural ecosystem — from farm planning and crop health to market access, logistics and
            farm finance.
          </p>
        </div>
        {GROUPS.map((group) => (
          <div key={group.title}>
            <h3 className="font-display text-sm font-semibold uppercase tracking-widest text-gold">{group.title}</h3>
            <ul className="mt-4 space-y-2.5">
              {group.links.map((link) => (
                <li key={link.to}>
                  <Link
                    to={link.to}
                    className="text-sm text-forest-foreground/75 transition-colors hover:text-forest-foreground"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="border-t border-forest-foreground/15">
        <div className="mx-auto flex max-w-7xl flex-col gap-2 px-4 py-6 text-xs text-forest-foreground/60 sm:flex-row sm:items-center sm:justify-between sm:px-6">
          <p>&copy; {new Date().getFullYear()} AGROVIAX. Digital agricultural ecosystem.</p>
          <p>Built for farmers, buyers, businesses, experts, transporters and administrators.</p>
        </div>
      </div>
    </footer>
  );
}
