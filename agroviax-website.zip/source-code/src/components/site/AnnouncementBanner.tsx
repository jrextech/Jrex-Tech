import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Megaphone, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

export function AnnouncementBanner() {
  const [dismissed, setDismissed] = useState<string[]>([]);

  const announcements = useQuery({
    queryKey: ["public-announcements"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("announcements")
        .select("id, title, body")
        .order("created_at", { ascending: false })
        .limit(1);
      if (error) throw error;
      return data ?? [];
    },
    staleTime: 60_000,
  });

  const active = (announcements.data ?? []).find((a) => !dismissed.includes(a.id));
  if (!active) return null;

  return (
    <div className="flex items-center justify-between gap-3 bg-gold px-4 py-2 text-sm text-gold-foreground">
      <div className="flex min-w-0 items-center gap-2">
        <Megaphone className="h-4 w-4 shrink-0" />
        <p className="truncate">
          <span className="font-semibold">{active.title}</span> — {active.body}
        </p>
      </div>
      <button
        type="button"
        onClick={() => setDismissed((d) => [...d, active.id])}
        className="shrink-0 opacity-80 hover:opacity-100"
        aria-label="Dismiss announcement"
      >
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}
