import type { ReactNode } from "react";
import { SiteHeader } from "./SiteHeader";
import { SiteFooter } from "./SiteFooter";
import { AnnouncementBanner } from "./AnnouncementBanner";

export function PublicLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col">
      <AnnouncementBanner />
      <SiteHeader />
      <main className="flex-1">{children}</main>
      <SiteFooter />
    </div>
  );
}

export function PageHero({
  eyebrow,
  title,
  description,
  children,
}: {
  eyebrow: string;
  title: string;
  description: string;
  children?: ReactNode;
}) {
  return (
    <section className="border-b border-border bg-forest text-forest-foreground">
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 md:py-20">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-gold">{eyebrow}</p>
        <h1 className="mt-3 max-w-3xl text-3xl leading-tight md:text-5xl">{title}</h1>
        <p className="mt-4 max-w-2xl text-sm text-forest-foreground/75 md:text-base">{description}</p>
        {children && <div className="mt-7">{children}</div>}
      </div>
    </section>
  );
}
