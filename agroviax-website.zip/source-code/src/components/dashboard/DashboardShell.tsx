import { useState, type ReactNode } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import {
  LayoutDashboard,
  Sprout,
  Store,
  Receipt,
  Wallet,
  Truck,
  ScanLine,
  Stethoscope,
  ShieldCheck,
  MessageSquare,
  UserRound,
  LogOut,
  Menu,
  X,
  Globe,
  Settings2,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Logo } from "@/components/brand/Logo";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth, ROLE_LABELS, type AppRole } from "@/hooks/useAuth";
import { NotificationsBell } from "@/components/site/NotificationsBell";
import { AnnouncementBanner } from "@/components/site/AnnouncementBanner";

type NavItem = {
  to:
    | "/dashboard"
    | "/dashboard/farms"
    | "/dashboard/listings"
    | "/dashboard/orders"
    | "/dashboard/finance"
    | "/dashboard/logistics"
    | "/dashboard/cases"
    | "/dashboard/expert"
    | "/dashboard/admin"
    | "/dashboard/messages"
    | "/dashboard/profile"
    | "/dashboard/settings"
    | "/dashboard/partner";
  label: string;
  icon: typeof LayoutDashboard;
  roles?: AppRole[];
};

const NAV: NavItem[] = [
  { to: "/dashboard", label: "Overview", icon: LayoutDashboard },
  { to: "/dashboard/farms", label: "Farms & crops", icon: Sprout, roles: ["farmer", "business", "admin"] },
  { to: "/dashboard/listings", label: "My listings", icon: Store, roles: ["farmer", "business", "admin"] },
  { to: "/dashboard/orders", label: "Orders", icon: Receipt, roles: ["farmer", "buyer", "business", "admin"] },
  { to: "/dashboard/finance", label: "Finance", icon: Wallet, roles: ["farmer", "business", "admin"] },
  { to: "/dashboard/cases", label: "Crop health cases", icon: ScanLine, roles: ["farmer", "buyer", "business", "expert", "admin"] },
  { to: "/dashboard/logistics", label: "Logistics", icon: Truck, roles: ["transporter", "admin"] },
  { to: "/dashboard/partner", label: "Partner portal", icon: Truck, roles: ["logistics_partner", "admin"] },
  { to: "/dashboard/expert", label: "Expert desk", icon: Stethoscope, roles: ["expert", "admin"] },
  { to: "/dashboard/admin", label: "Administration", icon: ShieldCheck, roles: ["admin"] },
  { to: "/dashboard/messages", label: "Messages", icon: MessageSquare },
  { to: "/dashboard/profile", label: "Profile", icon: UserRound },
  { to: "/dashboard/settings", label: "Settings", icon: Settings2 },
];

export function DashboardShell({ children }: { children: ReactNode }) {
  const { user, roles, primaryRole } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);

  const visible = NAV.filter((item) => !item.roles || item.roles.some((r) => roles.includes(r)) || roles.length === 0);

  const signOut = async () => {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", search: { mode: "signin" }, replace: true });
  };

  const name = (user?.user_metadata?.["full_name"] as string) ?? user?.email?.split("@")[0] ?? "there";

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 border-b border-border bg-card">
        <div className="mx-auto flex h-16 max-w-[100rem] items-center justify-between gap-3 px-4 sm:px-6">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setOpen((v) => !v)}
              className="inline-flex h-9 w-9 items-center justify-center rounded-md border border-border lg:hidden"
              aria-label={open ? "Close menu" : "Open menu"}
            >
              {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </button>
            <Logo />
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="hidden sm:inline-flex">
              {ROLE_LABELS[primaryRole]}
            </Badge>
            <NotificationsBell />
            <Button asChild variant="ghost" size="sm">
              <Link to="/">
                <Globe className="mr-1.5 h-4 w-4" /> Public site
              </Link>
            </Button>
            <Button variant="ghost" size="sm" onClick={signOut}>
              <LogOut className="mr-1.5 h-4 w-4" /> Sign out
            </Button>
          </div>
        </div>
      </header>

      <div className="mx-auto flex max-w-[100rem] gap-6 px-4 py-6 sm:px-6">
        <aside
          className={`${open ? "block" : "hidden"} fixed inset-x-0 top-16 z-30 border-b border-border bg-card p-3 lg:static lg:z-auto lg:block lg:w-60 lg:shrink-0 lg:border-0 lg:bg-transparent lg:p-0`}
        >
          <nav className="flex flex-col gap-1">
            {visible.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setOpen(false)}
                activeOptions={{ exact: item.to === "/dashboard" }}
                className="flex items-center gap-2.5 rounded-md px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                activeProps={{ className: "bg-secondary text-foreground" }}
              >
                <item.icon className="h-4 w-4" />
                {item.label}
              </Link>
            ))}
          </nav>
          <p className="mt-4 hidden px-3 text-xs text-muted-foreground lg:block">Signed in as {name}</p>
        </aside>

        <main className="min-w-0 flex-1">
          <AnnouncementBanner />
          <div className="p-4 sm:p-6 lg:p-8">{children}</div>
        </main>
      </div>
    </div>
  );
}

export function PageHeading({
  title,
  description,
  action,
}: {
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-2xl md:text-3xl">{title}</h1>
        {description && <p className="mt-1.5 text-sm text-muted-foreground">{description}</p>}
      </div>
      {action}
    </div>
  );
}

export function EmptyState({ title, body, action }: { title: string; body: string; action?: ReactNode }) {
  return (
    <div className="rounded-xl border border-dashed border-border p-10 text-center">
      <h3 className="text-base font-semibold">{title}</h3>
      <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">{body}</p>
      {action && <div className="mt-5 flex justify-center">{action}</div>}
    </div>
  );
}
