
DROP POLICY "products_public_read" ON public.products;
CREATE POLICY "products_anon_read" ON public.products FOR SELECT TO anon USING (status = 'active');
CREATE POLICY "products_auth_read" ON public.products FOR SELECT TO authenticated USING (status = 'active' OR auth.uid() = seller_id OR public.has_role(auth.uid(),'admin'));

DROP POLICY "bulk_public_read" ON public.bulk_requests;
CREATE POLICY "bulk_anon_read" ON public.bulk_requests FOR SELECT TO anon USING (status = 'open');
CREATE POLICY "bulk_auth_read" ON public.bulk_requests FOR SELECT TO authenticated USING (status = 'open' OR auth.uid() = buyer_id OR public.has_role(auth.uid(),'admin'));

REVOKE ALL ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated, service_role;
