-- ============================================================
-- Complete Admin, Staff & Account Architecture: multiple admins, each
-- scoped to a department, enforced by the database — not just hidden
-- buttons in the frontend (explicit developer rule, Section 20 of the
-- plan). 'admin' in user_roles still means "this person is AGROVIAX
-- platform staff of some kind"; admin_staff.department says WHICH
-- department, and only 'super_admin' gets full, unscoped access.
-- ============================================================
CREATE TABLE public.admin_staff (
  user_id UUID PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  department TEXT NOT NULL CHECK (department IN (
    'super_admin', 'finance', 'marketplace', 'agriculture', 'logistics', 'support', 'marketing', 'it_security'
  )),
  title TEXT,
  created_by UUID REFERENCES auth.users,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.admin_staff TO authenticated;
GRANT ALL ON public.admin_staff TO service_role;
ALTER TABLE public.admin_staff ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_department(p_user_id UUID, p_department TEXT)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  -- A super_admin passes every department check — that's the whole point
  -- of the role (Section 3: "global configuration... system-wide oversight").
  SELECT EXISTS (
    SELECT 1 FROM public.admin_staff
    WHERE user_id = p_user_id AND (department = p_department OR department = 'super_admin')
  );
$$;

CREATE POLICY "admin_staff_read_own_or_super" ON public.admin_staff FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_department(auth.uid(), 'super_admin'));
-- No INSERT/UPDATE policy for `authenticated` at all: only the service-role
-- client (via createDepartmentAdminAccount, which independently re-verifies
-- the caller is a super_admin) can create or change a department assignment.
-- A finance admin granting themselves super_admin by editing their own row
-- is exactly the privilege-escalation path this is designed to prevent.

CREATE TRIGGER admin_staff_updated BEFORE UPDATE ON public.admin_staff
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Backward compatibility: every account that already holds the blanket
-- 'admin' role (from before this migration) becomes a super_admin, so
-- nobody who already had full access loses it the moment this ships.
INSERT INTO public.admin_staff (user_id, department)
SELECT ur.user_id, 'super_admin' FROM public.user_roles ur
WHERE ur.role = 'admin'
ON CONFLICT (user_id) DO NOTHING;

-- ============================================================
-- Audit log — required by Section 18/20: every high-risk admin action
-- gets a traceable who/what/when/before/after record.
-- ============================================================
CREATE TABLE public.audit_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id UUID REFERENCES auth.users,
  action TEXT NOT NULL,
  table_name TEXT NOT NULL,
  record_id TEXT,
  old_data JSONB,
  new_data JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.audit_log TO authenticated;
GRANT ALL ON public.audit_log TO service_role;
ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "audit_log_super_admin_read" ON public.audit_log FOR SELECT TO authenticated
  USING (public.has_department(auth.uid(), 'super_admin'));

CREATE OR REPLACE FUNCTION public.log_audit_event()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.audit_log (actor_id, action, table_name, record_id, old_data, new_data)
  VALUES (
    auth.uid(),
    TG_OP,
    TG_TABLE_NAME,
    COALESCE(NEW.id::text, NEW.user_id::text, OLD.id::text, OLD.user_id::text),
    CASE WHEN TG_OP = 'DELETE' OR TG_OP = 'UPDATE' THEN to_jsonb(OLD) ELSE NULL END,
    CASE WHEN TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN to_jsonb(NEW) ELSE NULL END
  );
  RETURN COALESCE(NEW, OLD);
END;
$$;

-- Applied to the highest-risk tables: money configuration, driver
-- approval, refund decisions, and admin/department assignment itself.
CREATE TRIGGER audit_admin_staff AFTER INSERT OR UPDATE OR DELETE ON public.admin_staff
  FOR EACH ROW EXECUTE FUNCTION public.log_audit_event();
CREATE TRIGGER audit_drivers AFTER UPDATE ON public.drivers
  FOR EACH ROW EXECUTE FUNCTION public.log_audit_event();
CREATE TRIGGER audit_platform_fee_tiers AFTER INSERT OR UPDATE OR DELETE ON public.platform_fee_tiers
  FOR EACH ROW EXECUTE FUNCTION public.log_audit_event();
CREATE TRIGGER audit_platform_settings AFTER UPDATE ON public.platform_settings
  FOR EACH ROW EXECUTE FUNCTION public.log_audit_event();
CREATE TRIGGER audit_refund_requests AFTER UPDATE ON public.refund_requests
  FOR EACH ROW EXECUTE FUNCTION public.log_audit_event();
CREATE TRIGGER audit_payments AFTER UPDATE ON public.payments
  FOR EACH ROW EXECUTE FUNCTION public.log_audit_event();

-- ============================================================
-- Re-scope existing "any admin can do this" policies to the right
-- department. Each DROP + CREATE pair targets exactly one earlier policy;
-- nothing else about those tables changes.
-- ============================================================

-- Logistics: drivers, logistics_partners, logistics_partner_staff, and the
-- driver-assignment trigger on deliveries.
DROP POLICY IF EXISTS "drivers_admin_update" ON public.drivers;
CREATE POLICY "drivers_admin_update" ON public.drivers FOR UPDATE TO authenticated
  USING (public.has_department(auth.uid(), 'logistics'))
  WITH CHECK (public.has_department(auth.uid(), 'logistics'));

DROP POLICY IF EXISTS "logistics_partners_admin_all" ON public.logistics_partners;
CREATE POLICY "logistics_partners_admin_all" ON public.logistics_partners FOR ALL TO authenticated
  USING (public.has_department(auth.uid(), 'logistics')) WITH CHECK (public.has_department(auth.uid(), 'logistics'));

CREATE OR REPLACE FUNCTION public.enforce_driver_assignment()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.transporter_id IS DISTINCT FROM OLD.transporter_id THEN
    IF NOT public.has_department(auth.uid(), 'logistics') THEN
      RAISE EXCEPTION 'Only AGROVIAX Logistics staff can assign a delivery to a driver.';
    END IF;
    IF NEW.transporter_id IS NOT NULL AND NOT public.is_approved_driver(NEW.transporter_id) THEN
      RAISE EXCEPTION 'This user is not an approved AGROVIAX driver.';
    END IF;
    NEW.assigned_by := auth.uid();
    NEW.assigned_at := now();
    IF NEW.status = 'pending' THEN
      NEW.status := 'assigned';
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

-- Finance: fee configuration, platform settings, refunds, payments already
-- had admin-only visibility/edit — narrow those to Finance specifically.
DROP POLICY IF EXISTS "platform_fee_tiers_admin_write" ON public.platform_fee_tiers;
CREATE POLICY "platform_fee_tiers_admin_write" ON public.platform_fee_tiers FOR ALL TO authenticated
  USING (public.has_department(auth.uid(), 'finance')) WITH CHECK (public.has_department(auth.uid(), 'finance'));

DROP POLICY IF EXISTS "platform_settings_admin_write" ON public.platform_settings;
CREATE POLICY "platform_settings_admin_write" ON public.platform_settings FOR ALL TO authenticated
  USING (public.has_department(auth.uid(), 'finance')) WITH CHECK (public.has_department(auth.uid(), 'finance'));

DROP POLICY IF EXISTS "refund_requests_admin_update" ON public.refund_requests;
CREATE POLICY "refund_requests_admin_update" ON public.refund_requests FOR UPDATE TO authenticated
  USING (public.has_department(auth.uid(), 'finance')) WITH CHECK (public.has_department(auth.uid(), 'finance'));
DROP POLICY IF EXISTS "refund_requests_buyer_read" ON public.refund_requests;
CREATE POLICY "refund_requests_buyer_read" ON public.refund_requests FOR SELECT TO authenticated
  USING (auth.uid() = buyer_id OR public.has_department(auth.uid(), 'finance'));

DROP POLICY IF EXISTS "payments_party_read" ON public.payments;
CREATE POLICY "payments_party_read" ON public.payments FOR SELECT TO authenticated
  USING (
    EXISTS (SELECT 1 FROM public.orders o WHERE o.id = order_id AND (o.buyer_id = auth.uid() OR o.seller_id = auth.uid()))
    OR public.has_department(auth.uid(), 'finance')
  );

-- Vehicle tiers (transport pricing config) sits with Logistics rather than
-- Finance — it's about vehicle/route economics, not company money movement.
DROP POLICY IF EXISTS "vehicle_tiers_admin_write" ON public.vehicle_tiers;
CREATE POLICY "vehicle_tiers_admin_write" ON public.vehicle_tiers FOR ALL TO authenticated
  USING (public.has_department(auth.uid(), 'logistics')) WITH CHECK (public.has_department(auth.uid(), 'logistics'));

-- Marketplace: product moderation and market price data.
DROP POLICY IF EXISTS "products_admin_update" ON public.products;
CREATE POLICY "products_admin_update" ON public.products FOR UPDATE TO authenticated
  USING (public.has_department(auth.uid(), 'marketplace')) WITH CHECK (public.has_department(auth.uid(), 'marketplace'));
DROP POLICY IF EXISTS "products_admin_delete" ON public.products;
CREATE POLICY "products_admin_delete" ON public.products FOR DELETE TO authenticated
  USING (public.has_department(auth.uid(), 'marketplace'));

-- Support: the contact-form inbox.
DROP POLICY IF EXISTS "contact_messages_admin_read" ON public.contact_messages;
CREATE POLICY "contact_messages_admin_read" ON public.contact_messages FOR SELECT TO authenticated
  USING (public.has_department(auth.uid(), 'support'));
DROP POLICY IF EXISTS "contact_messages_admin_update" ON public.contact_messages;
CREATE POLICY "contact_messages_admin_update" ON public.contact_messages FOR UPDATE TO authenticated
  USING (public.has_department(auth.uid(), 'support')) WITH CHECK (public.has_department(auth.uid(), 'support'));

CREATE OR REPLACE FUNCTION public.notify_new_refund_request()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.notifications (user_id, title, body, kind)
  SELECT s.user_id, 'New refund request', NEW.reason, 'order'
  FROM public.admin_staff s WHERE s.department IN ('finance', 'super_admin');
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.notify_new_driver_application()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.notifications (user_id, title, body, kind)
  SELECT s.user_id, 'New driver application', NEW.display_name || ' applied to become an AGROVIAX driver.', 'message'
  FROM public.admin_staff s WHERE s.department IN ('logistics', 'super_admin');
  RETURN NEW;
END;
$$;
