
-- ENUMS
CREATE TYPE public.app_role AS ENUM ('farmer','buyer','business','expert','transporter','admin');
CREATE TYPE public.crop_status AS ENUM ('planned','planted','growing','ready_for_harvest','harvested','completed');
CREATE TYPE public.order_status AS ENUM ('pending','confirmed','paid','in_transit','delivered','cancelled');
CREATE TYPE public.case_status AS ENUM ('analyzing','analyzed','expert_requested','expert_reviewed');

-- UPDATED AT
CREATE OR REPLACE FUNCTION public.update_updated_at_column() RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$ LANGUAGE plpgsql SET search_path = public;

-- PROFILES
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  full_name TEXT NOT NULL DEFAULT '',
  phone TEXT,
  location TEXT,
  bio TEXT,
  avatar_url TEXT,
  organization TEXT,
  verified BOOLEAN NOT NULL DEFAULT false,
  rating NUMERIC(3,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT SELECT ON public.profiles TO anon;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "profiles_public_read" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "profiles_self_insert" ON public.profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);
CREATE POLICY "profiles_self_update" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);
CREATE TRIGGER profiles_updated BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ROLES
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT, INSERT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role);
$$;

CREATE POLICY "roles_self_read" ON public.user_roles FOR SELECT TO authenticated USING (auth.uid() = user_id OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "roles_self_insert" ON public.user_roles FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id AND role <> 'admin');

-- NEW USER TRIGGER
CREATE OR REPLACE FUNCTION public.handle_new_user() RETURNS TRIGGER
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE r public.app_role;
BEGIN
  INSERT INTO public.profiles (id, full_name, phone, location)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name',''), NEW.raw_user_meta_data->>'phone', NEW.raw_user_meta_data->>'location')
  ON CONFLICT (id) DO NOTHING;
  BEGIN
    r := COALESCE((NEW.raw_user_meta_data->>'role')::public.app_role, 'farmer');
  EXCEPTION WHEN others THEN r := 'farmer'; END;
  IF r = 'admin' THEN r := 'farmer'; END IF;
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, r) ON CONFLICT DO NOTHING;
  RETURN NEW;
END; $$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- FARMS
CREATE TABLE public.farms (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  name TEXT NOT NULL,
  location TEXT NOT NULL DEFAULT '',
  size NUMERIC(10,2) NOT NULL DEFAULT 0,
  size_unit TEXT NOT NULL DEFAULT 'hectares',
  soil_type TEXT,
  irrigation_method TEXT,
  description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.farms TO authenticated;
GRANT ALL ON public.farms TO service_role;
ALTER TABLE public.farms ENABLE ROW LEVEL SECURITY;
CREATE POLICY "farms_owner_all" ON public.farms FOR ALL TO authenticated USING (auth.uid() = owner_id OR public.has_role(auth.uid(),'admin')) WITH CHECK (auth.uid() = owner_id);
CREATE TRIGGER farms_updated BEFORE UPDATE ON public.farms FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- CROPS
CREATE TABLE public.crops (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  farm_id UUID NOT NULL REFERENCES public.farms ON DELETE CASCADE,
  owner_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  crop_type TEXT NOT NULL,
  variety TEXT,
  planting_date DATE,
  expected_harvest DATE,
  quantity_planted NUMERIC(12,2),
  expected_yield NUMERIC(12,2),
  actual_yield NUMERIC(12,2),
  status public.crop_status NOT NULL DEFAULT 'planned',
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.crops TO authenticated;
GRANT ALL ON public.crops TO service_role;
ALTER TABLE public.crops ENABLE ROW LEVEL SECURITY;
CREATE POLICY "crops_owner_all" ON public.crops FOR ALL TO authenticated USING (auth.uid() = owner_id OR public.has_role(auth.uid(),'admin')) WITH CHECK (auth.uid() = owner_id);
CREATE TRIGGER crops_updated BEFORE UPDATE ON public.crops FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ACTIVITIES
CREATE TABLE public.crop_activities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  farm_id UUID REFERENCES public.farms ON DELETE CASCADE,
  crop_id UUID REFERENCES public.crops ON DELETE CASCADE,
  activity_type TEXT NOT NULL,
  activity_date DATE NOT NULL DEFAULT CURRENT_DATE,
  notes TEXT,
  cost NUMERIC(12,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.crop_activities TO authenticated;
GRANT ALL ON public.crop_activities TO service_role;
ALTER TABLE public.crop_activities ENABLE ROW LEVEL SECURITY;
CREATE POLICY "activities_owner_all" ON public.crop_activities FOR ALL TO authenticated USING (auth.uid() = owner_id OR public.has_role(auth.uid(),'admin')) WITH CHECK (auth.uid() = owner_id);

-- HARVESTS
CREATE TABLE public.harvests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  crop_id UUID REFERENCES public.crops ON DELETE CASCADE,
  farm_id UUID REFERENCES public.farms ON DELETE CASCADE,
  harvest_date DATE NOT NULL DEFAULT CURRENT_DATE,
  quantity NUMERIC(12,2) NOT NULL DEFAULT 0,
  unit TEXT NOT NULL DEFAULT 'kg',
  quality_grade TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.harvests TO authenticated;
GRANT ALL ON public.harvests TO service_role;
ALTER TABLE public.harvests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "harvests_owner_all" ON public.harvests FOR ALL TO authenticated USING (auth.uid() = owner_id OR public.has_role(auth.uid(),'admin')) WITH CHECK (auth.uid() = owner_id);

-- EXPENSES
CREATE TABLE public.expenses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  farm_id UUID REFERENCES public.farms ON DELETE CASCADE,
  crop_id UUID REFERENCES public.crops ON DELETE SET NULL,
  category TEXT NOT NULL,
  amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  description TEXT,
  expense_date DATE NOT NULL DEFAULT CURRENT_DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.expenses TO authenticated;
GRANT ALL ON public.expenses TO service_role;
ALTER TABLE public.expenses ENABLE ROW LEVEL SECURITY;
CREATE POLICY "expenses_owner_all" ON public.expenses FOR ALL TO authenticated USING (auth.uid() = owner_id OR public.has_role(auth.uid(),'admin')) WITH CHECK (auth.uid() = owner_id);

-- INCOME
CREATE TABLE public.incomes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  farm_id UUID REFERENCES public.farms ON DELETE CASCADE,
  crop_id UUID REFERENCES public.crops ON DELETE SET NULL,
  source TEXT NOT NULL DEFAULT 'sale',
  amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  description TEXT,
  income_date DATE NOT NULL DEFAULT CURRENT_DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.incomes TO authenticated;
GRANT ALL ON public.incomes TO service_role;
ALTER TABLE public.incomes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "incomes_owner_all" ON public.incomes FOR ALL TO authenticated USING (auth.uid() = owner_id OR public.has_role(auth.uid(),'admin')) WITH CHECK (auth.uid() = owner_id);

-- INVENTORY
CREATE TABLE public.inventory (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  farm_id UUID REFERENCES public.farms ON DELETE CASCADE,
  item_name TEXT NOT NULL,
  item_type TEXT NOT NULL DEFAULT 'input',
  quantity NUMERIC(12,2) NOT NULL DEFAULT 0,
  unit TEXT NOT NULL DEFAULT 'kg',
  low_stock_threshold NUMERIC(12,2) NOT NULL DEFAULT 0,
  unit_cost NUMERIC(12,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.inventory TO authenticated;
GRANT ALL ON public.inventory TO service_role;
ALTER TABLE public.inventory ENABLE ROW LEVEL SECURITY;
CREATE POLICY "inventory_owner_all" ON public.inventory FOR ALL TO authenticated USING (auth.uid() = owner_id OR public.has_role(auth.uid(),'admin')) WITH CHECK (auth.uid() = owner_id);
CREATE TRIGGER inventory_updated BEFORE UPDATE ON public.inventory FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- CATEGORIES
CREATE TABLE public.categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'produce',
  description TEXT
);
GRANT SELECT ON public.categories TO anon, authenticated;
GRANT ALL ON public.categories TO service_role;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "categories_public_read" ON public.categories FOR SELECT USING (true);

-- PRODUCTS
CREATE TABLE public.products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id UUID REFERENCES auth.users ON DELETE CASCADE,
  seller_name TEXT NOT NULL DEFAULT 'AGROVIAX Verified Seller',
  category_slug TEXT NOT NULL DEFAULT 'grains',
  title TEXT NOT NULL,
  description TEXT,
  price NUMERIC(12,2) NOT NULL DEFAULT 0,
  currency TEXT NOT NULL DEFAULT 'NGN',
  unit TEXT NOT NULL DEFAULT 'kg',
  quantity_available NUMERIC(12,2) NOT NULL DEFAULT 0,
  location TEXT NOT NULL DEFAULT '',
  image_url TEXT,
  organic BOOLEAN NOT NULL DEFAULT false,
  verified BOOLEAN NOT NULL DEFAULT false,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.products TO authenticated;
GRANT SELECT ON public.products TO anon;
GRANT ALL ON public.products TO service_role;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
CREATE POLICY "products_public_read" ON public.products FOR SELECT USING (status = 'active' OR auth.uid() = seller_id OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "products_seller_insert" ON public.products FOR INSERT TO authenticated WITH CHECK (auth.uid() = seller_id);
CREATE POLICY "products_seller_update" ON public.products FOR UPDATE TO authenticated USING (auth.uid() = seller_id OR public.has_role(auth.uid(),'admin')) WITH CHECK (auth.uid() = seller_id OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "products_seller_delete" ON public.products FOR DELETE TO authenticated USING (auth.uid() = seller_id OR public.has_role(auth.uid(),'admin'));
CREATE TRIGGER products_updated BEFORE UPDATE ON public.products FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ORDERS
CREATE TABLE public.orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  buyer_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  seller_id UUID REFERENCES auth.users ON DELETE SET NULL,
  total_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  status public.order_status NOT NULL DEFAULT 'pending',
  delivery_address TEXT NOT NULL DEFAULT '',
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.orders TO authenticated;
GRANT ALL ON public.orders TO service_role;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
CREATE POLICY "orders_party_read" ON public.orders FOR SELECT TO authenticated USING (auth.uid() = buyer_id OR auth.uid() = seller_id OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "orders_buyer_insert" ON public.orders FOR INSERT TO authenticated WITH CHECK (auth.uid() = buyer_id);
CREATE POLICY "orders_party_update" ON public.orders FOR UPDATE TO authenticated USING (auth.uid() = buyer_id OR auth.uid() = seller_id OR public.has_role(auth.uid(),'admin')) WITH CHECK (true);
CREATE TRIGGER orders_updated BEFORE UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ORDER ITEMS
CREATE TABLE public.order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES public.orders ON DELETE CASCADE,
  product_id UUID REFERENCES public.products ON DELETE SET NULL,
  title TEXT NOT NULL,
  quantity NUMERIC(12,2) NOT NULL DEFAULT 1,
  unit_price NUMERIC(12,2) NOT NULL DEFAULT 0
);
GRANT SELECT, INSERT ON public.order_items TO authenticated;
GRANT ALL ON public.order_items TO service_role;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "order_items_party_read" ON public.order_items FOR SELECT TO authenticated USING (EXISTS (SELECT 1 FROM public.orders o WHERE o.id = order_id AND (o.buyer_id = auth.uid() OR o.seller_id = auth.uid() OR public.has_role(auth.uid(),'admin'))));
CREATE POLICY "order_items_buyer_insert" ON public.order_items FOR INSERT TO authenticated WITH CHECK (EXISTS (SELECT 1 FROM public.orders o WHERE o.id = order_id AND o.buyer_id = auth.uid()));

-- BULK REQUESTS
CREATE TABLE public.bulk_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  buyer_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  crop_type TEXT NOT NULL,
  quantity NUMERIC(12,2) NOT NULL DEFAULT 0,
  unit TEXT NOT NULL DEFAULT 'kg',
  target_price NUMERIC(12,2),
  location TEXT,
  needed_by DATE,
  details TEXT,
  status TEXT NOT NULL DEFAULT 'open',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.bulk_requests TO authenticated;
GRANT SELECT ON public.bulk_requests TO anon;
GRANT ALL ON public.bulk_requests TO service_role;
ALTER TABLE public.bulk_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "bulk_public_read" ON public.bulk_requests FOR SELECT USING (status = 'open' OR auth.uid() = buyer_id OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "bulk_owner_write" ON public.bulk_requests FOR INSERT TO authenticated WITH CHECK (auth.uid() = buyer_id);
CREATE POLICY "bulk_owner_update" ON public.bulk_requests FOR UPDATE TO authenticated USING (auth.uid() = buyer_id OR public.has_role(auth.uid(),'admin')) WITH CHECK (true);
CREATE POLICY "bulk_owner_delete" ON public.bulk_requests FOR DELETE TO authenticated USING (auth.uid() = buyer_id OR public.has_role(auth.uid(),'admin'));

-- MARKET PRICES
CREATE TABLE public.market_prices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  crop_type TEXT NOT NULL,
  market_name TEXT NOT NULL,
  region TEXT NOT NULL,
  price NUMERIC(12,2) NOT NULL,
  unit TEXT NOT NULL DEFAULT 'kg',
  previous_price NUMERIC(12,2),
  recorded_on DATE NOT NULL DEFAULT CURRENT_DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.market_prices TO anon, authenticated;
GRANT ALL ON public.market_prices TO service_role;
ALTER TABLE public.market_prices ENABLE ROW LEVEL SECURITY;
CREATE POLICY "prices_public_read" ON public.market_prices FOR SELECT USING (true);
CREATE POLICY "prices_admin_write" ON public.market_prices FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

-- DISEASES
CREATE TABLE public.diseases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  affected_crops TEXT NOT NULL DEFAULT '',
  symptoms TEXT NOT NULL DEFAULT '',
  causes TEXT NOT NULL DEFAULT '',
  treatment TEXT NOT NULL DEFAULT '',
  prevention TEXT NOT NULL DEFAULT '',
  severity TEXT NOT NULL DEFAULT 'moderate'
);
GRANT SELECT ON public.diseases TO anon, authenticated;
GRANT ALL ON public.diseases TO service_role;
ALTER TABLE public.diseases ENABLE ROW LEVEL SECURITY;
CREATE POLICY "diseases_public_read" ON public.diseases FOR SELECT USING (true);

-- CROP GUIDES
CREATE TABLE public.crop_guides (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT NOT NULL UNIQUE,
  crop_name TEXT NOT NULL,
  overview TEXT NOT NULL DEFAULT '',
  soil TEXT NOT NULL DEFAULT '',
  planting TEXT NOT NULL DEFAULT '',
  spacing TEXT NOT NULL DEFAULT '',
  fertilization TEXT NOT NULL DEFAULT '',
  pests TEXT NOT NULL DEFAULT '',
  diseases TEXT NOT NULL DEFAULT '',
  harvesting TEXT NOT NULL DEFAULT '',
  storage TEXT NOT NULL DEFAULT '',
  market_info TEXT NOT NULL DEFAULT '',
  season TEXT NOT NULL DEFAULT ''
);
GRANT SELECT ON public.crop_guides TO anon, authenticated;
GRANT ALL ON public.crop_guides TO service_role;
ALTER TABLE public.crop_guides ENABLE ROW LEVEL SECURITY;
CREATE POLICY "guides_public_read" ON public.crop_guides FOR SELECT USING (true);

-- DISEASE CASES
CREATE TABLE public.disease_cases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  farmer_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  farm_id UUID REFERENCES public.farms ON DELETE SET NULL,
  crop_id UUID REFERENCES public.crops ON DELETE SET NULL,
  crop_type TEXT NOT NULL DEFAULT '',
  media_url TEXT,
  media_type TEXT NOT NULL DEFAULT 'image',
  symptoms_note TEXT,
  ai_disease TEXT,
  ai_confidence NUMERIC(5,2),
  ai_summary TEXT,
  ai_treatment TEXT,
  ai_prevention TEXT,
  status public.case_status NOT NULL DEFAULT 'analyzing',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.disease_cases TO authenticated;
GRANT ALL ON public.disease_cases TO service_role;
ALTER TABLE public.disease_cases ENABLE ROW LEVEL SECURITY;
CREATE POLICY "cases_owner_read" ON public.disease_cases FOR SELECT TO authenticated USING (auth.uid() = farmer_id OR public.has_role(auth.uid(),'expert') OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "cases_owner_insert" ON public.disease_cases FOR INSERT TO authenticated WITH CHECK (auth.uid() = farmer_id);
CREATE POLICY "cases_owner_update" ON public.disease_cases FOR UPDATE TO authenticated USING (auth.uid() = farmer_id OR public.has_role(auth.uid(),'expert') OR public.has_role(auth.uid(),'admin')) WITH CHECK (true);
CREATE POLICY "cases_owner_delete" ON public.disease_cases FOR DELETE TO authenticated USING (auth.uid() = farmer_id OR public.has_role(auth.uid(),'admin'));
CREATE TRIGGER cases_updated BEFORE UPDATE ON public.disease_cases FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- EXPERT REVIEWS
CREATE TABLE public.expert_reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id UUID NOT NULL REFERENCES public.disease_cases ON DELETE CASCADE,
  expert_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  diagnosis TEXT NOT NULL,
  recommendation TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.expert_reviews TO authenticated;
GRANT ALL ON public.expert_reviews TO service_role;
ALTER TABLE public.expert_reviews ENABLE ROW LEVEL SECURITY;
CREATE POLICY "reviews_read" ON public.expert_reviews FOR SELECT TO authenticated USING (EXISTS (SELECT 1 FROM public.disease_cases c WHERE c.id = case_id AND (c.farmer_id = auth.uid() OR public.has_role(auth.uid(),'expert') OR public.has_role(auth.uid(),'admin'))));
CREATE POLICY "reviews_expert_insert" ON public.expert_reviews FOR INSERT TO authenticated WITH CHECK (auth.uid() = expert_id AND public.has_role(auth.uid(),'expert'));

-- VEHICLES
CREATE TABLE public.vehicles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  transporter_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  vehicle_type TEXT NOT NULL,
  plate_number TEXT NOT NULL,
  capacity_kg NUMERIC(12,2) NOT NULL DEFAULT 0,
  base_location TEXT,
  available BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.vehicles TO authenticated;
GRANT ALL ON public.vehicles TO service_role;
ALTER TABLE public.vehicles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "vehicles_read" ON public.vehicles FOR SELECT TO authenticated USING (true);
CREATE POLICY "vehicles_owner_write" ON public.vehicles FOR INSERT TO authenticated WITH CHECK (auth.uid() = transporter_id);
CREATE POLICY "vehicles_owner_update" ON public.vehicles FOR UPDATE TO authenticated USING (auth.uid() = transporter_id OR public.has_role(auth.uid(),'admin')) WITH CHECK (true);
CREATE POLICY "vehicles_owner_delete" ON public.vehicles FOR DELETE TO authenticated USING (auth.uid() = transporter_id OR public.has_role(auth.uid(),'admin'));

-- DELIVERIES
CREATE TABLE public.deliveries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID REFERENCES public.orders ON DELETE CASCADE,
  transporter_id UUID REFERENCES auth.users ON DELETE SET NULL,
  pickup_location TEXT NOT NULL DEFAULT '',
  dropoff_location TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pending',
  fee NUMERIC(12,2) NOT NULL DEFAULT 0,
  scheduled_for DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.deliveries TO authenticated;
GRANT ALL ON public.deliveries TO service_role;
ALTER TABLE public.deliveries ENABLE ROW LEVEL SECURITY;
CREATE POLICY "deliveries_read" ON public.deliveries FOR SELECT TO authenticated USING (
  transporter_id = auth.uid() OR public.has_role(auth.uid(),'transporter') OR public.has_role(auth.uid(),'admin')
  OR EXISTS (SELECT 1 FROM public.orders o WHERE o.id = order_id AND (o.buyer_id = auth.uid() OR o.seller_id = auth.uid())));
CREATE POLICY "deliveries_insert" ON public.deliveries FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "deliveries_update" ON public.deliveries FOR UPDATE TO authenticated USING (transporter_id = auth.uid() OR public.has_role(auth.uid(),'transporter') OR public.has_role(auth.uid(),'admin')) WITH CHECK (true);
CREATE TRIGGER deliveries_updated BEFORE UPDATE ON public.deliveries FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- MESSAGES
CREATE TABLE public.messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  recipient_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  body TEXT NOT NULL,
  read_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.messages TO authenticated;
GRANT ALL ON public.messages TO service_role;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "messages_party_read" ON public.messages FOR SELECT TO authenticated USING (auth.uid() = sender_id OR auth.uid() = recipient_id);
CREATE POLICY "messages_send" ON public.messages FOR INSERT TO authenticated WITH CHECK (auth.uid() = sender_id);
CREATE POLICY "messages_mark_read" ON public.messages FOR UPDATE TO authenticated USING (auth.uid() = recipient_id) WITH CHECK (auth.uid() = recipient_id);

-- NOTIFICATIONS
CREATE TABLE public.notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  title TEXT NOT NULL,
  body TEXT,
  kind TEXT NOT NULL DEFAULT 'info',
  read_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.notifications TO authenticated;
GRANT ALL ON public.notifications TO service_role;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "notifications_owner" ON public.notifications FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- SELLER REVIEWS
CREATE TABLE public.seller_reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  reviewer_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  rating INT NOT NULL DEFAULT 5,
  comment TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (seller_id, reviewer_id)
);
GRANT SELECT, INSERT, UPDATE ON public.seller_reviews TO authenticated;
GRANT SELECT ON public.seller_reviews TO anon;
GRANT ALL ON public.seller_reviews TO service_role;
ALTER TABLE public.seller_reviews ENABLE ROW LEVEL SECURITY;
CREATE POLICY "seller_reviews_public_read" ON public.seller_reviews FOR SELECT USING (true);
CREATE POLICY "seller_reviews_write" ON public.seller_reviews FOR INSERT TO authenticated WITH CHECK (auth.uid() = reviewer_id);
CREATE POLICY "seller_reviews_update" ON public.seller_reviews FOR UPDATE TO authenticated USING (auth.uid() = reviewer_id) WITH CHECK (auth.uid() = reviewer_id);

-- SEED CATEGORIES
INSERT INTO public.categories (slug, name, kind, description) VALUES
('grains','Grains & Cereals','produce','Maize, rice, sorghum, millet and wheat'),
('tubers','Tubers & Roots','produce','Yam, cassava, potato and sweet potato'),
('vegetables','Vegetables','produce','Tomato, pepper, onion, okra and leafy greens'),
('fruits','Fruits','produce','Mango, pineapple, banana, citrus and watermelon'),
('legumes','Legumes & Nuts','produce','Cowpea, soybean, groundnut and sesame'),
('livestock','Livestock & Poultry','produce','Live birds, goats, eggs and dairy'),
('seeds','Seeds & Seedlings','input','Certified seed and improved planting material'),
('fertilizers','Fertilizers','input','Organic and mineral soil nutrition'),
('crop-protection','Crop Protection','input','Herbicides, fungicides and biopesticides'),
('equipment','Equipment & Tools','input','Tractors, sprayers, harvesters and hand tools'),
('irrigation','Irrigation Supplies','input','Pumps, drip lines, sprinklers and tanks'),
('feed','Animal Feed','input','Poultry, fish and livestock feed');

-- SEED PRODUCTS
INSERT INTO public.products (seller_name, category_slug, title, description, price, unit, quantity_available, location, organic, verified, image_url) VALUES
('Kano Grain Collective','grains','Premium White Maize (Dry)','Cleaned, sun-dried white maize at 13% moisture. Bagged in 100kg sacks, ready for immediate pickup.',780,'kg',42000,'Kano State',false,true,'https://images.unsplash.com/photo-1551754655-cd27e38d2076?auto=format&fit=crop&w=1200&q=80'),
('Ebonyi Rice Farmers Union','grains','Long Grain Parboiled Rice','Locally milled, destoned parboiled rice from the 2026 wet season harvest.',1450,'kg',18000,'Ebonyi State',false,true,'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=1200&q=80'),
('Benue Root Crops Ltd','tubers','Fresh Puna Yam Tubers','Grade A puna yam tubers, average 3-4kg each, harvested this month.',1200,'tuber',6500,'Benue State',false,true,'https://images.unsplash.com/photo-1596097635121-14b63b7a0c19?auto=format&fit=crop&w=1200&q=80'),
('Jos Highland Produce','vegetables','Fresh Roma Tomatoes','Firm, deep-red Roma tomatoes packed in ventilated crates to reduce transit loss.',950,'kg',9000,'Plateau State',true,true,'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&w=1200&q=80'),
('Sokoto Allium Growers','vegetables','Red Onion Bulbs (Cured)','Cured red onions with strong storage life, sorted by size.',870,'kg',14000,'Sokoto State',false,true,'https://images.unsplash.com/photo-1618512496248-a07fe83aa8cb?auto=format&fit=crop&w=1200&q=80'),
('Oyo Orchard Partners','fruits','Sweet Kent Mangoes','Tree-ripened Kent mangoes, hand-picked and field-graded.',1100,'kg',4200,'Oyo State',true,false,'https://images.unsplash.com/photo-1553279768-865429fa0078?auto=format&fit=crop&w=1200&q=80'),
('Kaduna Legume Hub','legumes','Brown Cowpea (Beans)','Well-sorted brown cowpea, low breakage, treated for storage weevils.',1650,'kg',11000,'Kaduna State',false,true,'https://images.unsplash.com/photo-1515543237350-b3eea1ec8082?auto=format&fit=crop&w=1200&q=80'),
('Delta Poultry Co-op','livestock','Farm Fresh Crate Eggs','Point-of-lay farm eggs, collected daily and candled before dispatch.',4200,'crate',900,'Delta State',false,true,'https://images.unsplash.com/photo-1587486913049-53fc88980cfc?auto=format&fit=crop&w=1200&q=80'),
('SeedTech Nigeria','seeds','Hybrid Maize Seed SC-651','High-yield hybrid maize seed, drought tolerant, 110-day maturity.',9500,'10kg bag',1200,'Abuja FCT',false,true,'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&w=1200&q=80'),
('GreenGrow Inputs','fertilizers','NPK 15-15-15 Fertilizer','Balanced granular NPK for cereals and vegetables. 50kg bag.',38000,'50kg bag',3000,'Lagos State',false,true,'https://images.unsplash.com/photo-1625246333195-78d9c38ad449?auto=format&fit=crop&w=1200&q=80'),
('AgriShield Supplies','crop-protection','Broad Spectrum Biofungicide','Copper-free biofungicide effective on blight and leaf spot complexes.',12500,'litre',700,'Ogun State',true,true,'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?auto=format&fit=crop&w=1200&q=80'),
('FarmPower Machinery','equipment','Knapsack Motorised Sprayer 20L','Petrol-powered 20L knapsack sprayer with adjustable nozzle set.',145000,'unit',180,'Kano State',false,true,'https://images.unsplash.com/photo-1592982537447-7440770cbfc9?auto=format&fit=crop&w=1200&q=80'),
('DripLine Africa','irrigation','Drip Irrigation Starter Kit','Covers 1 hectare: mainline, laterals, emitters, filter and fittings.',420000,'kit',95,'Kaduna State',false,true,'https://images.unsplash.com/photo-1563514227147-6d2ff665a6a0?auto=format&fit=crop&w=1200&q=80'),
('FeedMill Direct','feed','Broiler Finisher Feed','Balanced broiler finisher mash, 25kg bag, produced weekly.',18500,'25kg bag',2400,'Ibadan, Oyo',false,false,'https://images.unsplash.com/photo-1548550023-2bdb3c5beed7?auto=format&fit=crop&w=1200&q=80'),
('Cross River Cassava Group','tubers','Fresh Cassava Tubers','Freshly uprooted cassava, high starch content, ideal for garri and flour.',320,'kg',30000,'Cross River',false,true,'https://images.unsplash.com/photo-1518977676601-b53f82aba655?auto=format&fit=crop&w=1200&q=80'),
('Zaria Sesame Exporters','legumes','Cleaned Sesame Seed','99% purity cleaned white sesame seed, export grade.',2350,'kg',8000,'Kaduna State',false,true,'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=1200&q=80');

-- SEED MARKET PRICES
INSERT INTO public.market_prices (crop_type, market_name, region, price, unit, previous_price, recorded_on) VALUES
('Maize','Dawanau International Market','North West',780,'kg',745,CURRENT_DATE),
('Maize','Mile 12 Market','South West',865,'kg',880,CURRENT_DATE),
('Rice (Paddy)','Abakaliki Rice Mill','South East',1180,'kg',1120,CURRENT_DATE),
('Rice (Milled)','Mile 12 Market','South West',1450,'kg',1420,CURRENT_DATE),
('Yam','Zaki Biam Yam Market','North Central',1200,'tuber',1350,CURRENT_DATE),
('Cassava','Ogbete Main Market','South East',320,'kg',298,CURRENT_DATE),
('Tomato','Jos Farin Gada Market','North Central',950,'kg',1240,CURRENT_DATE),
('Tomato','Mile 12 Market','South West',1180,'kg',1420,CURRENT_DATE),
('Onion','Sokoto Central Market','North West',870,'kg',760,CURRENT_DATE),
('Pepper','Bodija Market','South West',1620,'kg',1500,CURRENT_DATE),
('Cowpea','Kaduna Central Market','North West',1650,'kg',1580,CURRENT_DATE),
('Soybean','Makurdi Modern Market','North Central',1390,'kg',1300,CURRENT_DATE),
('Groundnut','Kano Kurmi Market','North West',2150,'kg',2050,CURRENT_DATE),
('Sesame','Zaria Grains Market','North West',2350,'kg',2280,CURRENT_DATE),
('Sorghum','Gombe Main Market','North East',690,'kg',655,CURRENT_DATE),
('Millet','Maiduguri Monday Market','North East',735,'kg',700,CURRENT_DATE),
('Plantain','Onitsha Main Market','South East',680,'kg',640,CURRENT_DATE),
('Palm Oil','Aba Ariaria Market','South East',2450,'litre',2300,CURRENT_DATE);

-- SEED DISEASES
INSERT INTO public.diseases (slug, name, affected_crops, symptoms, causes, treatment, prevention, severity) VALUES
('maize-streak-virus','Maize Streak Virus','Maize','Narrow, broken yellow streaks running parallel to leaf veins; stunted plants; poor cob fill.','Transmitted by leafhoppers (Cicadulina species), especially in late-planted fields.','Rogue severely infected plants early. Apply a recommended systemic insecticide to reduce leafhopper pressure.','Plant early and uniformly, use resistant hybrids, and control grass weeds that host leafhoppers.','high'),
('cassava-mosaic','Cassava Mosaic Disease','Cassava','Yellow-green mosaic patterning, leaf distortion and reduced leaf size; tuber yield loss up to 70%.','Begomoviruses spread by whitefly and by planting infected stem cuttings.','No curative treatment. Remove and destroy infected stands, then replant with clean material.','Use certified disease-free cuttings and tolerant varieties; manage whitefly populations.','high'),
('tomato-early-blight','Tomato Early Blight','Tomato, Potato','Dark brown concentric-ring lesions on older leaves, yellow halos, progressive defoliation.','Alternaria solani fungus favoured by warm, humid weather and overhead irrigation.','Apply a protectant fungicide on a 7-10 day schedule and remove infected lower leaves.','Rotate away from solanaceous crops, mulch to limit soil splash, and stake for airflow.','moderate'),
('tomato-late-blight','Tomato Late Blight','Tomato, Potato','Water-soaked grey-green lesions that turn brown, white fuzzy growth under leaves in humid mornings.','Phytophthora infestans, spreads rapidly in cool wet conditions.','Destroy affected plants immediately and apply systemic fungicide to remaining stands.','Avoid overhead watering, space plants widely, and scout daily during rainy spells.','high'),
('rice-blast','Rice Blast','Rice','Diamond-shaped lesions with grey centres on leaves; neck rot causing whiteheads and empty panicles.','Magnaporthe oryzae, worsened by excess nitrogen and prolonged leaf wetness.','Apply tricyclazole-class fungicide at booting; drain fields briefly to reduce humidity.','Use resistant varieties, split nitrogen applications, and maintain balanced potassium.','high'),
('cowpea-aphid','Cowpea Aphid Infestation','Cowpea, Soybean','Clusters of black aphids on shoots and pods, curled leaves, sooty mould, stunted pods.','Aphis craccivora colonies building in dry spells with few natural enemies.','Spray a selective insecticide or neem-based product in the evening to protect pollinators.','Encourage ladybird beetles, intercrop with cereals, and avoid late planting.','moderate'),
('groundnut-rosette','Groundnut Rosette Disease','Groundnut','Stunted bushy plants with small chlorotic leaves; drastic pod yield reduction.','Virus complex transmitted by aphids, worst in sparsely planted fields.','Remove affected plants; treat aphid vectors early in the season.','Plant densely and early, and use rosette-resistant varieties.','high'),
('banana-sigatoka','Black Sigatoka','Banana, Plantain','Narrow dark streaks that widen into black necrotic patches; premature ripening of fruit.','Pseudocercospora fijiensis spores spread by wind and rain splash.','De-leaf infected foliage and apply a systemic fungicide programme.','Improve drainage, maintain plant spacing, and de-sucker regularly.','moderate'),
('okra-mosaic','Okra Mosaic Virus','Okra','Vein-banding yellow mosaic, deformed pods, reduced pod set.','Virus transmitted by whitefly and flea beetles.','Remove infected plants; control the insect vectors promptly.','Use clean seed, remove volunteer hosts, and apply reflective mulch.','moderate'),
('poultry-newcastle','Newcastle Disease','Poultry','Greenish diarrhoea, respiratory distress, twisted neck, sudden high mortality.','Highly contagious avian paramyxovirus spread by contact and contaminated equipment.','No cure once infected. Isolate the flock and consult a veterinarian immediately.','Vaccinate on schedule, enforce strict biosecurity, and quarantine new birds.','high');

-- SEED CROP GUIDES
INSERT INTO public.crop_guides (slug, crop_name, overview, soil, planting, spacing, fertilization, pests, diseases, harvesting, storage, market_info, season) VALUES
('maize','Maize','Maize is the most widely grown cereal across the savannah and forest transition belts, used for food, feed and industrial starch.','Well-drained sandy loam with pH 5.8-7.0 and good organic matter.','Plant 2-3cm deep at the onset of stable rains; 2 seeds per hole thinned to one.','75cm between rows and 25cm within rows, giving about 53,000 plants per hectare.','Apply NPK 15-15-15 at planting and top-dress with urea at 4-6 weeks after emergence.','Fall armyworm, stem borer, termites and storage weevils.','Maize streak virus, leaf blight, rust and downy mildew.','Harvest when husks dry and kernels dent, around 100-120 days depending on variety.','Dry to 13% moisture, treat and store in hermetic bags away from moisture.','Steady year-round demand from feed mills, breweries and food processors.','Wet season, planted April-June'),
('rice','Rice','Rice is a staple with strong domestic demand and rapidly growing local milling capacity.','Clay or clay-loam soils that hold water; lowland fadama land is ideal.','Transplant 21-day-old seedlings or drill direct-seed in puddled fields.','20cm x 20cm for transplanted lowland rice.','Split nitrogen in three doses; add phosphorus at land preparation and potassium at panicle initiation.','Stem borer, rice bug, birds and rodents.','Rice blast, bacterial leaf blight and sheath rot.','Harvest at 85% grain maturity when panicles bend, roughly 110-140 days.','Dry paddy to 14% moisture before milling or bagging.','Milled rice attracts a strong premium over paddy; parboiling adds further value.','Wet season and irrigated dry season'),
('tomato','Tomato','Tomato is a high-value vegetable with sharp seasonal price swings and significant post-harvest loss risk.','Fertile, well-drained loam with pH 6.0-6.8.','Raise seedlings in a nursery for 3-4 weeks, then transplant in the cool of the evening.','60cm between plants and 75cm between rows on ridges.','Apply well-rotted manure at land preparation, then NPK and calcium to prevent blossom-end rot.','Whitefly, leaf miner, fruit borer and nematodes.','Early blight, late blight, bacterial wilt and tomato leaf curl.','Harvest at the breaker stage for distant markets, full red for local sale.','Store in ventilated crates in shade; avoid stacking in sacks.','Prices peak in the late dry season when supply from the north thins out.','Dry season with irrigation gives the best prices'),
('cassava','Cassava','Cassava is a resilient root crop and the base of garri, fufu and industrial starch value chains.','Tolerates poor soils but yields best in light, well-drained sandy loam.','Plant 25cm stem cuttings at a slant, 5-10cm into ridges or mounds.','1m x 1m, giving about 10,000 stands per hectare.','Apply NPK 15-15-15 at 8 weeks; potassium strongly influences tuber bulking.','Variegated grasshopper, mealybug and green mite.','Cassava mosaic disease and cassava bacterial blight.','Harvest 9-15 months after planting, when leaves start yellowing.','Process within 48 hours of harvest; fresh roots deteriorate quickly.','Processors pay premiums for high-starch fresh roots delivered promptly.','Plant at the start of the rains'),
('cowpea','Cowpea','Cowpea supplies affordable protein and improves soil nitrogen for the next cereal crop.','Light, well-drained sandy soils; avoid waterlogged fields.','Sow 3-4cm deep after the rains stabilise; use treated certified seed.','60cm x 20cm for spreading types, closer for erect varieties.','Low nitrogen requirement; apply phosphorus at planting for nodulation.','Aphids, flower thrips, pod borer and bruchid weevils in store.','Bacterial blight, brown blotch and cowpea mosaic.','Harvest pods when dry and brittle, usually 65-90 days.','Sun-dry, then store hermetically to control bruchids without chemicals.','Prices rise sharply in the months before the next harvest.','Late rains, planted July-August'),
('yam','Yam','Yam is a high-value tuber central to food security and ceremony across the middle belt.','Deep, fertile, free-draining loam; avoid stony ground.','Plant setts of 250-500g in large mounds at the start of the rains.','1m x 1m on mounds, staked for vine support.','Apply organic manure plus balanced NPK; excess nitrogen reduces storability.','Yam beetle, nematodes and termites.','Anthracnose and yam mosaic virus.','Harvest 7-10 months after planting; double-harvest varieties allow an early lift.','Cure tubers, then store in a ventilated, shaded yam barn.','Prices climb steeply between planting and the new-yam festival period.','Plant November-March depending on zone');
