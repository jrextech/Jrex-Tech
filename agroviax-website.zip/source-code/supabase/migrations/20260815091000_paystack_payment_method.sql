-- The original payment_method values assumed no gateway ("settle privately
-- by this method"). Real gateway payment now exists (see src/lib/paystack.ts),
-- so a buyer needs a way to actually select it at checkout.
ALTER TABLE public.orders DROP CONSTRAINT IF EXISTS orders_payment_method_check;
ALTER TABLE public.orders ADD CONSTRAINT orders_payment_method_check
  CHECK (payment_method IN ('pay_on_delivery', 'bank_transfer', 'paystack'));
