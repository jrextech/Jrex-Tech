-- The original schema migration seeded the marketplace with example produce
-- listings (maize, tomatoes, onions, etc.) so the page wasn't empty on
-- first load. Those rows have no seller_id (no real account behind them),
-- so "Message seller" / "Add to basket" on them led nowhere real — a buyer
-- could not actually reach anyone. Real listings created through
-- /dashboard/listings always have seller_id set (see dashboard.listings.tsx),
-- so this only removes the fake demo rows and leaves every real user's
-- listing untouched.
DELETE FROM public.products WHERE seller_id IS NULL;
