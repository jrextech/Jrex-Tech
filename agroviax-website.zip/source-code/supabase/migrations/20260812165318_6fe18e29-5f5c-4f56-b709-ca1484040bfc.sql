
CREATE POLICY "crop_media_insert_own" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'crop-media' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "crop_media_read_own" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'crop-media' AND ((storage.foldername(name))[1] = auth.uid()::text OR public.has_role(auth.uid(),'expert') OR public.has_role(auth.uid(),'admin')));
CREATE POLICY "crop_media_delete_own" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'crop-media' AND (storage.foldername(name))[1] = auth.uid()::text);
