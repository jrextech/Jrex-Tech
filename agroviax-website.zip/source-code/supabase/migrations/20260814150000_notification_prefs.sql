-- Per-user notification preferences, checked by the notification triggers
-- below (not just filtered in the UI — a toggle that only hides
-- already-created rows isn't a real preference, it has to stop them being
-- written in the first place).
ALTER TABLE public.profiles
  ADD COLUMN notification_prefs JSONB NOT NULL
  DEFAULT '{"order": true, "message": true, "delivery": true}'::jsonb;

CREATE OR REPLACE FUNCTION public.wants_notification(p_user_id UUID, p_kind TEXT)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COALESCE((SELECT (notification_prefs ->> p_kind)::boolean FROM public.profiles WHERE id = p_user_id), true);
$$;

CREATE OR REPLACE FUNCTION public.notify_new_order()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.seller_id IS NOT NULL AND public.wants_notification(NEW.seller_id, 'order') THEN
    INSERT INTO public.notifications (user_id, title, body, kind)
    VALUES (
      NEW.seller_id,
      'New order received',
      'A buyer placed an order worth ' || to_char(NEW.total_amount, 'FM999,999,990.00') ||
        ' (' || NEW.payment_method || '). Review and confirm it from your Orders dashboard.',
      'order'
    );
  END IF;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.notify_order_status_change()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.status IS DISTINCT FROM OLD.status AND public.wants_notification(NEW.buyer_id, 'order') THEN
    INSERT INTO public.notifications (user_id, title, body, kind)
    VALUES (NEW.buyer_id, 'Order update', 'Your order is now "' || NEW.status || '".', 'order');
  END IF;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.notify_new_message()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF public.wants_notification(NEW.recipient_id, 'message') THEN
    INSERT INTO public.notifications (user_id, title, body, kind)
    VALUES (NEW.recipient_id, 'New message', left(NEW.body, 140), 'message');
  END IF;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.notify_delivery_status_change()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  o RECORD;
BEGIN
  IF NEW.order_id IS NOT NULL AND NEW.status IS DISTINCT FROM OLD.status THEN
    SELECT buyer_id, seller_id INTO o FROM public.orders WHERE id = NEW.order_id;
    IF o.buyer_id IS NOT NULL AND public.wants_notification(o.buyer_id, 'delivery') THEN
      INSERT INTO public.notifications (user_id, title, body, kind)
      VALUES (o.buyer_id, 'Delivery update', 'Your delivery is now "' || NEW.status || '".', 'delivery');
    END IF;
    IF o.seller_id IS NOT NULL AND public.wants_notification(o.seller_id, 'delivery') THEN
      INSERT INTO public.notifications (user_id, title, body, kind)
      VALUES (o.seller_id, 'Delivery update', 'The delivery for your order is now "' || NEW.status || '".', 'delivery');
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.notify_new_delivery_job()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.notifications (user_id, title, body, kind)
  SELECT DISTINCT v.transporter_id, 'New delivery job available',
    NEW.pickup_location || ' → ' || NEW.dropoff_location || ' · fee ' || to_char(NEW.fee, 'FM999,999,990.00'),
    'delivery'
  FROM public.vehicles v
  WHERE v.available = true AND v.transporter_id IS NOT NULL AND public.wants_notification(v.transporter_id, 'delivery');
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.notify_new_expert_review()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  farmer UUID;
BEGIN
  SELECT farmer_id INTO farmer FROM public.disease_cases WHERE id = NEW.case_id;
  IF farmer IS NOT NULL AND public.wants_notification(farmer, 'message') THEN
    INSERT INTO public.notifications (user_id, title, body, kind)
    VALUES (farmer, 'Expert review ready', left(NEW.diagnosis, 140), 'message');
  END IF;
  RETURN NEW;
END;
$$;
