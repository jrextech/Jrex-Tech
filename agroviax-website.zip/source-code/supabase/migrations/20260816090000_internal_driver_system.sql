-- ============================================================
-- Internal, company-controlled logistics (Corrections & Architecture
-- Upgrade Plan, Section 4). Transporters are no longer an open pool who
-- self-claim jobs — AGROVIAX verifies and approves drivers, and only an
-- admin/logistics officer assigns a job to a specific approved driver.
-- ============================================================

CREATE TABLE public.drivers (
  user_id UUID PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,

  -- What the person submits when applying (Section 4A: identity, licence,
  -- vehicle, employment). display_name is the ONLY name ever shown to a
  -- buyer/seller — legal_name and licence details never leave this table.
  legal_name TEXT NOT NULL,
  display_name TEXT NOT NULL,
  phone TEXT,
  id_verification_status TEXT NOT NULL DEFAULT 'pending'
    CHECK (id_verification_status IN ('pending', 'verified', 'rejected')),

  license_number TEXT,
  license_expiry DATE,
  license_status TEXT NOT NULL DEFAULT 'pending'
    CHECK (license_status IN ('pending', 'verified', 'expired', 'rejected')),

  vehicle_type TEXT,
  plate_number TEXT,
  capacity_kg NUMERIC(12,2),
  vehicle_status TEXT NOT NULL DEFAULT 'pending'
    CHECK (vehicle_status IN ('pending', 'verified', 'rejected')),

  employment_status TEXT NOT NULL DEFAULT 'pending'
    CHECK (employment_status IN ('pending', 'active', 'ended')),
  onboarded_at DATE,

  -- The actual gate: only 'approved' drivers can ever be assigned a job
  -- (enforced below, not just by convention).
  approval_status TEXT NOT NULL DEFAULT 'pending'
    CHECK (approval_status IN ('pending', 'approved', 'suspended', 'rejected')),
  approved_by UUID REFERENCES auth.users,
  approved_at TIMESTAMPTZ,

  operational_status TEXT NOT NULL DEFAULT 'inactive'
    CHECK (operational_status IN ('available', 'on_delivery', 'suspended', 'inactive')),

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE ON public.drivers TO authenticated;
GRANT ALL ON public.drivers TO service_role;
ALTER TABLE public.drivers ENABLE ROW LEVEL SECURITY;

-- Anyone can apply (submit their own application) — recruitment can start
-- with a person applying, but that alone grants nothing; see approval_status.
CREATE POLICY "drivers_self_apply" ON public.drivers FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- An applicant can read/edit their own application ONLY while it's still
-- pending — once approved (or rejected/suspended), only an admin can change
-- it, so an approved driver can't quietly edit their own vehicle/licence
-- record without going back through review.
CREATE POLICY "drivers_self_read" ON public.drivers FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "drivers_self_update_while_pending" ON public.drivers FOR UPDATE TO authenticated
  USING (auth.uid() = user_id AND approval_status = 'pending')
  WITH CHECK (auth.uid() = user_id AND approval_status = 'pending');
CREATE POLICY "drivers_admin_update" ON public.drivers FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER drivers_updated BEFORE UPDATE ON public.drivers
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Buyer/seller-safe slice of a driver's record (Section 4B: "the buyer
-- should see enough to trust the delivery, never private documents").
-- A view exposing only these columns, for approved drivers only, is a
-- stronger guarantee than trusting every future query to remember which
-- columns are safe to select.
CREATE VIEW public.driver_public_info AS
  SELECT user_id, display_name, vehicle_type, plate_number, operational_status
  FROM public.drivers
  WHERE approval_status = 'approved';
GRANT SELECT ON public.driver_public_info TO authenticated;

CREATE OR REPLACE FUNCTION public.is_approved_driver(p_user_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SET search_path = public
AS $$
  SELECT EXISTS (SELECT 1 FROM public.drivers WHERE user_id = p_user_id AND approval_status = 'approved');
$$;

-- ============================================================
-- Deliveries: richer, auditable status trail (Section 4D) and — the actual
-- security fix — jobs can no longer be self-claimed by any transporter.
-- ============================================================
ALTER TABLE public.deliveries DROP CONSTRAINT IF EXISTS deliveries_status_check;
ALTER TABLE public.deliveries ALTER COLUMN status SET DEFAULT 'pending';
ALTER TABLE public.deliveries ADD CONSTRAINT deliveries_status_check
  CHECK (status IN (
    'pending', 'assigned', 'going_to_pickup', 'picked_up', 'in_transit',
    'near_destination', 'arrived', 'delivered', 'cancelled'
  ));

ALTER TABLE public.deliveries
  ADD COLUMN assigned_by UUID REFERENCES auth.users,
  ADD COLUMN assigned_at TIMESTAMPTZ,
  ADD COLUMN pickup_confirmed_at TIMESTAMPTZ,
  ADD COLUMN delivery_confirmed_at TIMESTAMPTZ,
  ADD COLUMN delivery_confirmation_code TEXT;

-- The real fix: drop the old "any transporter-role user can update any
-- delivery" clause. What's left — transporter_id = auth.uid() OR admin —
-- means an unassigned driver simply has no row to update at all, so
-- self-claiming an open job is no longer possible. Only an admin (assigning
-- via the has_role(admin) clause) or the already-assigned driver (updating
-- their own job's status) can write to a delivery.
DROP POLICY IF EXISTS "deliveries_update" ON public.deliveries;
CREATE POLICY "deliveries_update" ON public.deliveries FOR UPDATE TO authenticated
  USING (transporter_id = auth.uid() OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (
    -- Whoever is updating may change status/tracking fields freely, but
    -- transporter_id itself may only ever be SET (assigned) by an admin,
    -- and only to a user who is an approved driver.
    public.has_role(auth.uid(), 'admin')
    OR transporter_id = auth.uid()
  );

CREATE OR REPLACE FUNCTION public.enforce_driver_assignment()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.transporter_id IS DISTINCT FROM OLD.transporter_id THEN
    IF NOT public.has_role(auth.uid(), 'admin') THEN
      RAISE EXCEPTION 'Only AGROVIAX logistics/admin can assign a delivery to a driver.';
    END IF;
    IF NEW.transporter_id IS NOT NULL AND NOT public.is_approved_driver(NEW.transporter_id) THEN
      RAISE EXCEPTION 'This user is not an approved AGROVIAX driver.';
    END IF;
    NEW.assigned_by := auth.uid();
    NEW.assigned_at := now();
    IF NEW.status = 'pending' THEN
      NEW.status := 'assigned';
    END IF;
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER deliveries_enforce_driver_assignment
  BEFORE UPDATE ON public.deliveries
  FOR EACH ROW EXECUTE FUNCTION public.enforce_driver_assignment();

-- Notify the assigned driver directly (the existing "nudge every available
-- transporter" trigger from an earlier migration no longer makes sense once
-- jobs aren't an open pool — replaced with a targeted assignment notice).
DROP TRIGGER IF EXISTS deliveries_notify_transporters ON public.deliveries;
DROP FUNCTION IF EXISTS public.notify_new_delivery_job();

CREATE OR REPLACE FUNCTION public.notify_driver_assigned()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.transporter_id IS NOT NULL AND NEW.transporter_id IS DISTINCT FROM OLD.transporter_id
     AND public.wants_notification(NEW.transporter_id, 'delivery') THEN
    INSERT INTO public.notifications (user_id, title, body, kind)
    VALUES (
      NEW.transporter_id, 'New delivery assigned to you',
      NEW.pickup_location || ' \u2192 ' || NEW.dropoff_location || ' \u00b7 fee ' || to_char(NEW.fee, 'FM999,999,990.00'),
      'delivery'
    );
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER deliveries_notify_driver_assigned
  AFTER UPDATE ON public.deliveries
  FOR EACH ROW EXECUTE FUNCTION public.notify_driver_assigned();

CREATE OR REPLACE FUNCTION public.notify_new_driver_application()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.notifications (user_id, title, body, kind)
  SELECT ur.user_id, 'New driver application', NEW.display_name || ' applied to become an AGROVIAX driver.', 'message'
  FROM public.user_roles ur WHERE ur.role = 'admin';
  RETURN NEW;
END;
$$;
CREATE TRIGGER drivers_notify_admin_on_apply
  AFTER INSERT ON public.drivers
  FOR EACH ROW EXECUTE FUNCTION public.notify_new_driver_application();

CREATE OR REPLACE FUNCTION public.notify_driver_approval_change()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.approval_status IS DISTINCT FROM OLD.approval_status THEN
    INSERT INTO public.notifications (user_id, title, body, kind)
    VALUES (NEW.user_id, 'Driver application update', 'Your AGROVIAX driver application is now "' || NEW.approval_status || '".', 'message');
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER drivers_notify_applicant
  AFTER UPDATE ON public.drivers
  FOR EACH ROW EXECUTE FUNCTION public.notify_driver_approval_change();
