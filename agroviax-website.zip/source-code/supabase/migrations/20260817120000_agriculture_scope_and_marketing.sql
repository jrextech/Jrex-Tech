-- Narrow disease_cases admin access to Agriculture specifically — "a
-- department does not automatically receive unrestricted access to
-- another department's records" (Compressed Admin Structure, Section 11).
DROP POLICY IF EXISTS "cases_owner_read" ON public.disease_cases;
CREATE POLICY "cases_owner_read" ON public.disease_cases FOR SELECT TO authenticated
  USING (auth.uid() = farmer_id OR public.has_role(auth.uid(), 'expert') OR public.has_department(auth.uid(), 'agriculture'));

DROP POLICY IF EXISTS "cases_owner_update" ON public.disease_cases;
CREATE POLICY "cases_owner_update" ON public.disease_cases FOR UPDATE TO authenticated
  USING (auth.uid() = farmer_id OR public.has_role(auth.uid(), 'expert') OR public.has_department(auth.uid(), 'agriculture'))
  WITH CHECK (true);

DROP POLICY IF EXISTS "cases_owner_delete" ON public.disease_cases;
CREATE POLICY "cases_owner_delete" ON public.disease_cases FOR DELETE TO authenticated
  USING (auth.uid() = farmer_id OR public.has_department(auth.uid(), 'agriculture'));

-- ============================================================
-- Marketing & Communications: real content the department can publish,
-- shown as a homepage/site banner.
-- ============================================================
CREATE TABLE public.announcements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  starts_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  ends_at TIMESTAMPTZ,
  created_by UUID REFERENCES auth.users,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.announcements TO anon, authenticated;
GRANT ALL ON public.announcements TO service_role;
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;

CREATE POLICY "announcements_public_read" ON public.announcements FOR SELECT TO anon, authenticated
  USING (is_active = true AND starts_at <= now() AND (ends_at IS NULL OR ends_at > now()));
CREATE POLICY "announcements_marketing_read_all" ON public.announcements FOR SELECT TO authenticated
  USING (public.has_department(auth.uid(), 'marketing'));
CREATE POLICY "announcements_marketing_write" ON public.announcements FOR ALL TO authenticated
  USING (public.has_department(auth.uid(), 'marketing')) WITH CHECK (public.has_department(auth.uid(), 'marketing'));

CREATE TRIGGER announcements_updated BEFORE UPDATE ON public.announcements
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER audit_announcements AFTER INSERT OR UPDATE OR DELETE ON public.announcements
  FOR EACH ROW EXECUTE FUNCTION public.log_audit_event();
