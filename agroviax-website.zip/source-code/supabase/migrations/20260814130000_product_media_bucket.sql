-- Product/listing photos need to be publicly viewable (the marketplace is
-- browsable by anonymous visitors), unlike crop-media which is private.
-- This bucket is public for reads; writes are still scoped to the
-- uploading seller's own folder, same pattern as crop-media.
INSERT INTO storage.buckets (id, name, public)
VALUES ('product-media', 'product-media', true)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "product_media_public_read" ON storage.objects FOR SELECT TO public
  USING (bucket_id = 'product-media');

CREATE POLICY "product_media_insert_own" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'product-media' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "product_media_update_own" ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id = 'product-media' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "product_media_delete_own" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'product-media' AND (storage.foldername(name))[1] = auth.uid()::text);
