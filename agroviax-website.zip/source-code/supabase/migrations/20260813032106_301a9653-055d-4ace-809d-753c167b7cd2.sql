update public.products set image_url = '/__l5e/assets-v1/681571d1-5c12-42f3-a7e6-d99ed8309f36/puna-yam.jpg' where id = 'a02ebe3c-aaf6-4fb3-b67d-c7f8f5e5f6bb';

create policy products_admin_update on public.products for update to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
create policy products_admin_delete on public.products for delete to authenticated using (public.has_role(auth.uid(),'admin'));