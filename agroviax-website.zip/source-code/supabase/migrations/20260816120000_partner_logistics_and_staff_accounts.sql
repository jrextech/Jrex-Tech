-- A partner company's staff need their own role distinct from 'transporter'
-- (internal drivers) so the dashboard shell can route them to their own
-- portal using the same role-based nav pattern as every other role.
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'logistics_partner';

-- ============================================================
-- Corrections & Architecture Upgrade Plan + Logistics Architecture Update:
-- drivers are staff-only accounts AGROVIAX creates itself — there is no
-- public driver self-registration. The previous migration's
-- "drivers_self_apply" insert policy contradicts that, so it's replaced:
-- only an admin (via the createDriverAccount server function, using the
-- service-role client) can create a drivers row from now on.
-- ============================================================
DROP POLICY IF EXISTS "drivers_self_apply" ON public.drivers;
DROP POLICY IF EXISTS "drivers_self_update_while_pending" ON public.drivers;
-- Only the service-role client (server-side, never the browser) inserts
-- drivers rows now, so no INSERT policy for `authenticated` is needed at
-- all — service_role bypasses RLS by design. Admin can still edit a
-- driver's record after creation (verification steps, suspension, etc.)
-- via the existing "drivers_admin_update" policy.

ALTER TABLE public.drivers
  ADD COLUMN created_by UUID REFERENCES auth.users,
  ADD COLUMN branch_area TEXT;

-- ============================================================
-- External logistics partner companies (Logistics Architecture Update,
-- sections 6–8, 15): a separate, controlled category from internal
-- drivers. AGROVIAX vets and onboards a partner company, then that
-- company's own staff log in to a scoped portal to see only the delivery
-- jobs routed to them.
-- ============================================================
CREATE TABLE public.logistics_partners (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name TEXT NOT NULL,
  contact_name TEXT NOT NULL,
  contact_email TEXT,
  contact_phone TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'suspended')),
  notes TEXT,
  created_by UUID REFERENCES auth.users,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.logistics_partners TO authenticated;
GRANT ALL ON public.logistics_partners TO service_role;
ALTER TABLE public.logistics_partners ENABLE ROW LEVEL SECURITY;
CREATE POLICY "logistics_partners_admin_all" ON public.logistics_partners FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE TRIGGER logistics_partners_updated BEFORE UPDATE ON public.logistics_partners
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Staff accounts for a partner company — also created by AGROVIAX (or by
-- the partner's own admin once that's needed), never self-signup, same
-- principle as internal drivers.
CREATE TABLE public.logistics_partner_staff (
  user_id UUID PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  partner_id UUID NOT NULL REFERENCES public.logistics_partners ON DELETE CASCADE,
  display_name TEXT NOT NULL,
  role_title TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.logistics_partner_staff TO authenticated;
GRANT ALL ON public.logistics_partner_staff TO service_role;
ALTER TABLE public.logistics_partner_staff ENABLE ROW LEVEL SECURITY;
CREATE POLICY "partner_staff_self_read" ON public.logistics_partner_staff FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));

-- Now that logistics_partner_staff exists, add the partner-facing read
-- policy on logistics_partners that depends on it.
CREATE POLICY "logistics_partners_staff_read_own" ON public.logistics_partners FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.logistics_partner_staff s WHERE s.partner_id = id AND s.user_id = auth.uid()));

CREATE OR REPLACE FUNCTION public.is_partner_staff(p_user_id UUID, p_partner_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.logistics_partner_staff
    WHERE user_id = p_user_id AND partner_id = p_partner_id
  );
$$;

-- ============================================================
-- Deliveries: which provider is handling this job (Logistics Architecture
-- Update, section 8 "Common Delivery Record" — one Delivery ID, one shape,
-- whether it's an internal driver or a partner company).
-- ============================================================
ALTER TABLE public.deliveries
  ADD COLUMN provider_type TEXT NOT NULL DEFAULT 'internal' CHECK (provider_type IN ('internal', 'partner')),
  ADD COLUMN partner_id UUID REFERENCES public.logistics_partners,
  -- What the partner company enters for the job — their own driver/vehicle
  -- aren't AGROVIAX-verified records, just operational text they provide.
  ADD COLUMN partner_driver_name TEXT,
  ADD COLUMN partner_vehicle_info TEXT,
  ADD COLUMN delivery_evidence_url TEXT;

-- A partner's staff can see and update only jobs routed to their own
-- company — never another partner's, never an internal-driver job.
CREATE POLICY "deliveries_partner_staff_read" ON public.deliveries FOR SELECT TO authenticated
  USING (provider_type = 'partner' AND partner_id IS NOT NULL AND public.is_partner_staff(auth.uid(), partner_id));
CREATE POLICY "deliveries_partner_staff_update" ON public.deliveries FOR UPDATE TO authenticated
  USING (provider_type = 'partner' AND partner_id IS NOT NULL AND public.is_partner_staff(auth.uid(), partner_id))
  WITH CHECK (provider_type = 'partner' AND partner_id IS NOT NULL AND public.is_partner_staff(auth.uid(), partner_id));

CREATE OR REPLACE FUNCTION public.notify_partner_job_routed()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.provider_type = 'partner' AND NEW.partner_id IS NOT NULL
     AND (OLD.partner_id IS DISTINCT FROM NEW.partner_id) THEN
    INSERT INTO public.notifications (user_id, title, body, kind)
    SELECT s.user_id, 'New delivery job routed to your company',
      NEW.pickup_location || ' \u2192 ' || NEW.dropoff_location || ' \u00b7 fee ' || to_char(NEW.fee, 'FM999,999,990.00'),
      'delivery'
    FROM public.logistics_partner_staff s WHERE s.partner_id = NEW.partner_id;
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER deliveries_notify_partner
  AFTER UPDATE ON public.deliveries
  FOR EACH ROW EXECUTE FUNCTION public.notify_partner_job_routed();
