-- ============================================================
-- Payment method on orders
-- ============================================================
-- No real payment gateway is wired into this project (that needs a real
-- provider account + API keys, e.g. Paystack/Flutterwave, which isn't
-- something that can be fabricated). What's implemented instead is a
-- payment *method* choice at checkout, which is the honest, common pattern
-- for marketplaces like this: buyer and seller settle payment by the
-- chosen method outside the card-processing flow, while the order record
-- itself stays authoritative.
ALTER TABLE public.orders
  ADD COLUMN payment_method TEXT NOT NULL DEFAULT 'pay_on_delivery'
  CHECK (payment_method IN ('pay_on_delivery', 'bank_transfer'));

-- ============================================================
-- Notifications: populated by triggers, not client inserts.
-- The notifications table's RLS only allows a user to write their own rows
-- (auth.uid() = user_id), which is correct — a buyer's browser should not
-- be able to insert arbitrary rows into a seller's notification feed. The
-- standard, safe way to notify "the other party" is a SECURITY DEFINER
-- trigger function owned by the table owner, which runs with the
-- privileges to write across users but only ever in response to a real,
-- permitted action (an order being placed, a message being sent, etc).
-- ============================================================

CREATE OR REPLACE FUNCTION public.notify_new_order()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.seller_id IS NOT NULL THEN
    INSERT INTO public.notifications (user_id, title, body, kind)
    VALUES (
      NEW.seller_id,
      'New order received',
      'A buyer placed an order worth ' || to_char(NEW.total_amount, 'FM999,999,990.00') ||
        ' (' || NEW.payment_method || '). Review and confirm it from your Orders dashboard.',
      'order'
    );
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER orders_notify_seller
  AFTER INSERT ON public.orders
  FOR EACH ROW EXECUTE FUNCTION public.notify_new_order();

CREATE OR REPLACE FUNCTION public.notify_order_status_change()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.status IS DISTINCT FROM OLD.status THEN
    INSERT INTO public.notifications (user_id, title, body, kind)
    VALUES (
      NEW.buyer_id,
      'Order update',
      'Your order is now "' || NEW.status || '".',
      'order'
    );
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER orders_notify_status_change
  AFTER UPDATE ON public.orders
  FOR EACH ROW EXECUTE FUNCTION public.notify_order_status_change();

CREATE OR REPLACE FUNCTION public.notify_new_message()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.notifications (user_id, title, body, kind)
  VALUES (NEW.recipient_id, 'New message', left(NEW.body, 140), 'message');
  RETURN NEW;
END;
$$;

CREATE TRIGGER messages_notify_recipient
  AFTER INSERT ON public.messages
  FOR EACH ROW EXECUTE FUNCTION public.notify_new_message();

CREATE OR REPLACE FUNCTION public.notify_delivery_status_change()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  o RECORD;
BEGIN
  IF NEW.order_id IS NOT NULL AND NEW.status IS DISTINCT FROM OLD.status THEN
    SELECT buyer_id, seller_id INTO o FROM public.orders WHERE id = NEW.order_id;
    IF o.buyer_id IS NOT NULL THEN
      INSERT INTO public.notifications (user_id, title, body, kind)
      VALUES (o.buyer_id, 'Delivery update', 'Your delivery is now "' || NEW.status || '".', 'delivery');
    END IF;
    IF o.seller_id IS NOT NULL THEN
      INSERT INTO public.notifications (user_id, title, body, kind)
      VALUES (o.seller_id, 'Delivery update', 'The delivery for your order is now "' || NEW.status || '".', 'delivery');
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER deliveries_notify_status_change
  AFTER UPDATE ON public.deliveries
  FOR EACH ROW EXECUTE FUNCTION public.notify_delivery_status_change();

CREATE OR REPLACE FUNCTION public.notify_new_delivery_job()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Nudge every transporter who has at least one available vehicle.
  INSERT INTO public.notifications (user_id, title, body, kind)
  SELECT DISTINCT transporter_id, 'New delivery job available',
    NEW.pickup_location || ' → ' || NEW.dropoff_location || ' · fee ' || to_char(NEW.fee, 'FM999,999,990.00'),
    'delivery'
  FROM public.vehicles
  WHERE available = true AND transporter_id IS NOT NULL;
  RETURN NEW;
END;
$$;

CREATE TRIGGER deliveries_notify_transporters
  AFTER INSERT ON public.deliveries
  FOR EACH ROW EXECUTE FUNCTION public.notify_new_delivery_job();

CREATE OR REPLACE FUNCTION public.notify_new_expert_review()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  farmer UUID;
BEGIN
  SELECT farmer_id INTO farmer FROM public.disease_cases WHERE id = NEW.case_id;
  IF farmer IS NOT NULL THEN
    INSERT INTO public.notifications (user_id, title, body, kind)
    VALUES (farmer, 'Expert review ready', left(NEW.diagnosis, 140), 'message');
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER expert_reviews_notify_farmer
  AFTER INSERT ON public.expert_reviews
  FOR EACH ROW EXECUTE FUNCTION public.notify_new_expert_review();
