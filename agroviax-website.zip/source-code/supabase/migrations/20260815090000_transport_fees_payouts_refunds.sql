-- ============================================================
-- 1. Seller transport choice + product weight (for vehicle-tier fee calc)
-- ============================================================
ALTER TABLE public.products
  ADD COLUMN transport_option TEXT NOT NULL DEFAULT 'seller_provides'
    CHECK (transport_option IN ('seller_provides', 'need_transport')),
  ADD COLUMN weight_kg NUMERIC(10,2);

COMMENT ON COLUMN public.products.transport_option IS
  'seller_provides: seller already has their own transporter, no platform delivery job or fee.
   need_transport: seller wants AGROVIAX to find a transporter; only then can a buyer request delivery.';

-- ============================================================
-- 2. Buyer's per-order delivery choice + the fee breakdown that resulted
-- ============================================================
ALTER TABLE public.orders
  ADD COLUMN delivery_option TEXT NOT NULL DEFAULT 'buyer_pickup'
    CHECK (delivery_option IN ('buyer_pickup', 'need_transport')),
  ADD COLUMN transport_fee NUMERIC(12,2) NOT NULL DEFAULT 0,
  ADD COLUMN platform_fee NUMERIC(12,2) NOT NULL DEFAULT 0,
  ADD COLUMN seller_payout_amount NUMERIC(12,2),
  -- Set only by the BUYER confirming receipt (see dashboard.orders.tsx) —
  -- never by the seller's own status update. Fund release reads this
  -- column, not `status`, precisely so a seller can't mark their own
  -- order "delivered" and release payment without ever shipping anything.
  ADD COLUMN buyer_confirmed_at TIMESTAMPTZ;

COMMENT ON COLUMN public.orders.delivery_option IS
  'Only meaningful when the seller''s product(s) have transport_option = need_transport.
   need_transport here means the buyer is asking AGROVIAX to arrange a transporter (fee applies,
   a delivery job is posted). buyer_pickup means no transporter, no fee, no delivery job — even if
   the seller would have allowed platform transport.';

-- ============================================================
-- 3. Vehicle weight tiers — used to pick a fuel-consumption assumption and a
--    base handling fee for the transport fee formula. Admin-editable so
--    pricing can be adjusted as fuel prices/market conditions change.
-- ============================================================
CREATE TABLE public.vehicle_tiers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  label TEXT NOT NULL,                    -- e.g. "Bike / Keke (up to 50kg)"
  max_weight_kg NUMERIC(10,2) NOT NULL,   -- upper bound of this tier
  km_per_litre NUMERIC(6,2) NOT NULL,     -- assumed fuel efficiency for this vehicle class
  base_handling_fee NUMERIC(12,2) NOT NULL DEFAULT 0,
  sort_order INT NOT NULL DEFAULT 0
);
GRANT SELECT ON public.vehicle_tiers TO anon, authenticated;
GRANT ALL ON public.vehicle_tiers TO service_role;
ALTER TABLE public.vehicle_tiers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "vehicle_tiers_public_read" ON public.vehicle_tiers FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "vehicle_tiers_admin_write" ON public.vehicle_tiers FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Starting tiers. Realistic starting point, not researched per-vehicle-model —
-- adjust km_per_litre / fees from the admin dashboard as you get real data.
INSERT INTO public.vehicle_tiers (label, max_weight_kg, km_per_litre, base_handling_fee, sort_order) VALUES
  ('Bike / Keke (up to 50kg)', 50, 30, 500, 1),
  ('Small van (50–500kg)', 500, 10, 1500, 2),
  ('Pickup truck (500–2,000kg)', 2000, 6, 3500, 3),
  ('Large truck (2,000kg+)', 999999, 3.5, 7000, 4);

-- ============================================================
-- 4. Platform commission tiers — percentage of the PRODUCT subtotal only
--    (the transport fee passes through to the transporter untouched; it's
--    already a real, itemised cost, not a markup). Order-value-based, as
--    requested, rather than category-based like Jumia/Konga use — simpler
--    for a first version and easy to re-tier from the admin dashboard.
-- ============================================================
CREATE TABLE public.platform_fee_tiers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  min_amount NUMERIC(12,2) NOT NULL,
  max_amount NUMERIC(12,2),              -- NULL = no upper bound
  fee_percent NUMERIC(5,2) NOT NULL,
  sort_order INT NOT NULL DEFAULT 0
);
GRANT SELECT ON public.platform_fee_tiers TO anon, authenticated;
GRANT ALL ON public.platform_fee_tiers TO service_role;
ALTER TABLE public.platform_fee_tiers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "platform_fee_tiers_public_read" ON public.platform_fee_tiers FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "platform_fee_tiers_admin_write" ON public.platform_fee_tiers FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Starting tiers, informed by real Nigerian marketplace commissions (Jumia/
-- Konga run 4–15% by category). A lower, gently-declining range fits an
-- agri-marketplace with thinner margins than general retail — change any of
-- this any time from Admin → Fees & Payouts.
INSERT INTO public.platform_fee_tiers (min_amount, max_amount, fee_percent, sort_order) VALUES
  (0,        100000,   6.0, 1),
  (100000,   500000,   4.5, 2),
  (500000,   1000000,  3.5, 3),
  (1000000,  NULL,     2.5, 4);

CREATE OR REPLACE FUNCTION public.calculate_platform_fee(p_amount NUMERIC)
RETURNS NUMERIC
LANGUAGE sql
STABLE
SET search_path = public
AS $$
  SELECT COALESCE(
    p_amount * (
      SELECT fee_percent FROM public.platform_fee_tiers
      WHERE p_amount >= min_amount AND (max_amount IS NULL OR p_amount < max_amount)
      ORDER BY sort_order LIMIT 1
    ) / 100,
    0
  );
$$;

-- ============================================================
-- 5. Transport fee formula: distance × fuel price ÷ vehicle efficiency,
--    plus that vehicle tier's base handling fee, times a margin so the
--    transporter is actually earning something rather than just breaking
--    even on fuel.
-- ============================================================
CREATE TABLE public.platform_settings (
  key TEXT PRIMARY KEY,
  value JSONB NOT NULL
);
GRANT SELECT ON public.platform_settings TO anon, authenticated;
GRANT ALL ON public.platform_settings TO service_role;
ALTER TABLE public.platform_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "platform_settings_public_read" ON public.platform_settings FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "platform_settings_admin_write" ON public.platform_settings FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

INSERT INTO public.platform_settings (key, value) VALUES
  -- Manually admin-maintained reference price, not a live feed — there is no
  -- single reliable free API for a nationwide average pump price in Nigeria.
  -- Update this periodically from Admin → Fees & Payouts.
  ('fuel_price_per_litre', '{"amount": 1200, "note": "Manually updated reference price, NGN/litre", "updated_at": null}'),
  ('transport_fee_margin', '{"multiplier": 1.4}'),
  -- Where the platform's own commission settles. Filled in by the admin from
  -- Admin → Fees & Payouts, same shape as a payout_accounts row.
  ('platform_payout_account', '{"bank_name": "", "account_number": "", "account_name": ""}');

CREATE OR REPLACE FUNCTION public.calculate_transport_fee(p_distance_km NUMERIC, p_weight_kg NUMERIC)
RETURNS NUMERIC
LANGUAGE plpgsql
STABLE
SET search_path = public
AS $$
DECLARE
  tier RECORD;
  fuel_price NUMERIC;
  margin NUMERIC;
  fuel_cost NUMERIC;
BEGIN
  SELECT * INTO tier FROM public.vehicle_tiers
    WHERE COALESCE(p_weight_kg, 1) <= max_weight_kg ORDER BY sort_order LIMIT 1;
  IF NOT FOUND THEN
    SELECT * INTO tier FROM public.vehicle_tiers ORDER BY sort_order DESC LIMIT 1;
  END IF;

  SELECT (value ->> 'amount')::NUMERIC INTO fuel_price FROM public.platform_settings WHERE key = 'fuel_price_per_litre';
  SELECT (value ->> 'multiplier')::NUMERIC INTO margin FROM public.platform_settings WHERE key = 'transport_fee_margin';

  fuel_cost := (COALESCE(p_distance_km, 0) / tier.km_per_litre) * COALESCE(fuel_price, 1200);
  RETURN ROUND((tier.base_handling_fee + fuel_cost) * COALESCE(margin, 1.4), -1); -- round to nearest ₦10
END;
$$;

-- ============================================================
-- 6. Payout accounts — where a seller/business/transporter/expert receives
--    money. Deliberately NOT collected from buyers up front (see refund
--    flow below) — asking a buyer for bank details before they need one is
--    the kind of thing that makes people distrust a marketplace.
-- ============================================================
CREATE TABLE public.payout_accounts (
  user_id UUID PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  bank_name TEXT NOT NULL,
  bank_code TEXT NOT NULL DEFAULT '',
  account_number TEXT NOT NULL,
  account_name TEXT NOT NULL,
  paystack_recipient_code TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.payout_accounts TO authenticated;
GRANT ALL ON public.payout_accounts TO service_role;
ALTER TABLE public.payout_accounts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "payout_accounts_owner" ON public.payout_accounts FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "payout_accounts_admin_read" ON public.payout_accounts FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

-- ============================================================
-- 7. Refunds — buyer-initiated, bank details collected only at this point,
--    reviewed by an admin (manual settlement, matching the safe-payment
--    document's dispute flow: hold, review, decide, not instant/automatic).
-- ============================================================
CREATE TABLE public.refund_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES public.orders ON DELETE CASCADE,
  buyer_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  reason TEXT NOT NULL,
  bank_name TEXT NOT NULL,
  account_number TEXT NOT NULL,
  account_name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'paid')),
  admin_note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.refund_requests TO authenticated;
GRANT UPDATE ON public.refund_requests TO authenticated;
GRANT ALL ON public.refund_requests TO service_role;
ALTER TABLE public.refund_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "refund_requests_buyer_insert" ON public.refund_requests FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = buyer_id);
CREATE POLICY "refund_requests_buyer_read" ON public.refund_requests FOR SELECT TO authenticated
  USING (auth.uid() = buyer_id OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "refund_requests_admin_update" ON public.refund_requests FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE OR REPLACE FUNCTION public.notify_refund_status_change()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.status IS DISTINCT FROM OLD.status THEN
    INSERT INTO public.notifications (user_id, title, body, kind)
    VALUES (NEW.buyer_id, 'Refund update', 'Your refund request is now "' || NEW.status || '".', 'order');
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER refund_requests_notify_buyer
  AFTER UPDATE ON public.refund_requests
  FOR EACH ROW EXECUTE FUNCTION public.notify_refund_status_change();

CREATE OR REPLACE FUNCTION public.notify_new_refund_request()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.notifications (user_id, title, body, kind)
  SELECT ur.user_id, 'New refund request', NEW.reason, 'order'
  FROM public.user_roles ur WHERE ur.role = 'admin';
  RETURN NEW;
END;
$$;
CREATE TRIGGER refund_requests_notify_admin
  AFTER INSERT ON public.refund_requests
  FOR EACH ROW EXECUTE FUNCTION public.notify_new_refund_request();

-- ============================================================
-- 8. Payments — the ledger the escrow/split flow reads and writes to. Real
--    money movement needs a payment gateway wired in via Edge Functions
--    (see supabase/functions/) with real API keys; this table is the
--    source of truth those functions read/write.
-- ============================================================
CREATE TABLE public.payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES public.orders ON DELETE CASCADE,
  provider TEXT NOT NULL DEFAULT 'paystack',
  reference TEXT UNIQUE,
  amount NUMERIC(12,2) NOT NULL,
  platform_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  seller_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  transport_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'paid', 'released', 'refunded', 'failed')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.payments TO authenticated;
GRANT ALL ON public.payments TO service_role;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "payments_party_read" ON public.payments FOR SELECT TO authenticated
  USING (
    EXISTS (SELECT 1 FROM public.orders o WHERE o.id = order_id AND (o.buyer_id = auth.uid() OR o.seller_id = auth.uid()))
    OR public.has_role(auth.uid(), 'admin')
  );
-- Deliberately no client INSERT/UPDATE policy: only Edge Functions running
-- with the service role (after verifying a real payment webhook) may write
-- here. A payment status is not something a browser should be able to set.
