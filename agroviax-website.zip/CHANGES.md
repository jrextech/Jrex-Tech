# AGROVIAX — changes made in this review pass

This file documents exactly what was audited, fixed, and added on top of the
original Lovable-generated build. Everything below was verified by reading
the actual source and, where possible, checked with a local TypeScript
syntax pass (no network access was available to run `npm install`, so this
was **not** run through a live dev server — see "What still needs your
verification" at the bottom).

## Real bugs fixed

1. **Marketplace listing category defaulted to a non-existent slug.**
   `dashboard.listings.tsx` initialised the category `<select>` to
   `"grains-cereals"`, but the seeded `categories` table only has `"grains"`.
   Every new listing created without touching the dropdown got silently
   orphaned from its category. Fixed to default to `"grains"`.

2. **AI confidence score displayed 100x too high.**
   The crop-health AI function returns confidence as a 0–100 number, but
   `dashboard.cases.tsx` multiplied it by 100 again when displaying it
   (would have shown "8700% confidence" instead of "87% confidence"). Fixed.

3. **Crop-health scans were never saved to the database.**
   This was the biggest gap. The public `/crop-health` AI scanner produced a
   result on-screen but never wrote a `disease_cases` row — so a signed-in
   farmer's case history page and the expert review queue could *never* have
   anything in them; the whole "scan → save → escalate to expert" loop was
   disconnected. Rebuilt end-to-end:
   - The photo now uploads to the `crop-media` storage bucket (already had
     correct RLS policies, just wasn't being used) under the user's own
     folder, and a long-lived signed URL is stored.
   - A `disease_cases` row is written with the AI's output.
   - "Request expert review" is now a real action (updates case status)
     instead of a dead link to the sign-up page.
   - Anonymous visitors still get the AI result on-screen (no regression),
     just with a prompt to sign up to save it, instead of a promise that
     silently did nothing.

4. **The cart/checkout system existed but was completely disconnected.**
   `src/lib/cart.tsx` defines a full `CartProvider`/`useCart` context, but
   it was never mounted anywhere, no button anywhere added an item to it,
   and nothing in the app ever inserted a row into `orders`. The Orders
   dashboard's own empty-state text referenced a "basket" that didn't exist
   in the UI. Fixed:
   - `CartProvider` is now mounted at the app root (`__root.tsx`).
   - Built `src/components/site/CartDrawer.tsx` — a cart drawer (using the
     existing Sheet component) with quantity controls and a real checkout
     action that inserts into `orders` + `order_items`, correctly split into
     one order per seller if the basket has items from more than one
     (matches the schema's one-seller-per-order design).
   - Added the cart button to the site header (desktop + mobile).
   - `marketplace.$id.tsx` (product detail page) now shows real "Add to
     basket" / "Message seller" actions for signed-in visitors, a "Manage
     this listing" link if you're viewing your own product, and only falls
     back to "sign in to order" for anonymous visitors — previously it
     showed "sign in" unconditionally, even to users already logged in.

5. **Messages showed raw UUID fragments instead of names.**
   `dashboard.messages.tsx` displayed conversation partners as `#a3f9c210`
   with no way to tell who that was. Now joins against `profiles` and shows
   the person's organisation or full name, sorts conversations by most
   recent activity, and shows who the open thread is with.

6. **The public contact form was fake.**
   It ran a `setTimeout` and showed a success toast without saving the
   message anywhere. Added a `contact_messages` table (new migration,
   `20260814090000_add_contact_messages.sql`) with RLS allowing public
   insert / admin-only read, wired the form to really insert into it, and
   added an "Inbox" tab to the admin dashboard so submissions are actually
   reviewable (with an unread-count badge).

## Second pass — login, notifications, payment, image upload, and per-role audit

1. **Login redirect bug, actually fixed.** The auth guard (`_authenticated/route.tsx`)
   used `supabase.auth.getUser()`, which makes a fresh network round-trip to
   re-verify the session, racing against the sign-in call that just set it —
   this could bounce a just-logged-in user straight back to `/auth`. Switched
   to `getSession()` (reads the already-persisted session, no race), matching
   what `useAuth.ts` already correctly used.

2. **Order notifications, built for real.** Added database triggers
   (`20260814120000_payments_and_notifications.sql`) so a seller is notified
   the instant an order is placed, a buyer is notified on status changes, a
   farmer is notified when an expert review comes back, and transporters are
   notified when a delivery job is posted. Built an actual notification bell
   (`NotificationsBell.tsx`) with unread count and mark-as-read, mounted in
   both the dashboard topbar and public header. Notifications respect
   per-user preferences (see Settings below) — the toggle actually stops the
   trigger from writing the row, not just hides it in the UI.

3. **Payment method at checkout.** Added a `payment_method` column
   (`pay_on_delivery` / `bank_transfer`) and a real selector in the cart
   drawer. No card processor is wired in — that needs a real gateway account
   (Paystack/Flutterwave) and API keys, which can't be fabricated. This is
   the honest, common pattern instead: the method is recorded, buyer and
   seller settle by it directly, and the order record stays authoritative.

4. **Image upload for listings, fixed.** The "sell something" form used a
   raw URL text field. Replaced it with a real upload button (
   `product-media` storage bucket, new migration, public-read/owner-write
   RLS) with a live preview.

5. **Removed the fake demo marketplace listings.** The seeded produce
   listings (maize, tomatoes, onions, etc. from the original schema
   migration) had no real seller account behind them — "message seller" or
   "buy" led nowhere real. Deleted via migration
   (`20260814140000_remove_seed_products.sql`), which only removes rows with
   no `seller_id`, so real listings are untouched.

6. **Marketplace → logistics loop closed.** There was no way to actually
   post a delivery job from an order — the logistics/transporter side could
   accept jobs but nothing created them. Added an "Arrange transport" action
   on confirmed/paid orders (seller side) that posts a real `deliveries` row,
   and the order card now shows live delivery status once one exists.

7. **Settings page**, new: theme (light/dark/system, applied site-wide, not
   just the dashboard), per-category notification toggles that are wired
   into the trigger functions (not decorative), password change, and an
   account-deletion request flow (routed to admin — real user deletion needs
   a service-role action, so this is handled by a person, which is standard
   practice for anything this irreversible).

8. **FAQ page**, new (`/faq`): real AGROVIAX-specific Q&A plus a working
   "ask a question" box that inserts into the same `contact_messages` table
   as the contact page, visible in the admin Inbox.

9. **Per-role dashboard overview, fixed.** Every role saw the identical 8
   stat cards — a buyer's overview showed "Farms: 0", "Total income: ₦0"
   with links to pages not even in their own sidebar; an expert had zero
   role-relevant information anywhere on their own overview (no
   pending-review count). Overview now adapts: farmer/business/admin keep
   the full management view, buyer/transporter get a lean, relevant set, and
   experts get a real "pending reviews" card linking to their queue.

10. **Case photos were invisible everywhere except the instant of scanning.**
    Neither the farmer's own case list nor the expert review queue displayed
    the actual uploaded photo — an expert had to diagnose blind. Fixed both.

11. **Expenses/income always attributed to your first farm**, silently,
    if you had more than one. Added a farm selector to both forms so this
    only auto-picks when you actually have just one farm.

12. **Form autocomplete/suggestions**, added via native `<datalist>` (no
    extra dependency): crop names, Nigerian states for every location field
    (farms, listings, profile), market prices form (crop/market/region
    suggest from what's already in the table), and expense categories /
    income sources.

13. **Duplicate email on sign-up — verified, not a bug.** Supabase already
    rejects a second sign-up with a confirmed email with a clear error,
    which the form surfaces. The one exception (re-signing up with an
    *unconfirmed* email returns a generic success) is intentional
    anti-enumeration behavior on Supabase's side, not something to override.

14. **Login/Sign up reachable from anywhere — verified, already true.**
    Every public route goes through the shared `SiteHeader`, which shows
    Sign in / Create account whenever you're logged out. Nothing needed
    fixing here; confirmed by grepping every route file.

One structural note: `src/routeTree.gen.ts` is auto-generated by TanStack
Router's Vite plugin and explicitly marked as such (`@ts-nocheck`,
eslint-disabled). The two new routes added this session (`/faq`,
`/dashboard/settings`) will register automatically the first time you run
`npm run dev` or `npm run build` — you don't need to do anything, but if you
browse the raw source before running it, don't be alarmed that this file
doesn't mention them yet.

## What still needs your verification

I have no internet access in the environment I did this work in, so I could
not run `npm install`, boot the dev server, or click through the app myself.
Every change above was verified by:
- Reading the actual file contents and tracing data flow against the real
  database schema (not assuming — e.g. the category bug was caught by
  cross-checking the seeded `categories` slugs against the hardcoded default).
- A local TypeScript syntax/structure check (stubbed module resolution,
  since the real `node_modules` isn't installed) that came back clean for
  every file touched.

Before you treat this as production-ready, please:
1. `cd source-code && npm install && npm run dev` and click through the
   flows above yourself, especially checkout (money-adjacent code deserves
   a human look) and the crop-health save/expert-review loop.
2. Confirm your Supabase project (`wuhjrhsvjyvjeaxlyeno`) is still the one
   referenced in `.env` and that the new `contact_messages` migration has
   been applied (`supabase db push` or via the Lovable Cloud dashboard).
3. Note that Google sign-in and the crop-health AI call both depend on
   Lovable Cloud's own services (`LOVABLE_API_KEY` / the built-in OAuth
   integration) — they won't work if this is run completely outside
   Lovable's hosting without adapting those two integration points.

## Session: Departmental admin architecture (multiple admins, real RBAC)

Implemented the Compressed Admin Structure: Super Admin plus 7 departments
(Business & Marketplace, Agriculture & Crop Health, Logistics & Operations,
Finance, Customer & Support, Technology & Security, Marketing &
Communications). This is **multiple distinct admin accounts**, each scoped
to their own department — not one shared "admin" login.

- New `admin_staff` table (one department per admin) + `has_department()`
  function. Existing single-admin accounts are auto-migrated to
  `super_admin` so nobody loses access.
- **Enforced at the database**, not just hidden buttons: every previously
  blanket "any admin" RLS policy (drivers, logistics partners, fee tiers,
  platform settings, refunds, payments, vehicle tiers, product moderation,
  contact inbox, crop-health cases) now checks the specific department.
- `audit_log` table + triggers on every high-risk table (admin/department
  assignment, driver approval, fee changes, refund decisions, payment
  status) — who, what, when, before/after.
- Admin dashboard now shows only the tabs a given admin's department
  actually covers; Super Admin sees everything plus a "Staff & departments"
  tab to create new department admin accounts (same one-time
  credential-handoff pattern as driver/partner accounts).
- Gave the three previously-empty departments real tools: Agriculture gets
  platform-wide crop-health case oversight; Marketing gets an announcements
  system with a live site-wide + in-dashboard banner; IT/Security gets the
  audit log.
- Removed the "Built with Lovable" badge (it's injected by Lovable's own
  build tooling, not something in this project's source, so it's hidden via
  a permanent CSS override rather than deleted at the source).
- Verified every self-signup role (farmer, buyer, business, expert) still
  has a complete, non-empty dashboard nav after all these changes — nothing
  broke. Business still shares farmer's farm/listing/finance/order tools
  (fully functional) rather than having a dedicated workspace — that
  remains a distinct future phase, not something silently skipped.
